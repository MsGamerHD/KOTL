package de.msgamerhd.kingoftheladder.countdowns;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.commands.Skip_CMD;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.utils.GameUtils;
import de.msgamerhd.kingoftheladder.utils.HologramUtils;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;
import de.msgamerhd.kingoftheladder.utils.TokensUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class ShopCountdown {

	public static int shopcountdown = GameStatus.SHOP.getTime();
	
	public static void startCountdown(){
		shopcountdown = GameStatus.SHOP.getTime();
		
		Main.status = GameStatus.SHOP;
		HologramUtils.refreshHolos();
		TokensUtils.tokens.clear();
		
		for(Player all : Bukkit.getOnlinePlayers()){
			PlayerUtils.teleportToLobby(all);
			all.playSound(all.getLocation(), Sound.ANVIL_LAND, 1, 1);
			PlayerUtils.resetPlayer(all, GameMode.ADVENTURE, true);
			
			if(PlayerUtils.getTeam(all) == Team.SPIELENDER){
				PlayerUtils.clearChat(all);
				all.sendMessage(Settings.pr+Settings.hlt+"Die Kaufphase endet in "+GameStatus.SHOP.getTime()+" Sekunden!");
				all.sendMessage(Settings.pr+"Deine erspielten Tokens: �6"+TokensUtils.getTokens(all));
				all.getInventory().setItem(4, ItemUtils.getItem(Material.CHEST, 1, 0, Settings.shop_name, null));
			}
		}
		
		ScoreboardUtils.resetScoreboardAll();
		ScoreboardUtils.updateBoard();
		
		
		
		new BukkitRunnable() {
			
			@Override
			public void run() {
				if(Main.status != GameStatus.SHOP){
					cancel();
					return;
				}
				for(Player all : Bukkit.getOnlinePlayers()){
					PlayerUtils.sendActionBar(all, "�6�l>> �e�lAusr�sten");
				}
				
				if(Skip_CMD.skiped.size() >= GameUtils.getPlayerCount()){
					if(shopcountdown > 5){
						shopcountdown = 5;
						Bukkit.broadcastMessage(Settings.pr+"Die Wartezeit wurde auf "+Settings.hlt+"5 Sekunden"+Settings.co+" verk�rzt!");
					}
				}
				
				if(shopcountdown == 10 || (shopcountdown <= 5 && shopcountdown >= 1)){
					for(Player all : Bukkit.getOnlinePlayers()){
						all.playSound(all.getLocation(), Sound.ITEM_PICKUP, 1, 1);
					}
				} else if(shopcountdown == 0){
					DeathmatchCountdown.startCountdown();
					cancel();
				}
				ScoreboardUtils.updateDisplayname();
				shopcountdown-=1;
			}
		}.runTaskTimer(Main.getInstance(), 0, 20);
	}
	
}
