package de.msgamerhd.kingoftheladder.countdowns;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.kits.KitSkillUtils;
import de.msgamerhd.kingoftheladder.stats.Stats_PlayedGames;
import de.msgamerhd.kingoftheladder.utils.MapUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class ProtectionCountdown {

	public static int protectioncountdown = GameStatus.PROTECTION.getTime();
	
	public static void startCountdown(){
		protectioncountdown = GameStatus.PROTECTION.getTime();
		
		Main.status = GameStatus.PROTECTION;
		
		for(Player all : Bukkit.getOnlinePlayers()){
			all.playSound(all.getLocation(), Sound.LEVEL_UP, 1, 1);
			
			PlayerUtils.addTeam(all, Team.SPIELENDER);
			PlayerUtils.resetPlayer(all, GameMode.SURVIVAL, true);
			PlayerUtils.clearChat(all);
			PlayerUtils.teleportToMapspawn(all);
			PlayerUtils.updateItems(all);
			KitSkillUtils.setKitEffectAndItem(all);
			
			Stats_PlayedGames.add(all.getUniqueId(), 1);
		}
		Bukkit.broadcastMessage(Settings.pr+Settings.acpt+"Das Spiel beginnt!");
		Bukkit.broadcastMessage(Settings.pr+"Gespielt wird auf der Map "+Settings.hlt+Main.map+Settings.co+" von "+Settings.hlt+MapUtils.getBuilder(Main.map)+Settings.co+".");
		
		ScoreboardUtils.resetScoreboardAll();
		ScoreboardUtils.updateBoard();
		
		
		
		new BukkitRunnable() {
			
			@Override
			public void run() {
				if(Main.status != GameStatus.PROTECTION){
					cancel();
					return;
				}
				for(Player all : Bukkit.getOnlinePlayers()){
					PlayerUtils.sendActionBar(all, "�6�l>> �e�lSchutzzeit");
				}
				
				if(protectioncountdown == 10 || protectioncountdown == 3 || protectioncountdown == 2 || protectioncountdown == 1){
					Bukkit.broadcastMessage(Settings.pr+"Das Spiel startet in "+Settings.hlt+protectioncountdown+(protectioncountdown == 1 ? " Sekunde" : " Sekunden")+Settings.co+".");
					
					for(Player all : Bukkit.getOnlinePlayers()){
						all.playSound(all.getLocation(), Sound.ITEM_PICKUP, 1, 1);
					}
				} else if(protectioncountdown == 0){
					GameCountdown.startCountdown();
					cancel();
				}
				ScoreboardUtils.updateDisplayname();
				protectioncountdown-=1;
			}
		}.runTaskTimer(Main.getInstance(), 0, 20);
	}
	
}
