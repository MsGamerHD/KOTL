package de.msgamerhd.kingoftheladder.countdowns;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class RestartCountdown {

	public static void startCountdown(){
		Main.status = GameStatus.RESTARTING;
		
		
		PlayerUtils.updateVisibility();
		
		for(Player all : Bukkit.getOnlinePlayers()){
			PlayerUtils.teleportToLobby(all);
			PlayerUtils.resetPlayer(all, GameMode.ADVENTURE, true);
		}
		
		ScoreboardUtils.resetScoreboardAll();
		ScoreboardUtils.updateBoard();
		ScoreboardUtils.updateDisplayname();
		
		Bukkit.broadcastMessage(Settings.pr+Settings.wrn+"Der Server startet in "+GameStatus.RESTARTING.getTime()+" Sekunden neu!");
	
		new BukkitRunnable() {
			
			@Override
			public void run() {
//				for(Player all : Bukkit.getOnlinePlayers()){
//					all.kickPlayer("�cDer Server startet neu.");
//				}
				Bukkit.reload();
//				Bukkit.spigot().restart();
			}
		}.runTaskLater(Main.getInstance(), GameStatus.RESTARTING.getTime()*20);
	}
	
}
