package de.msgamerhd.kingoftheladder.countdowns;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.commands.Einrichten_CMD;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.utils.HologramUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class LobbyCountdown {

	public static int lobbycountdown = GameStatus.LOBBY.getTime();
	
	public static void startCountdown(){
		lobbycountdown = GameStatus.LOBBY.getTime();
		
		Main.status = GameStatus.LOBBY;
		
		for(Player all : Bukkit.getOnlinePlayers()) {
			PlayerUtils.resetPlayer(all, GameMode.ADVENTURE, true);
			PlayerUtils.playerJoin(all);
		}
		HologramUtils.refreshHolos();
		ScoreboardUtils.updateBoard();
		ScoreboardUtils.updateDisplayname();
		
		
		
		new BukkitRunnable() {
			
			@Override
			public void run() {
				if(Einrichten_CMD.configurationmode){
					for(Player all : Bukkit.getOnlinePlayers()){
						PlayerUtils.sendActionBar(all, "�6�l>> �4�lDer Server wird gerade eingerichtet �6�l<<");
					}
				} else {
					int onlinecount = Bukkit.getOnlinePlayers().size();
					for(Player all : Bukkit.getOnlinePlayers()){
						PlayerUtils.sendActionBar(all, "�6�l>> �e�lSpieler: �a�l"+onlinecount+" �6�l| �e�lMindestens: "+Settings.hlt+"�l"+Settings.minplayers+" �6�l<<");
					}
					
					if(onlinecount >= Settings.minplayers){
						if(lobbycountdown == 60 || lobbycountdown == 40 ||lobbycountdown == 30 || lobbycountdown == 20 || (lobbycountdown > 0 && lobbycountdown <= 10)){
							Bukkit.broadcastMessage(Settings.pr+"Noch "+Settings.hlt+lobbycountdown+Settings.co+(lobbycountdown == 1 ? " Sekunde" : " Sekunden")+" bis zum Start!");
							
							for(Player all : Bukkit.getOnlinePlayers()){
								all.playSound(all.getLocation(), Sound.NOTE_BASS, 1, 1);
							}
						} else if(lobbycountdown == 0){
							ProtectionCountdown.startCountdown();
							cancel();
						}
					} else {
						lobbycountdown = GameStatus.LOBBY.getTime();
					}
					ScoreboardUtils.updateDisplayname();
					lobbycountdown-=1;
				}
			}
		}.runTaskTimer(Main.getInstance(), 0, 20);
	}
	
}
