package de.msgamerhd.kingoftheladder.countdowns;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.kits.KitSkillUtils;
import de.msgamerhd.kingoftheladder.kits.KitUtils;
import de.msgamerhd.kingoftheladder.utils.GameUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.PointsUtils;

/**
 * Class created by MsGamerHD on 04.10.2016
 */
public class OtherRunnables {

	//Freeze
	public static void startFreezeRunnable(){
		new BukkitRunnable() {
			
			@SuppressWarnings("deprecation")
			@Override
			public void run() {
				for(Player all : KitSkillUtils.freezelist.keySet()){
					if(all != null){
						int counter = KitSkillUtils.freezelist.get(all);
						counter-=1;
						if(counter <= 0){
							KitSkillUtils.freezelist.remove(all);
							all.sendMessage(Settings.pr+Settings.hlt+"Du kannst dich wieder bewegen!");
						} else {
							KitSkillUtils.freezelist.put(all, counter);
							all.getWorld().playEffect(all.getLocation(), Effect.STEP_SOUND, Material.ICE.getId(), 10);
							all.damage(0.8);
						}
					}
				}
			}
		}.runTaskTimer(Main.getInstance(), 5, 5);
	}
	
	public static HashMap<Player, Integer> pointtime = new HashMap<>();
	
	public static void startRunnableForEverySecond(){
		new BukkitRunnable() {
			
			@Override
			public void run() {
				//Wetter
				for(World w : Bukkit.getWorlds()){
					w.setStorm(false);
					w.setThundering(false);
				}
				
				//Punkte f�r den K�nig
				if(Main.status == GameStatus.INGAME){
					for(Player all : Bukkit.getOnlinePlayers()){
						int count = 0;
						if(pointtime.containsKey(all)) count = pointtime.get(all);
						
						int wait = 4;
						
						if(count >= (wait-1)) {
							count = 0;
							String extra = "";
							
							int coins = 2;
							
							if(GameUtils.isKing(all)) {
								extra = " �6(+ 3 Punkte K�nig-Bonus)";
								coins+=3;
							}
							if(KitUtils.pkits.containsKey(all)){
								if(KitUtils.pkits.get(all) == Kit.DIEB){
									extra = extra+" �7(�b+ 1 �7Geklauten Punkt)";
									coins+=1;
								}
							}
							PlayerUtils.sendActionBar(all, "�a+ 2"+(coins == 1 ? " Punkt" : " Punkte")+extra);
							PointsUtils.addPoints(all, coins, false);
						} else {
							count+=1;
							PlayerUtils.sendActionBar(all, "�ePunkte in "+Settings.hlt+(wait-count)+((wait-count) == 1 ? " Sekunde" : " Sekunden"));
						}
						
						pointtime.put(all, count);
					}
				}
			}
		}.runTaskTimer(Main.getInstance(), 20, 20);
	}
}
