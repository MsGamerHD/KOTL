package de.msgamerhd.kingoftheladder.countdowns;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.powerups.Powerup;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class GameCountdown {

	public static int gamecountdown = GameStatus.INGAME.getTime();
	
	public static void startCountdown(){
		gamecountdown = GameStatus.INGAME.getTime();
		
		Main.status = GameStatus.INGAME;

		for(Player all : Bukkit.getOnlinePlayers()){
			all.playSound(all.getLocation(), Sound.ANVIL_LAND, 1, 1);
		}
		Bukkit.broadcastMessage(Settings.pr+Settings.hlt+"Go!");
		
		ScoreboardUtils.updateBoard();
		Powerup.startSpawningPowerups();
		
		
		
		new BukkitRunnable() {
			
			@Override
			public void run() {
				if(Main.status != GameStatus.INGAME){
					cancel();
					return;
				}
				
				if(gamecountdown == 60 || gamecountdown == 30 || gamecountdown == 20 || (gamecountdown > 0 && gamecountdown <= 10)){
					for(Player all : Bukkit.getOnlinePlayers()){
						all.playSound(all.getLocation(), Sound.NOTE_BASS, 1, 1);
					}
				} else if(gamecountdown == 0){
					ShopCountdown.startCountdown();
					cancel();
				}
				ScoreboardUtils.updateDisplayname();
				gamecountdown-=1;
			}
		}.runTaskTimer(Main.getInstance(), 0, 20);
	}
	
}
