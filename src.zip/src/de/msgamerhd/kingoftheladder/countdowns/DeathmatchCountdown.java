package de.msgamerhd.kingoftheladder.countdowns;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.Map_DeathmatchUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class DeathmatchCountdown {

	public static int deathmatchcountdown = GameStatus.DEATHMATCH.getTime();
	
	public static void startCountdown(){
		deathmatchcountdown = GameStatus.DEATHMATCH.getTime();
		
		Main.status = GameStatus.DEATHMATCH;
		
		for(Player all : Bukkit.getOnlinePlayers()){
			PlayerUtils.resetPlayer(all, GameMode.SURVIVAL, false);
			all.closeInventory();
			ItemUtils.removeItem(all, Material.CHEST, 1);
			PlayerUtils.teleportToDMMapspawn(all);
			PlayerUtils.clearChat(all);
			PlayerUtils.respawnProtection(all, 2);
			all.playSound(all.getLocation(), Sound.ANVIL_LAND, 1, 1);
		}
		Bukkit.broadcastMessage(Settings.pr+Settings.hlt+"DEATHMATCH!");
		Bukkit.broadcastMessage(Settings.pr+"Das Deathmatch wird auf der Map "+Settings.hlt+Main.dmmap+Settings.co+" von "+Settings.hlt+Map_DeathmatchUtils.getBuilder(Main.dmmap)+Settings.co+" ausgetragen.");

		ScoreboardUtils.resetScoreboardAll();
		ScoreboardUtils.updateBoard();
		ScoreboardUtils.updateDisplayname();
		
		new BukkitRunnable() {
			
			@Override
			public void run() {
				if(Main.status != GameStatus.DEATHMATCH){
					cancel();
					return;
				}
				for(Player all : Bukkit.getOnlinePlayers()){
					PlayerUtils.sendActionBar(all, "�6�l>> �c�lTEAMS VERBOTEN!");
				}
				
				if(deathmatchcountdown == 60 || deathmatchcountdown == 30 || deathmatchcountdown == 20 || (deathmatchcountdown > 0 && deathmatchcountdown <= 10)){
					Bukkit.broadcastMessage(Settings.pr+Settings.wrn+"Das Deathmatch endet in "+Settings.hlt+deathmatchcountdown+Settings.wrn+(deathmatchcountdown == 1 ? " Sekunde" : " Sekunden")+"!");
					
					for(Player all : Bukkit.getOnlinePlayers()){
						all.playSound(all.getLocation(), Sound.NOTE_BASS, 1, 1);
					}
				} else if(deathmatchcountdown == 0){
					for(Player all : Bukkit.getOnlinePlayers()){
						all.playSound(all.getLocation(), Sound.ANVIL_LAND, 1, 1);
						PlayerUtils.clearChat(all);
					}
					
					Bukkit.broadcastMessage(Settings.pr+Settings.wrn+"Das Spiel ist zu Ende!");
					Bukkit.broadcastMessage(Settings.pr+Settings.wrn+"Keiner hat gewonnen!");
					RestartCountdown.startCountdown();
					cancel();
				}
				ScoreboardUtils.updateDisplayname();
				deathmatchcountdown-=1;
			}
		}.runTaskTimer(Main.getInstance(), 0, 20);
	}
	
}
