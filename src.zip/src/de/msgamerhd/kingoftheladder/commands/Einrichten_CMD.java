package de.msgamerhd.kingoftheladder.commands;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.countdowns.LobbyCountdown;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.utils.HologramUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Einrichten_CMD implements CommandExecutor{

	public static boolean configurationmode = false;
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;

		if(!(p.hasPermission("game.configurate"))){
			p.sendMessage(Settings.perm);
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
			return false;
		}
		
		LobbyCountdown.lobbycountdown = GameStatus.LOBBY.getTime();
		ScoreboardUtils.updateDisplayname();
		if(configurationmode){
			for(Player all : Bukkit.getOnlinePlayers()){
				HologramUtils.refreshPacketHolos(all);
			}
			HologramUtils.refreshHolos();
			p.sendMessage(Settings.pr+Settings.acpt+"Der Server befindet sich nun wieder im Spielmodus.");
			configurationmode = false;
			LobbyCountdown.startCountdown();
			
		} else {
			for(Player all : Bukkit.getOnlinePlayers()){
				PlayerUtils.resetPlayer(all, GameMode.CREATIVE, true);
				HologramUtils.removeHolos(all);
			}
			HologramUtils.removeHolos();
			p.sendMessage(Settings.pr+Settings.acpt+"Der Server befindet sich nun im Einrichtungsmodus.");
			configurationmode = true;
		}
		return false;
	}
	
}
