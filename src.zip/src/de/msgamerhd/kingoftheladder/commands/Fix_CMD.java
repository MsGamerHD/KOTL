package de.msgamerhd.kingoftheladder.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.countdowns.GameCountdown;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Fix_CMD implements CommandExecutor{

	public static boolean configurationmode = false;
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;
		PlayerUtils.updateVisibility();
		p.sendMessage(Settings.pr+Settings.acpt+"Fixed!");
		
		GameCountdown.gamecountdown = 5;
		return false;
	}
	
}
