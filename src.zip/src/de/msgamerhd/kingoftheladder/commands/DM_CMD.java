package de.msgamerhd.kingoftheladder.commands;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.Map_DeathmatchUtils;
import de.msgamerhd.kingoftheladder.utils.FileManager;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
@SuppressWarnings("unused")
public class DM_CMD  implements CommandExecutor{
	
	public static HashMap<Player, String> editmap = new HashMap<>();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;
		
		if(!(p.hasPermission("game.configurate"))){
			p.sendMessage(Settings.perm);
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
			return false;
		}
		
		if(args.length == 1){
			if(args[0].equalsIgnoreCase("maps")){
				p.sendMessage(Settings.pr+"Folgende Deathmatch-Maps sind verf�gbar: "+Settings.hlt+Map_DeathmatchUtils.getMaps());
			
			} else if(args[0].equalsIgnoreCase("end")){
				if(!editmap.containsKey(p)){
					p.sendMessage(Settings.pr+Settings.wrn+"Du bearbeitest aktuell keine Deathmatch-Map.");
					return false;
				}
				
				p.sendMessage(Settings.pr+Settings.acpt+"Das Bearbeiten der Deathmatch-Map "+Settings.hlt+editmap.get(p)+Settings.acpt+" wurde erfolgreich beendet.");
				editmap.remove(p);
				
			} else if(args[0].equalsIgnoreCase("nextspawn")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/dm edit <Map>"+Settings.wrn+" zur Bearbeitung einer Deathmatch-Map ein.");
					return false;
				}
				
				p.sendMessage(Settings.pr+Settings.acpt+"Der Spawnpunkt mit der ID "+Settings.hlt+"#"+Map_DeathmatchUtils.addSpawn(editmap.get(p), p.getLocation())+Settings.acpt+" wurde der Deathmatch-Map "+editmap.get(p)+" hinzugef�gt.");
				
			} else if(args[0].equalsIgnoreCase("inv")){
				Inventory inv = Bukkit.createInventory(null, 9, Settings.dm_einrichten_invname);
				
				for(int i = 0; i < inv.getSize(); i++){
					inv.setItem(i, ItemUtils.getItem(Material.STAINED_GLASS_PANE, 1, 7, " ", null));
				}

				inv.setItem(4, ItemUtils.getItem(Material.NETHER_STAR, 1, 0, Settings.dm_setspawn_itemname, "�7Hiermit f�gst du einen �bSpawnpunkt\n�7f�r die Spieler hinzu"));
				
				p.openInventory(inv);
			
			} else if(args[0].equalsIgnoreCase("help")){
				p.sendMessage("�6>> �a�bersicht �7�o(DM) �6<<");
				p.sendMessage(Settings.hlt+"/dm createmap <Mapname>");
				p.sendMessage(Settings.co+"Erstelle eine neue Deathmatch-Map");
				
				p.sendMessage(Settings.hlt+"/dm maps");
				p.sendMessage(Settings.co+"Zeigt dir eine Liste aller verf�gbaren Deathmatch-Maps");

				p.sendMessage(Settings.hlt+"/dm edit <Mapname>");
				p.sendMessage(Settings.co+"W�hle eine Map zur Bearbeitung aus");

				p.sendMessage(Settings.hlt+"/dm end");
				p.sendMessage(Settings.co+"Schlie�e die Bearbeitung einer Deathmatch-Map ab");

				p.sendMessage(Settings.hlt+"/dm nextspawn");
				p.sendMessage(Settings.co+"F�ge einen weiteren Spawnpunkt hinzu");
				
				p.sendMessage(Settings.hlt+"/dm removespawn <ID>");
				p.sendMessage(Settings.co+"L�sche einen bereits gesetzten Spawnpunkt");

				p.sendMessage(Settings.hlt+"/dm setbuilder <Namen des Erbauers>");
				p.sendMessage(Settings.co+"Setze den Zielpunkt der Deathmatch-Map");
				
				p.sendMessage(Settings.hlt+"/dm inv");
				p.sendMessage(Settings.co+"�ffne das GUI zur vereinfachten bedienung");
			} else {
				p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/dm help");
			}
		
		} else if(args.length >= 2){ 
			if(args.length == 2 && args[0].equalsIgnoreCase("removespawn")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/dm edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
					return false;
				}
				
				try {
					int id = Integer.parseInt(args[1]);
					
					if(Map_DeathmatchUtils.existSpawn(editmap.get(p), id)){
						Map_DeathmatchUtils.removeSpawn(editmap.get(p), id);
						p.sendMessage(Settings.pr+Settings.acpt+"Der Spawnpunkt "+Settings.hlt+"#"+id+Settings.acpt+" wurde erfolgreich gel�scht.");
					} else {
						p.sendMessage(Settings.pr+Settings.wrn+"Der angegeben Spawnpunkt existiert nicht.");
					}
				} catch (NumberFormatException e) {
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte gebe eine korrekte ID an!");
				}
			} 
			if(args[0].equalsIgnoreCase("createmap")){
				if(editmap.containsKey(p)){
					p.sendMessage(Settings.pr+Settings.wrn+"Bevor du eine neue Deathmatch-Map erstellen willst, musst du den aktuellen �nderungs-Modus mit "+Settings.hlt+"/ktol end"+Settings.wrn+" verlassen!");
					return false;
				}
				
				String mapname = "";
				
				for(int i = 1; i < args.length; i++){
					mapname = mapname + " " + args[i];
				}
				mapname = mapname.substring(1);
				
				if(Map_DeathmatchUtils.existMap(mapname)){
					p.sendMessage(Settings.pr+Settings.wrn+"Die Deathmatch-Map existiert bereits!");
					return false;
				}
				
				if(Map_DeathmatchUtils.createMap(mapname)){
					p.sendMessage(Settings.pr+Settings.acpt+"Die Deathmatch-Map "+Settings.hlt+mapname+Settings.acpt+" wurde erstellt.");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Die Deathmatch-Map konnte nicht gespeichert werden!");
				}
			
			} else if(args[0].equalsIgnoreCase("edit")){
				if(editmap.containsKey(p)){
					p.sendMessage(Settings.pr+Settings.wrn+"Bevor du eine neue Deathmatch-Map bearbeiten willst, musst du den aktuellen �nderungs-Modus mit "+Settings.hlt+"/ktol end"+Settings.wrn+" verlassen!");
					return false;
				}
				
				String mapname = "";
				
				for(int i = 1; i < args.length; i++){
					mapname = mapname + " " + args[i];
				}
				mapname = mapname.substring(1);
				
				if(Map_DeathmatchUtils.existMap(mapname)){
					editmap.put(p, mapname);
					p.sendMessage(Settings.pr+Settings.acpt+"Du Bearbeitest nun die Map "+Settings.hlt+mapname+Settings.acpt+"!");
					p.sendMessage(Settings.pr+"Mit "+Settings.hlt+"/dm end"+Settings.co+" beendest du diesen Vorgang!");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Die Map existiert noch nicht!");
				}
			
			} else if(args[0].equalsIgnoreCase("setbuilder")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/dm edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
					return false;
				}
				
				String erbauer = "";
				
				for(int i = 1; i < args.length; i++){
					erbauer = erbauer + " " + args[i];
				}
				erbauer = erbauer.substring(1);
				
				if(Map_DeathmatchUtils.setBuilder(editmap.get(p), erbauer)){
					p.sendMessage(Settings.pr+Settings.acpt+"Der Erbauer von "+Settings.hlt+editmap.get(p)+Settings.acpt+" ist nun "+Settings.hlt+erbauer+Settings.acpt+".");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Die Map konnte nicht gespeichert werden!");
				}
			}
		} else {
			p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/dm help");
		}
		
		return false;
	}
	
}
