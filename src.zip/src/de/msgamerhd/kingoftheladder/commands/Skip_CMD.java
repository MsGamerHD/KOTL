package de.msgamerhd.kingoftheladder.commands;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.utils.GameUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Skip_CMD implements CommandExecutor{

	public static ArrayList<Player> skiped = new ArrayList<>();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;

		if(Main.status == GameStatus.SHOP){
			if(PlayerUtils.getTeam(p) != Team.SPIELENDER){
				p.sendMessage(Settings.pr+Settings.wrn+"Dieser Befehl ist nicht f�r Zuschauer!");
				return false;
			} else {
				if(skiped.contains(p)){
					p.sendMessage(Settings.pr+Settings.wrn+"Du hast diesen Befehl bereits ausgef�hrt!");
				} else {
					skiped.add(p);
					
					Bukkit.broadcastMessage(Settings.pr+"Der Spieler "+Settings.hlt+p.getName()+Settings.co+" hat daf�r gestimmt, die Wartezeit zu verk�rzen "+Settings.hlt+"("+skiped.size()+"/"+GameUtils.getPlayerCount()+")"+Settings.co+"! �o[/skip]");
					
					for(Player all : Bukkit.getOnlinePlayers()) all.playSound(all.getLocation(), Sound.NOTE_PLING, 1, 1);
				}
			}
		} else {
			p.sendMessage(Settings.pr+Settings.wrn+"Der Befehl kann nur in der Kauf-Phase benutzt werden!");
		}
		return false;
	}
	
}
