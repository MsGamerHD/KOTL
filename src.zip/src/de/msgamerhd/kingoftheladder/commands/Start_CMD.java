package de.msgamerhd.kingoftheladder.commands;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.countdowns.LobbyCountdown;
import de.msgamerhd.kingoftheladder.enums.GameStatus;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Start_CMD implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;
		
		if(!(p.hasPermission("game.start"))){
			p.sendMessage(Settings.perm);
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
			return false;
		}
		
		if(Main.status == GameStatus.LOBBY && LobbyCountdown.lobbycountdown > 13){
			int onlinecount = Bukkit.getOnlinePlayers().size();
			Settings.minplayers = 1;
			if(onlinecount >= Settings.minplayers){
				LobbyCountdown.lobbycountdown = 3;
				p.sendMessage(Settings.pr+Settings.hlt+"Die Wartezeit wurde verk�rzt!");
				p.playSound(p.getLocation(), Sound.NOTE_PLING, 1, 1);
			} else {
				p.sendMessage(Settings.pr+Settings.wrn+"Es "+(onlinecount == 1 ? "fehlt" : "fehlen")+" noch "+Settings.hlt+(Settings.minplayers-onlinecount)+Settings.wrn+" Spieler, damit das Spiel starten kann!");
				p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
			}
		} else {
			p.sendMessage(Settings.pr+Settings.wrn+"Die Wartezeit kann nicht mehr verk�rzt werden!");
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
		}
		
		return false;
	}
	
}
