package de.msgamerhd.kingoftheladder.commands;

import java.util.UUID;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.stats.Stats_Coins;
import de.msgamerhd.kingoftheladder.stats.Stats_Deaths;
import de.msgamerhd.kingoftheladder.stats.Stats_Kills;
import de.msgamerhd.kingoftheladder.stats.Stats_LastKit;
import de.msgamerhd.kingoftheladder.stats.Stats_LeavedGames;
import de.msgamerhd.kingoftheladder.stats.Stats_Name;
import de.msgamerhd.kingoftheladder.stats.Stats_PlayedGames;
import de.msgamerhd.kingoftheladder.stats.Stats_PowerUPs;
import de.msgamerhd.kingoftheladder.stats.Stats_RankingPoints;
import de.msgamerhd.kingoftheladder.stats.Stats_Wins;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Stats_CMD implements CommandExecutor{

	public static boolean configurationmode = false;
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		if(args.length == 1){
			sendStats(sender, args[0]);
		} else {
			sendStats(sender, sender.getName());
		}
		
		return false;
	}
	
	public static void sendStats(CommandSender sender, String from){
		UUID uuid = Stats_Name.getUUID(from);
		
		if(uuid != null){
			String symbol = "§f■ "+Settings.co;
			
			sender.sendMessage(Settings.pr+Settings.hlt+"Statistiken:");
			sender.sendMessage(Settings.pr+symbol+"Name: "+Settings.hlt+from);
			sender.sendMessage(Settings.pr+symbol+"Gespielte Spiele: "+Settings.hlt+Stats_PlayedGames.get(uuid));
			sender.sendMessage(Settings.pr+symbol+"Verlassene Spiele: "+Settings.hlt+Stats_LeavedGames.get(uuid));
			sender.sendMessage(Settings.pr+symbol+"Gewonnene Spiele: "+Settings.hlt+Stats_Wins.get(uuid));
			sender.sendMessage(Settings.pr+symbol+"Aufgesammelte Powerups: "+Settings.hlt+Stats_PowerUPs.get(uuid));

			int deaths = Stats_Deaths.get(uuid);
			int kills = Stats_Kills.get(uuid);
			sender.sendMessage(Settings.pr+symbol+"Kills: "+Settings.acpt+kills);
			sender.sendMessage(Settings.pr+symbol+"Tode: "+Settings.wrn+deaths);
			
			double kd = (double)kills / (double)(deaths == 0 ? 1 : deaths);

			if(Double.isNaN(kd)) kd = 0;
			kd = (int)(kd*100+0.5)/100.0;
			sender.sendMessage(Settings.pr+symbol+"K/D: "+Settings.hlt+kd);
			sender.sendMessage(Settings.pr+symbol+"Punkte: "+Settings.hlt+Stats_RankingPoints.get(uuid));
			sender.sendMessage(Settings.pr+symbol+"Coins: "+Settings.hlt+Stats_Coins.get(uuid));
			
			Kit lastkit = Stats_LastKit.get(uuid);
			sender.sendMessage(Settings.pr+symbol+"Letztes Kit: "+Settings.hlt+(lastkit == null ? "§cnoch keins" : lastkit.getName()));
		} else {
			sender.sendMessage(Settings.pr+Settings.wrn+"Der angegebene spieler hat noch nie KingOfTheLadder gespielt!");
		}
	}
	
}
