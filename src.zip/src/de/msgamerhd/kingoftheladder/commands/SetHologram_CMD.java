package de.msgamerhd.kingoftheladder.commands;

import java.io.File;
import java.io.IOException;

import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.FileManager;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class SetHologram_CMD  implements CommandExecutor{
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;
		
		if(!(p.hasPermission("game.configurate"))){
			p.sendMessage(Settings.perm);
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
			return false;
		}
		
		File file = FileManager.getDataFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		//fp <1/2/3> | /fp <holo> </1/2/3/4>
		if(args.length == 1){
			if(args[0].equalsIgnoreCase("1") || args[0].equalsIgnoreCase("2") || args[0].equalsIgnoreCase("3")){
				cfg.set("location.rank_"+args[0], p.getLocation());
				
				try {
					cfg.save(file);
					p.sendMessage(Settings.pr+Settings.acpt+"Du hast den Punkt f�r den Rank #"+Settings.hlt+args[0]+Settings.acpt+" erfolgreich gesetzt!");
				} catch (IOException e) {
					p.sendMessage(Settings.pr+Settings.wrn+"Der Standpunkt konnte nicht gesetzt werden!");
					e.printStackTrace();
				}
			} else {
				p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/fp <1/2/3> | /fp <holo> <1/2/3/4/5>");
			}
		} else if(args.length == 2){
			if(args[0].equalsIgnoreCase("holo")){
				if(args[1].equalsIgnoreCase("1") || args[1].equalsIgnoreCase("2") || args[1].equalsIgnoreCase("3") || args[1].equalsIgnoreCase("4") || args[1].equalsIgnoreCase("5")){
					cfg.set("location.hologram.rank_"+args[1], p.getLocation());
					
					try {
						cfg.save(file);
						p.sendMessage(Settings.pr+Settings.acpt+"Du hast den Hologram-Punkt f�r die ID #"+Settings.hlt+args[1]+Settings.acpt+" erfolgreich gesetzt!");
					} catch (IOException e) {
						p.sendMessage(Settings.pr+Settings.wrn+"Der Standpunkt konnte nicht gesetzt werden!");
						e.printStackTrace();
					}
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/fp <1/2/3> | /fp <holo> <1/2/3/4/5>");
				}
			} else {
				p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/fp <1/2/3> | /fp <holo> <1/2/3/4/5>");
			}
		} else {
			p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/fp <1/2/3> | /fp <holo> <1/2/3/4/5>");
		}
		
		return false;
	}
	
}
