package de.msgamerhd.kingoftheladder.commands;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.FileManager;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.MapUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class KOTL_CMD  implements CommandExecutor{
	
	public static HashMap<Player, String> editmap = new HashMap<>();
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;


		if(!(p.hasPermission("game.configurate"))){
			p.sendMessage(Settings.perm);
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
			return false;
		}
		
		if(args.length == 1){
			if(args[0].equalsIgnoreCase("maps")){
				p.sendMessage(Settings.pr+"Folgende Maps sind verf�gbar: "+Settings.hlt+MapUtils.getMaps());
			
			} else if(args[0].equalsIgnoreCase("setlobby")){
				p.sendMessage(Settings.pr+Settings.acpt+"Der Startpunkt f�r die Lobby wurde gesetzt.");

				File file = FileManager.getLocationFile();
				YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
				
				cfg.set("lobby", p.getLocation());
				try {
					cfg.save(file);
				} catch (IOException e) {
					e.printStackTrace();
				}
				
			} else if(args[0].equalsIgnoreCase("end")){
				if(!editmap.containsKey(p)){
					p.sendMessage(Settings.pr+Settings.wrn+"Du bearbeitest aktuell keine Map.");
					return false;
				}
				
				p.sendMessage(Settings.pr+Settings.acpt+"Das Bearbeiten der Map "+Settings.hlt+editmap.get(p)+Settings.acpt+" wurde erfolgreich beendet.");
				editmap.remove(p);
				
			} else if(args[0].equalsIgnoreCase("nextspawn")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/kotl edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
					return false;
				}
				
				p.sendMessage(Settings.pr+Settings.acpt+"Der Spawnpunkt mit der ID "+Settings.hlt+"#"+MapUtils.addSpawn(editmap.get(p), p.getLocation())+Settings.acpt+" wurde der Map "+editmap.get(p)+" hinzugef�gt.");
				
			} else if(args[0].equalsIgnoreCase("nextpowerup")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/kotl edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
					return false;
				}
				
				p.sendMessage(Settings.pr+Settings.acpt+"Ein Powerup mit der ID "+Settings.hlt+"#"+MapUtils.addPowerup(editmap.get(p), p.getLocation())+Settings.acpt+" wurde der Map "+editmap.get(p)+" hinzugef�gt.");
				
			} else if(args[0].equalsIgnoreCase("setgoal")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/kotl edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
					return false;
				}
				
				if(MapUtils.setGoal(editmap.get(p), p.getLocation())){
					p.sendMessage(Settings.pr+Settings.acpt+"Der Zielpunkt auf der Map "+Settings.hlt+editmap.get(p)+Settings.acpt+" wurde gesetzt.");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Der Zielpunkt der Map konnte nicht gespeichert werden!");
				}
				
			} else if(args[0].equalsIgnoreCase("inv")){
				Inventory inv = Bukkit.createInventory(null, 9, Settings.einrichten_invname);
				
				for(int i = 0; i < inv.getSize(); i++){
					inv.setItem(i, ItemUtils.getItem(Material.STAINED_GLASS_PANE, 1, 7, " ", null));
				}

				inv.setItem(2, ItemUtils.getItem(Material.NETHER_STAR, 1, 0, Settings.setspawn_itemname, "�7Hiermit f�gst du einen �bSpawnpunkt\n�7f�r die Spieler hinzu"));
				inv.setItem(4, ItemUtils.getItem(Material.EMERALD, 1, 0, Settings.addpowerup_itemname, "�7Hiermit f�gst du der Map ein\n�bPowerup �7hinzu"));
				inv.setItem(6, ItemUtils.getItem(Material.DIAMOND, 1, 0, Settings.setgoal_itemname, "�7Hiermit setzt du den Standpunkt\n�7f�r das Ziel"));
				
				p.openInventory(inv);
			
			} else if(args[0].equalsIgnoreCase("help")){
				p.sendMessage("�6>> �a�bersicht �6<<");
				p.sendMessage(Settings.hlt+"/kotl createmap <Mapname>");
				p.sendMessage(Settings.co+"Erstelle eine neue Map");
				
				p.sendMessage(Settings.hlt+"/kotl maps");
				p.sendMessage(Settings.co+"Zeigt dir eine Liste aller verf�gbaren Maps");
				
				p.sendMessage(Settings.hlt+"/kotl edit <Mapname>");
				p.sendMessage(Settings.co+"W�hle eine Map zur Bearbeitung aus");

				p.sendMessage(Settings.hlt+"/kotl nextspawn");
				p.sendMessage(Settings.co+"F�ge einen weiteren Spawnpunkt hinzu");
				
				p.sendMessage(Settings.hlt+"/kotl removespawn <ID>");
				p.sendMessage(Settings.co+"L�sche einen bereits gesetzten Spawnpunkt");

				p.sendMessage(Settings.hlt+"/kotl nextpowerup");
				p.sendMessage(Settings.co+"F�ge ein Powerup hinzu");
				
				p.sendMessage(Settings.hlt+"/kotl removepowerup");
				p.sendMessage(Settings.co+"L�sche ein bereits gesetztes Powerup");
				
				p.sendMessage(Settings.hlt+"/kotl setgoal");
				p.sendMessage(Settings.co+"Setze den Zielpunkt der Map");
				
				p.sendMessage(Settings.hlt+"/kotl setbuilder <Namen des Erbauers>");
				p.sendMessage(Settings.co+"Setze den Zielpunkt der Map");
				
				p.sendMessage(Settings.hlt+"/kotl inv");
				p.sendMessage(Settings.co+"�ffne das GUI zur vereinfachten bedienung");
			} else {
				p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/kotl help");
			}
		
		} else if(args.length >= 2){ 
			if(args.length == 2 && args[0].equalsIgnoreCase("removespawn")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/kotl edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
					return false;
				}
				
				try {
					int id = Integer.parseInt(args[1]);
					
					if(MapUtils.existSpawn(editmap.get(p), id)){
						MapUtils.removeSpawn(editmap.get(p), id);
						p.sendMessage(Settings.pr+Settings.acpt+"Der Spawnpunkt "+Settings.hlt+"#"+id+Settings.acpt+" wurde erfolgreich gel�scht.");
					} else {
						p.sendMessage(Settings.pr+Settings.wrn+"Der angegeben Spawnpunkt existiert nicht.");
					}
				} catch (NumberFormatException e) {
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte gebe eine korrekte ID an!");
				}
			} else if(args.length == 2 && args[0].equalsIgnoreCase("removepowerup")){
					if(!(editmap.containsKey(p))){
						p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/kotl edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
						return false;
					}
					
					try {
						int id = Integer.parseInt(args[1]);
						
						if(MapUtils.existPowerup(editmap.get(p), id)){
							MapUtils.removePowerup(editmap.get(p), id);
							p.sendMessage(Settings.pr+Settings.acpt+"Das Powerup "+Settings.hlt+"#"+id+Settings.acpt+" wurde erfolgreich gel�scht.");
						} else {
							p.sendMessage(Settings.pr+Settings.wrn+"Ein Powerup mit der angegeben ID existiert nicht.");
						}
					} catch (NumberFormatException e) {
						p.sendMessage(Settings.pr+Settings.wrn+"Bitte gebe eine korrekte ID an!");
					}
				}
			
			if(args[0].equalsIgnoreCase("createmap")){
				if(editmap.containsKey(p)){
					p.sendMessage(Settings.pr+Settings.wrn+"Bevor du eine neue Map erstellen willst, musst du den aktuellen �nderungs-Modus mit "+Settings.hlt+"/ktol end"+Settings.wrn+" verlassen!");
					return false;
				}
				
				String mapname = "";
				
				for(int i = 1; i < args.length; i++){
					mapname = mapname + " " + args[i];
				}
				mapname = mapname.substring(1);
				
				if(MapUtils.existMap(mapname)){
					p.sendMessage(Settings.pr+Settings.wrn+"Die Map existiert bereits!");
					return false;
				}
				
				if(MapUtils.createMap(mapname)){
					p.sendMessage(Settings.pr+Settings.acpt+"Die Map "+Settings.hlt+mapname+Settings.acpt+" wurde erstellt.");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Die Map konnte nicht gespeichert werden!");
				}
			
			} else if(args[0].equalsIgnoreCase("edit")){
				if(editmap.containsKey(p)){
					p.sendMessage(Settings.pr+Settings.wrn+"Bevor du eine neue Map bearbeiten willst, musst du den aktuellen �nderungs-Modus mit "+Settings.hlt+"/ktol end"+Settings.wrn+" verlassen!");
					return false;
				}
				
				String mapname = "";
				
				for(int i = 1; i < args.length; i++){
					mapname = mapname + " " + args[i];
				}
				mapname = mapname.substring(1);
				
				if(MapUtils.existMap(mapname)){
					editmap.put(p, mapname);
					p.sendMessage(Settings.pr+Settings.acpt+"Du Bearbeitest nun die Map "+Settings.hlt+mapname+Settings.acpt+"!");
					p.sendMessage(Settings.pr+"Mit "+Settings.hlt+"/kotl end"+Settings.co+" beendest du diesen Vorgang!");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Die Map existiert noch nicht!");
				}
			
			} else if(args[0].equalsIgnoreCase("setbuilder")){
				if(!(editmap.containsKey(p))){
					p.sendMessage(Settings.pr+Settings.wrn+"Bitte trage dich erst mit "+Settings.hlt+"/kotl edit <Map>"+Settings.wrn+" zur Bearbeitung einer Map ein.");
					return false;
				}
				
				String erbauer = "";
				
				for(int i = 1; i < args.length; i++){
					erbauer = erbauer + " " + args[i];
				}
				erbauer = erbauer.substring(1);
				
				if(MapUtils.setBuilder(editmap.get(p), erbauer)){
					p.sendMessage(Settings.pr+Settings.acpt+"Der Erbauer von "+Settings.hlt+editmap.get(p)+Settings.acpt+" ist nun "+Settings.hlt+erbauer+Settings.acpt+".");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Die Map konnte nicht gespeichert werden!");
				}
			}
		} else {
			p.sendMessage(Settings.pr+Settings.wrn+"Bitte benutze "+Settings.hlt+"/kotl help");
		}
		
		return false;
	}
	
}
