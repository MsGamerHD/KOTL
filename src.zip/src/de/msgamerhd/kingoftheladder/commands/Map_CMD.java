package de.msgamerhd.kingoftheladder.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Map_CMD implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;
		p.sendMessage(Settings.pr+"Map: "+Settings.hlt+Main.map+Settings.co+" | Deathmatch-Map: "+Settings.hlt+Main.dmmap);
		
		return false;
	}
	
}