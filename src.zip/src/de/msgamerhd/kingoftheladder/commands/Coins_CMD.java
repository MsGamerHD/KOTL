package de.msgamerhd.kingoftheladder.commands;

import java.util.UUID;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.stats.Stats_Coins;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Coins_CMD implements CommandExecutor{

	public static boolean configurationmode = false;
	
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg2, String[] args) {
		if(!(sender instanceof Player)){
			sender.sendMessage("Du musst ein Spieler sein!");
			return false;
		}
		
		Player p = (Player) sender;
		
		UUID uuid = p.getUniqueId();
		p.sendMessage(Settings.pr+"Deine Coins: "+Settings.hlt+Stats_Coins.get(uuid));
		
		Stats_Coins.add(p.getUniqueId(), 2500, true, true);
		
		return false;
	}
}
