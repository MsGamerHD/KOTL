package de.msgamerhd.kingoftheladder;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;

import de.msgamerhd.kingoftheladder.commands.Coins_CMD;
import de.msgamerhd.kingoftheladder.commands.DM_CMD;
import de.msgamerhd.kingoftheladder.commands.Einrichten_CMD;
import de.msgamerhd.kingoftheladder.commands.Fix_CMD;
import de.msgamerhd.kingoftheladder.commands.KOTL_CMD;
import de.msgamerhd.kingoftheladder.commands.Map_CMD;
import de.msgamerhd.kingoftheladder.commands.SetHologram_CMD;
import de.msgamerhd.kingoftheladder.commands.Skip_CMD;
import de.msgamerhd.kingoftheladder.commands.Start_CMD;
import de.msgamerhd.kingoftheladder.commands.Stats_CMD;
import de.msgamerhd.kingoftheladder.countdowns.LobbyCountdown;
import de.msgamerhd.kingoftheladder.countdowns.OtherRunnables;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.events.OtherListeners;
import de.msgamerhd.kingoftheladder.events.DeathListener;
import de.msgamerhd.kingoftheladder.events.ItemInteractListener;
import de.msgamerhd.kingoftheladder.events.InventoryListener;
import de.msgamerhd.kingoftheladder.events.JoinListener;
import de.msgamerhd.kingoftheladder.events.LeaveListener;
import de.msgamerhd.kingoftheladder.events.MoveListener;
import de.msgamerhd.kingoftheladder.events.WorldResetListener;
import de.msgamerhd.kingoftheladder.kits.KitSkillListener;
import de.msgamerhd.kingoftheladder.kits.KitUtils;
import de.msgamerhd.kingoftheladder.powerups.PickupPowerupListener;
import de.msgamerhd.kingoftheladder.powerups.SpecialItemsListener;
import de.msgamerhd.kingoftheladder.shop.Shop_InventoryListener;
import de.msgamerhd.kingoftheladder.stats.AchievementUtils;
import de.msgamerhd.kingoftheladder.stats.Stats_Coins;
import de.msgamerhd.kingoftheladder.stats.Stats_Deaths;
import de.msgamerhd.kingoftheladder.stats.Stats_Kills;
import de.msgamerhd.kingoftheladder.stats.Stats_LastKit;
import de.msgamerhd.kingoftheladder.stats.Stats_LeavedGames;
import de.msgamerhd.kingoftheladder.stats.Stats_PlayedGames;
import de.msgamerhd.kingoftheladder.stats.Stats_PowerUPs;
import de.msgamerhd.kingoftheladder.stats.Stats_RankingPoints;
import de.msgamerhd.kingoftheladder.stats.Stats_Wins;
import de.msgamerhd.kingoftheladder.utils.Map_DeathmatchUtils;
import de.msgamerhd.kingoftheladder.utils.MySQL;
import de.msgamerhd.kingoftheladder.utils.HologramUtils;
import de.msgamerhd.kingoftheladder.utils.MapUtils;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Main extends JavaPlugin {
	
	public static Main main;
	
	public static GameStatus status = GameStatus.LOBBY;

	public static String map;
	public static String dmmap;
	
	public static Inventory changemap_inv = null;
	public static Inventory changedmmap_inv = null;
	
	@Override
	public void onEnable() {
		main = this;
		
		ScoreboardUtils.resetScoreboardAll();
		map = MapUtils.getRandomMap();
		dmmap = Map_DeathmatchUtils.getRandomMap();
		
		//Commands
		getCommand("start").setExecutor(new Start_CMD());
		getCommand("map").setExecutor(new Map_CMD());
		getCommand("kotl").setExecutor(new KOTL_CMD());
		getCommand("einrichten").setExecutor(new Einrichten_CMD());
		getCommand("fix").setExecutor(new Fix_CMD());
		getCommand("skip").setExecutor(new Skip_CMD());
		getCommand("dm").setExecutor(new DM_CMD());
		getCommand("stats").setExecutor(new Stats_CMD());
		getCommand("setholo").setExecutor(new SetHologram_CMD());
		getCommand("coins").setExecutor(new Coins_CMD());
		
		//Events
		Bukkit.getPluginManager().registerEvents(new JoinListener(), this);
		Bukkit.getPluginManager().registerEvents(new LeaveListener(), this);
		Bukkit.getPluginManager().registerEvents(new InventoryListener(), this);
		Bukkit.getPluginManager().registerEvents(new ItemInteractListener(), this);
		Bukkit.getPluginManager().registerEvents(new MoveListener(), this);
		Bukkit.getPluginManager().registerEvents(new WorldResetListener(), this);
		Bukkit.getPluginManager().registerEvents(new OtherListeners(), this);
		Bukkit.getPluginManager().registerEvents(new DeathListener(), this);
		Bukkit.getPluginManager().registerEvents(new SpecialItemsListener(), this);
		Bukkit.getPluginManager().registerEvents(new PickupPowerupListener(), this);
		Bukkit.getPluginManager().registerEvents(new Shop_InventoryListener(), this);
		Bukkit.getPluginManager().registerEvents(new KitSkillListener(), this);
		
		LobbyCountdown.startCountdown();
		OtherRunnables.startFreezeRunnable();
		OtherRunnables.startRunnableForEverySecond();
		
		MySQL.connect();
		
		MySQL.update("CREATE TABLE IF NOT EXISTS "+Settings.stats_tabelname+" (UUID VARCHAR(100),name VARCHAR(100),last_kit_id INT(100),kills INT(100),deaths INT(100),played_games INT(100),leaved_games INT(100),wins INT(100),points INT(100),picked_powerups INT(100),coins INT(100))");
		MySQL.update("CREATE TABLE IF NOT EXISTS "+Settings.achievements_tabelname+" (UUID VARCHAR(100),achievements VARCHAR(100))");
		MySQL.update("CREATE TABLE IF NOT EXISTS "+Settings.kits_tabelname+" (UUID VARCHAR(100),kits VARCHAR(100))");
	}
	
	@Override
	public void onDisable() {
		syncAllWithMySQL();
		MySQL.close();
		
		for(Player all : Bukkit.getOnlinePlayers()){
			HologramUtils.removeHolos(all);
		}
	}
	
	public static void syncAllWithMySQL(){
		Stats_Kills.syncWithMySQL();
		Stats_Deaths.syncWithMySQL();
		Stats_PlayedGames.syncWithMySQL();
		Stats_LeavedGames.syncWithMySQL();
		Stats_RankingPoints.syncWithMySQL();
		Stats_Wins.syncWithMySQL();
		Stats_PowerUPs.syncWithMySQL();
		AchievementUtils.syncWithMySQL();
		Stats_LastKit.syncWithMySQL();
		KitUtils.syncWithMySQL();
		Stats_Coins.syncWithMySQL();
	}
	
	public static Main getInstance(){
		return main;
	}
	
}