package de.msgamerhd.kingoftheladder.kits;

import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.Potion;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

public class KitSkillUtils {

	public static HashMap<Player, Integer> freezelist = new HashMap<>();
	public static ArrayList<Player> iswaiting = new ArrayList<>();
	
	public static void setKitEffectAndItem(Player p){
		if(KitUtils.pkits.containsKey(p)){
			Kit kit = KitUtils.pkits.get(p);
			
			p.getInventory().setItem(Settings.kititemslot, null);

			if(kit == Kit.BARBAR){
				p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 99999999, 2));
				p.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 99999999, 0));
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.WOOD_SWORD, 1, 0, "�7Schwert", null, true));
			} else if(kit == Kit.BOMBER){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.TNT, 1, 0, "�cTNT", null));
			} else if(kit == Kit.DIEB){
				ItemStack item = ItemUtils.getItem(Material.GOLD_INGOT, 1, 0, "�6Goldklumpen", null);
				item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
				p.getInventory().setItem(Settings.kititemslot, item);
			} else if(kit == Kit.ENDERMAN){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.ENDER_PEARL, 1, 0, "�3Enderperle", null));
			} else if(kit == Kit.PYROTECHNIKER){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.FIREBALL, 1, 0, "�6Feuerattacke", null));
			} else if(kit == Kit.HEXE){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.BREWING_STAND_ITEM, 1, 0, "�4Sch�dlicher Trank �7�o(Rechtsklick)", null));
			} else if(kit == Kit.KOBOLD){
				ItemStack item = ItemUtils.getItem(Material.STICK, 1, 0, "�aKobold-Speer", null);
				item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 1);
				item.addUnsafeEnchantment(Enchantment.KNOCKBACK, 2);
				p.getInventory().setItem(Settings.kititemslot, item);
			} else if(kit == Kit.SCHNEEMANN){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.SNOW_BALL, 1, 0, "�f�lSchneeball", null));
			} else if(kit == Kit.GOLEM){
				p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 99999999, 3));
				p.getInventory().setLeggings(ItemUtils.getItem(Material.DIAMOND_LEGGINGS, 1, 0, "�bDiamanthose", null, true));
				p.getInventory().setBoots(ItemUtils.getItem(Material.DIAMOND_BOOTS, 1, 0, "�bDiamantschuhe", null, true));
			} else if(kit == Kit.RENNER){
				p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 99999999, 2));
			} else if(kit == Kit.SCHLANGE){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.INK_SACK, 1, 10, "�aGift", null));
			} else if(kit == Kit.SPRINGER){
				p.setAllowFlight(true);
				p.setFlying(false);
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.FEATHER, 1, 0, "�7Doppelsprung �o(2x Leertaste)", null));
			} else if(kit == Kit.TINTENFISCH){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.INK_SACK, 1, 0, "�9Tintenklecks", null));
			} else if(kit == Kit.ZAUBERER){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.BLAZE_ROD, 1, 0, "�bZauberstab", null));
			} else if(kit == Kit.HEILER){
				p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.APPLE, 1, 0, "�cHeilapfel", null));
			}
		}
	}
	
	public static void wait(Player p, int seconds){
		if(!iswaiting.contains(p) && Main.status == GameStatus.INGAME){
			iswaiting.add(p);
			
			new BukkitRunnable() {
				
				int counter = seconds;
				
				@Override
				public void run() {
					if(Main.status != GameStatus.INGAME || !iswaiting.contains(p)){
						cancel();
						return;
					}
					if(p.isOnline() && PlayerUtils.getTeam(p) == Team.SPIELENDER){
						if(counter <= 0){
							cancel();
							setKitEffectAndItem(p);
							iswaiting.remove(p);
							p.playSound(p.getLocation(), Sound.ANVIL_LAND, 1, 1);
						} else {
							p.getInventory().setItem(Settings.kititemslot, ItemUtils.getItem(Material.FIREWORK_CHARGE, 1, 0, "�7Warte noch �b"+counter+(counter == 1 ? " Sekunde" : " Sekunden"), null));
						}
					} else {
						cancel();
						iswaiting.remove(p);
					}
					counter-=1;
				}
			}.runTaskTimer(Main.getInstance(), 0, 20);
		}
	}
	
	public static void useSkill(Player p){
		Kit kit = KitUtils.pkits.get(p);
		
		if(kit != null && Main.status == GameStatus.INGAME && !iswaiting.contains(p)){
			if(kit == Kit.BOMBER){
				throwTNT(p);
				wait(p, 18);
			} else if(kit == Kit.ENDERMAN){
				p.launchProjectile(EnderPearl.class);
				wait(p, 8);
			} else if(kit == Kit.PYROTECHNIKER){
				useFire(p);
				wait(p, 16);
			} else if(kit == Kit.HEXE){
				throwRandomPotion(p);
				wait(p, 16);
			} else if(kit == Kit.SCHNEEMANN){
				p.launchProjectile(Snowball.class);
				wait(p, 14);
			} else if(kit == Kit.SCHLANGE){
				throwPotion(p, PotionType.POISON, 2);
				wait(p, 16);
			} else if(kit == Kit.TINTENFISCH){
				for(Player all : Bukkit.getOnlinePlayers()){
					if(all != p){
						all.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 5*20, 2));
						all.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 5*20, 2));
					}
				}
				wait(p, 16);
			} else if(kit == Kit.ZAUBERER){
				throwItem(p, ItemUtils.getItem(Material.BLAZE_ROD, 1, 0, p.getName(), null), true, false, Effect.FLYING_GLYPH, Sound.LAVA_POP);
				wait(p, 16);
			} else if(kit == Kit.HEILER){
				p.setHealth(p.getMaxHealth());
				p.getWorld().spigot().playEffect(p.getLocation(), Effect.HEART, 0, 0, 1, 1, 1, 0, 20, 50);
				p.playSound(p.getLocation(), Sound.IRONGOLEM_THROW, 1, 1);
				wait(p, 22);
			}
		}
	}
	
	public static void throwRandomPotion(Player p){
		throwPotion(p, PotionType.POISON, 1);
	}
	
	public static void throwPotion(Player p, PotionType effect, int level){
		Potion potion = new Potion(effect, level);
		potion.setSplash(true);
		 
		ItemStack is = new ItemStack(Material.POTION);
		potion.apply(is);
		 
		ThrownPotion thrownPotion = p.launchProjectile(ThrownPotion.class);
		thrownPotion.setItem(is);
	}
	
	public static void useFire(Player p){
		ItemStack pitem = p.getItemInHand();
		if(pitem.getAmount() > 1){
			pitem.setAmount((pitem.getAmount()-1));
		} else {
			p.setItemInHand(new ItemStack(Material.AIR));
		}
		
		for(Entity around : p.getNearbyEntities(4, 3, 4)){
			if(around instanceof Player){
				around.setFireTicks((int) 6*20);
			}
		}
		
		p.getWorld().spigot().playEffect(p.getLocation(), Effect.MOBSPAWNER_FLAMES, 0, 0, 3, 2, 3, 0, 40, 20);
		p.getWorld().spigot().playEffect(p.getLocation(), Effect.LAVA_POP, 0, 0, 2, 1, 2, 0, 30, 20);
	}
	


	public static void freeze(Player p, int seconds){
		freezelist.put(p, seconds*4);
	}
	
	@SuppressWarnings("deprecation")
	public static void useEarthquake(Player p){
		int radius = 3;
		
		for(Entity all : p.getNearbyEntities(radius, radius, radius)){
			if(all instanceof Player){
				if(all != p){
	                Vector vectora = all.getLocation().toVector();
	                Vector vectorp = p.getLocation().toVector();
	                Vector v = vectora.clone().subtract(vectorp).multiply(1.8/vectora.distance(vectorp));
	                v.setY(0.7);
	                all.setVelocity(v);
				}
			}
		}
		
		Location loc1 = p.getLocation().clone();
		loc1.add(radius, 1, radius);
		
		Location loc2 = p.getLocation().clone();
		loc2.subtract(radius, 1, radius);

		for(int x = Integer.min((int) loc1.getX(), (int) loc2.getX()); x < Integer.max((int) loc1.getX(), (int) loc2.getX()); x++){
			for(int y = Integer.min((int) loc1.getY(), (int) loc2.getY()); y < Integer.max((int) loc1.getY(), (int) loc2.getY()); y++){
				for(int z = Integer.min((int) loc1.getZ(), (int) loc2.getZ()); z < Integer.max((int) loc1.getZ(), (int) loc2.getZ()); z++){
					Location effectloc = new Location(loc1.getWorld(), x, y, z);
					
					if(effectloc.getBlock().getType() != Material.AIR){
						p.getWorld().playEffect(effectloc, Effect.STEP_SOUND, effectloc.getBlock().getTypeId(), 10);
					}
				}
			}
		}
	}
	
	public static void throwTNT(Player p){
		TNTPrimed tnt = (TNTPrimed) p.getWorld().spawnEntity(p.getEyeLocation(), EntityType.PRIMED_TNT);
		tnt.setVelocity(p.getEyeLocation().getDirection().multiply(2.1).normalize());
		tnt.setFuseTicks(4*20);
	}
	
	public static void throwItem(Player p, ItemStack is, boolean removeOnGround, boolean getBackOnGround, Effect effect, Sound sound){
		Item item = p.getWorld().dropItem(p.getEyeLocation(), is);
		item.setVelocity(p.getEyeLocation().getDirection().multiply(1.8).normalize());
		item.setPickupDelay(0);
		
		if(removeOnGround){
			new BukkitRunnable() {
				
				@Override
				public void run() {
					if(!p.isOnline()){
						cancel();
						item.remove();
						return;
					}
					if(item != null){
						if(item.isDead()){
							cancel();
						} else if(item.isOnGround()){
							if(getBackOnGround){
								iswaiting.remove(p);
								setKitEffectAndItem(p);
								p.playSound(p.getLocation(), Sound.ITEM_PICKUP, 1, 1);
							}
							
							cancel();
							item.remove();
						} else {
							if(effect != null){
								item.getWorld().spigot().playEffect(item.getLocation(), effect, 0, 0, 0, 0, 0, 0, 10, 100);
							}
							if(sound != null){
								for(Player all : Bukkit.getOnlinePlayers()){
									all.playSound(item.getLocation(), sound, 1, 1);
								}
							}
						}
					}
				}
			}.runTaskTimer(Main.getInstance(), 1, 1);
		}
	}
}
