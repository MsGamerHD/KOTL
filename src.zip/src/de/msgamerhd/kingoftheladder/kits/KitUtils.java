package de.msgamerhd.kingoftheladder.kits;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.stats.Stats_Coins;
import de.msgamerhd.kingoftheladder.stats.Stats_LastKit;
import de.msgamerhd.kingoftheladder.stats.Stats_RankingPoints;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.MySQL;
import de.msgamerhd.kingoftheladder.utils.ScoreboardUtils;

/**
 * Class created by MsGamerHD on 09.10.2016
 */
public class KitUtils {

	public static String column = "kits";

	public static HashMap<UUID, String> kitlist = new HashMap<>();
	//F�r das ausgew�hlte Kit
	public static HashMap<Player, Kit> pkits = new HashMap<>();
	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.kits_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static void syncWithMySQL(){
		for(UUID uuid : kitlist.keySet()){
			if(existPlayer(uuid)){
				MySQL.update("UPDATE "+Settings.kits_tabelname+" SET "+column+" = '"+kitlist.get(uuid)+"' WHERE UUID = '"+uuid+"'");
			} else {
				MySQL.update("INSERT INTO "+Settings.kits_tabelname+" (UUID,"+column+") VALUES ('"+uuid.toString()+"','"+kitlist.get(uuid)+"')");
			}
		}
	}
	
	public static void loadKits(Player p){
		UUID uuid = p.getUniqueId();

		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.kits_tabelname+" WHERE UUID = '"+uuid+"'");
			if(rs.next()){
				if(rs.getString(column) != null){
					kitlist.put(uuid, rs.getString(column));
					return;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		kitlist.put(uuid, "");
	}
	
	public static int hasKit(Player p, Kit kit){
		if(kit.getCost() <= 0 || p.hasPermission("game.unlockkits")){
			return 1;
		}
		
		UUID uuid = p.getUniqueId();
		
		if(!kitlist.containsKey(uuid)){
			loadKits(p);
		}
		
		String allachs = kitlist.get(uuid);
		if(allachs.contains(",")){
			String[] achsplited = allachs.split(",");

			for(String all : achsplited){
				if(all.contains(":")){
					String[] statusplited = all.split(":");

					if(statusplited[0].equalsIgnoreCase("#"+kit.getID())){
						try {
							int status = Integer.parseInt(statusplited[1]);
							if(status == 1 || status == 0) return status;
						} catch (Exception e) {
							p.sendMessage(Settings.pr+Settings.wrn+"Ein Fehler beim Laden deiner Kits ist aufgetreten!");
						}
					}
				}
			}
		} else {
			if(allachs.contains(":")){
				String[] statusplited = allachs.split(":");

				if(statusplited[0].equalsIgnoreCase("#"+kit.getID())){
					try {
						int status = Integer.parseInt(statusplited[1]);
						if(status == 1 || status == 0) return status;
					} catch (Exception e) {
						p.sendMessage(Settings.pr+Settings.wrn+"Ein Fehler beim Laden deiner Errungenschaften ist aufgetreten!");
					}
				}
			}
		}
		return 0;
	}
	
	public static void setKit(Player p, Kit kit, boolean status){
		UUID uuid = p.getUniqueId();
		
		int statusid = (status ? 1 : 0);
		
		if(!kitlist.containsKey(uuid)){
			loadKits(p);
		}
		
		String playerachs = kitlist.get(uuid);
		
		if(playerachs.contains("#"+kit.getID()+":0")){
			playerachs.replaceFirst("#"+kit.getID()+":0", "#"+kit.getID()+":"+statusid);
			
		} else if(playerachs.contains("#"+kit.getID()+":1")){
			playerachs.replaceFirst("#"+kit.getID()+":1", "#"+kit.getID()+":"+statusid);
		
		} else {
			if(playerachs.equals("")){
				playerachs = "#"+kit.getID()+":"+statusid;
			} else {
				playerachs = playerachs+",#"+kit.getID()+":"+statusid;
			}
		}
		
		kitlist.put(uuid, playerachs);
	}
	
	
	public static void openKitInventory(Player p){
		//autom. inventar gr��e
		int invsize = 3*9;
		for(int i = 0; i < 3; i++){
			if(Kit.values().length > i*9) {
				invsize = (i*9)+(3*9);
			}
		}
		
		Inventory inv = Bukkit.createInventory(null, invsize, Settings.kit_itemname);
		
		for(int i = 0; i < inv.getSize(); i++) inv.setItem(i, ItemUtils.getItem(Material.STAINED_GLASS_PANE, 1, 7, " ", null));
		
		//sortieren: erst die gekauften
		ArrayList<Kit> kitlist = new ArrayList<>();
		for(Kit kit : Kit.values()) if(hasKit(p, kit) == 1) kitlist.add(kit);
		for(Kit kit : Kit.values()) if(hasKit(p, kit) != 1) kitlist.add(kit);

		int slot = 9;
		for(Kit kit : kitlist){
			String lore = "�r\n"
					+(hasKit(p, kit) == 1 ? "�6>> �aim Besitz\n" : "�6>> �cnicht im Besitz"
					+ "\n")
					+ "\n�r"+kit.getDescription();
			inv.setItem(slot, ItemUtils.getItem(kit.getType(), 1, 0, (hasKit(p, kit) == 1 ? "�a"+kit.getName() : "�c"+kit.getName()+" �7(�b"+kit.getCost()+" �7Coins)"), lore));
			slot+=1;
		}
		
		p.openInventory(inv);
	}
	
	public static void chooseKit(Player p, Kit kit){
		if(hasKit(p, kit) != 1){
			openBuyInv(p, kit);
			return;
		}
		
		ScoreboardUtils.setKit(p, kit);
		
		p.sendMessage(Settings.pr+"Du hast das Kit "+Settings.hlt+kit.getName()+Settings.co+" ausgew�hlt.");
		p.playSound(p.getLocation(), Sound.NOTE_PLING, 1, 1);
		p.closeInventory();
		pkits.put(p, kit);
		Stats_LastKit.set(p.getUniqueId(), kit);
	}
	
	public static void buyKit(Player p, Kit kit){
		if(hasKit(p, kit) == 1){
			p.sendMessage(Settings.pr+Settings.wrn+"Du bist bereits im Besitz dieses Kits!");
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
			p.closeInventory();
			return;
		}
		if(Stats_Coins.get(p.getUniqueId()) >= kit.getCost()){
			((CraftPlayer)p).sendTitle(Settings.hlt+kit.getName(), Settings.acpt+"Du hast das Kit gekauft!");
			p.playSound(p.getLocation(), Sound.LEVEL_UP, 1, 1);
			setKit(p, kit, true);
			chooseKit(p, kit);
			Stats_Coins.remove(p.getUniqueId(), kit.getCost());
			Stats_RankingPoints.add(p.getUniqueId(), 4, true);
		} else {
			int need = kit.getCost()-Stats_Coins.get(p.getUniqueId());
			
			p.sendMessage(Settings.pr+Settings.wrn+"Dir "+(need == 1 ? "fehlt" : "fehlen")+" noch "+Settings.hlt+need+(need == 1 ? " Coin" : " Coins")+"!");
			p.playSound(p.getLocation(), Sound.NOTE_BASS_DRUM, 1, 1);
		}
	}
	
	public static void openBuyInv(Player p, Kit kit){
		if(kit != null){
			Inventory inv = Bukkit.createInventory(null, 9, Settings.buykit_invname);
			
			for(int i = 0; i < inv.getSize(); i++) inv.setItem(i, ItemUtils.getItem(Material.STAINED_GLASS_PANE, 1, 7, " ", null));
			
			inv.setItem(1, ItemUtils.getItem(Material.EMERALD, 1, 0, "�aF�r "+kit.getCost()+" Coins kaufen", "�7Klicke, um den Kauf abzuschlie�en"));
			inv.setItem(4, ItemUtils.getItem(kit.getType(), 1, 0, "�a"+kit.getName(), "�r\n�6>> �7Kosten: �b"+kit.getCost()+"\n�r\n"+kit.getDescription()));
			inv.setItem(7, ItemUtils.getItem(Material.REDSTONE, 1, 0, "�cAbbrechen", "�7Klicke, um den Kauf abzubrechen"));
			
			p.openInventory(inv);
		}
	}
	
}
