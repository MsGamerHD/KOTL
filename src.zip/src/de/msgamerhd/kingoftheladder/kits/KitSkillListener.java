package de.msgamerhd.kingoftheladder.kits;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.ItemStack;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class KitSkillListener implements Listener {

	public static HashMap<Player, Integer> currentslotlist = new HashMap<>();
	
	@EventHandler
	public void on(PlayerItemHeldEvent e){
		Player p = e.getPlayer();
		
		currentslotlist.put(p, e.getNewSlot());
	}
	
	@EventHandler
	public void on(PlayerInteractEvent e){
		Player p = e.getPlayer();
		
		if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK){
			int slot = 0;
			if(currentslotlist.containsKey(p)) slot = currentslotlist.get(p);
			
			if(slot == Settings.kititemslot && Main.status == GameStatus.INGAME){
				e.setCancelled(true);
				
				if(KitUtils.pkits.containsKey(p)){
					Kit kit = KitUtils.pkits.get(p);
					if(kit == Kit.SPRINGER) return;
				}
				KitSkillUtils.useSkill(p);
			}
		}
	}
	
	@EventHandler
	public void on(EntityDamageEvent e){
		if(e.getEntity() instanceof Player){
			Player p = (Player) e.getEntity();
			if(KitUtils.pkits.containsKey(p)){
				Kit kit = KitUtils.pkits.get(p);
				
				if(kit == Kit.BOMBER){
					if(e.getCause() == DamageCause.BLOCK_EXPLOSION || e.getCause() == DamageCause.ENTITY_EXPLOSION){
						e.setCancelled(true);
					}
				}
				
				if(kit == Kit.PYROTECHNIKER){
					if(e.getCause() == DamageCause.FIRE || e.getCause() == DamageCause.FIRE_TICK || e.getCause() == DamageCause.LAVA){
						e.setCancelled(true);
					}
				}
				
				if(kit == Kit.SPRINGER){
					if(e.getCause() == DamageCause.FALL){
						e.setCancelled(true);
					}
				}
				
				if(kit == Kit.HEXE){
					if(e.getCause() == DamageCause.POISON || e.getCause() == DamageCause.MAGIC){
						e.setCancelled(true);
					}
				}
				
				if(kit == Kit.SCHLANGE){
					if(e.getCause() == DamageCause.POISON){
						e.setCancelled(true);
					}
				}
			}
			
		}
	}
	
	@EventHandler
	public void on(EntityDamageByEntityEvent e){
		if(e.getEntity() instanceof Player && e.getDamager() instanceof Snowball){
			Player p = (Player) e.getEntity();
			Snowball snowball = (Snowball) e.getDamager();
			
			if(snowball.getShooter() instanceof Player){
				Player shooter = (Player) snowball.getShooter();
				
				if(KitUtils.pkits.containsKey(shooter)){
					if(KitUtils.pkits.get(shooter) == Kit.SCHNEEMANN){
						p.sendMessage(Settings.pr+"Der §f☃  "+shooter.getName()+Settings.co+" hat dich eingefrohren.");
						KitSkillUtils.freeze(p, 3);
					}
				}
			}
		}
	}
	
	@EventHandler
	public void on(PlayerToggleFlightEvent e){
		Player p = e.getPlayer();
		
		if(e.isFlying()){
			if(KitUtils.pkits.containsKey(p)){
				if(KitUtils.pkits.get(p) == Kit.SPRINGER){
					p.setAllowFlight(false);
					p.setVelocity(p.getLocation().getDirection().multiply(1.8));
					p.playSound(p.getLocation(), Sound.ENDERDRAGON_WINGS, 1, 1);
					
					KitSkillUtils.wait(p, 6);
				}
			}
		}
	}
	
	@EventHandler
	public void on(PlayerPickupItemEvent e){
		Player p = e.getPlayer();
		
		if(Main.status == GameStatus.INGAME){
			ItemStack is = e.getItem().getItemStack();
			
			if(is.getItemMeta() != null){
				String name = is.getItemMeta().getDisplayName();
				if(name != null){
					if(!name.equals(p.getName())){
						if(PlayerUtils.getTeam(p) == Team.SPIELENDER){
							e.setCancelled(true);
							e.getItem().remove();
							
							Player a = Bukkit.getPlayer(name);
							if(a != null){
								Location ploc = p.getLocation();
								Location aloc = a.getLocation();
								
								ploc.getWorld().spigot().playEffect(ploc, Effect.LARGE_SMOKE, 0, 0, 1, 1, 1, 0, 70, 50);
								aloc.getWorld().spigot().playEffect(aloc, Effect.LARGE_SMOKE, 0, 0, 1, 1, 1, 0, 70, 50);
							
								p.teleport(aloc);
								a.teleport(ploc);
							}
						}
					}
				}
			}
		}
	}
}
