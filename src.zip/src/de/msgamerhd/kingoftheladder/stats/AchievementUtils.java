package de.msgamerhd.kingoftheladder.stats;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.ChatAPI;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.MySQL;

/**
 * Class created by MsGamerHD on 07.10.2016
 */
public class AchievementUtils {

	public static String column = "achievements";

	public static HashMap<UUID, String> achs = new HashMap<>();
	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.achievements_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static void syncWithMySQL(){
		for(UUID uuid : achs.keySet()){
			if(existPlayer(uuid)){
				MySQL.update("UPDATE "+Settings.achievements_tabelname+" SET "+column+" = '"+achs.get(uuid)+"' WHERE UUID = '"+uuid+"'");
			} else {
				MySQL.update("INSERT INTO "+Settings.achievements_tabelname+" (UUID,"+column+") VALUES ('"+uuid.toString()+"','"+achs.get(uuid)+"')");
			}
		}
	}
	
	public static void loadAchievements(Player p){
		UUID uuid = p.getUniqueId();

		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.achievements_tabelname+" WHERE UUID = '"+uuid+"'");
			if(rs.next()){
				if(rs.getString(column) != null){
					achs.put(uuid, rs.getString(column));
					return;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		achs.put(uuid, "");
	}
	
	public static int hasAchievement(Player p, Achievement achievement){
		UUID uuid = p.getUniqueId();
		
		if(!achs.containsKey(uuid)){
			loadAchievements(p);
		}
		
		String allachs = achs.get(uuid);
		if(allachs.contains(",")){
			String[] achsplited = allachs.split(",");

			for(String all : achsplited){
				if(all.contains(":")){
					String[] statusplited = all.split(":");

					if(statusplited[0].equalsIgnoreCase("#"+achievement.getID())){
						try {
							int status = Integer.parseInt(statusplited[1]);
							if(status == 1 || status == 0) return status;
						} catch (Exception e) {
							p.sendMessage(Settings.pr+Settings.wrn+"Ein Fehler beim Laden deiner Errungenschaften ist aufgetreten!");
						}
					}
				}
			}
		} else {
			if(allachs.contains(":")){
				String[] statusplited = allachs.split(":");

				if(statusplited[0].equalsIgnoreCase("#"+achievement.getID())){
					try {
						int status = Integer.parseInt(statusplited[1]);
						if(status == 1 || status == 0) return status;
					} catch (Exception e) {
						p.sendMessage(Settings.pr+Settings.wrn+"Ein Fehler beim Laden deiner Errungenschaften ist aufgetreten!");
					}
				}
			}
		}
		return 0;
	}
	
	public static void setAchievement(Player p, Achievement achievement, boolean status){
		UUID uuid = p.getUniqueId();
		
		int statusid = (status ? 1 : 0);
		
		if(!achs.containsKey(uuid)){
			loadAchievements(p);
		}
		
		String playerachs = achs.get(uuid);
		
		if(playerachs.contains("#"+achievement.getID()+":0")){
			playerachs.replaceFirst("#"+achievement.getID()+":0", "#"+achievement.getID()+":"+statusid);
			
		} else if(playerachs.contains("#"+achievement.getID()+":1")){
			playerachs.replaceFirst("#"+achievement.getID()+":1", "#"+achievement.getID()+":"+statusid);
		
		} else {
			if(playerachs.equals("")){
				playerachs = "#"+achievement.getID()+":"+statusid;
			} else {
				playerachs = playerachs+",#"+achievement.getID()+":"+statusid;
			}
		}
		
		achs.put(uuid, playerachs);
	}
	
	@SuppressWarnings("deprecation")
	public static void openAchievementInventory(Player p){
		if(!achs.containsKey(p.getUniqueId())){
			loadAchievements(p);
		}
		Inventory inv = Bukkit.createInventory(null, 3*9, Settings.achievement_itemname);
		
		for(int i = 0; i < inv.getSize(); i++){
			inv.setItem(i, ItemUtils.getItem(Material.STAINED_GLASS_PANE, 1, 7, " ", null));
		}
		
		int slot = 10;
		for(Achievement allach : Achievement.values()){
			int achstatus = hasAchievement(p, allach);
			inv.setItem(slot, ItemUtils.getItem(Material.WOOL, 1, (achstatus == 1 ? DyeColor.LIME.getWoolData() : DyeColor.GRAY.getWoolData()), (achstatus == 1 ? "�a" : "�c")+allach.getName(), (achstatus == 1 ? "�e"+allach.getDescription() : "�8???")));
			slot+=1;
		}
		
		p.openInventory(inv);
	}
	
	public static void sendAchievementMessage(Player p, Achievement ach){
		p.sendMessage("�f�k##########################################");
		p.sendMessage(" ");
		//Nachricht mit "Mauszeiger-Text"
		ChatAPI.sendMessage(p, 
				ChatAPI.nrmltext("�7Du hast die Errungenschaft �e")
				+","+ChatAPI.coursorText("�e"+ach.getName(), "�a"+ach.getName()+"\n"+ach.getDescription())
				+","+ChatAPI.nrmltext("�7 erziehlt!"));
		
		if(ach.getPoints() > 0){
			p.sendMessage(" ");
			p.sendMessage("�7Belohnung:");
			p.sendMessage("�e+ "+ach.getPoints()+" "+(ach.getPoints() == 1 ? "Ranking-Punkt" : "Ranking-Punkte"));
		}
		p.sendMessage(" ");
		p.sendMessage("�f�k##########################################");
		
		p.playSound(p.getLocation(), Sound.ANVIL_USE, 4, 6);
	}
	
	public static void addAchievement(Player p, Achievement ach){
		if(hasAchievement(p, ach) == 0){
			sendAchievementMessage(p, ach);
			setAchievement(p, ach, true);
			Stats_RankingPoints.add(p.getUniqueId(), ach.getPoints(), false);
		}
	}
	
}
