package de.msgamerhd.kingoftheladder.stats;

/**
 * Class created by MsGamerHD on 07.10.2016
 */
public enum Achievement {

	ERSTERUNDE(1, 10, "Erste Runde", "Beende eine komplette Runde"),
	TNTMEISTER(2, 10, "Sprengmeister", "Kaufe dir 15 TNT im Shop"),
	ALLESMEIN(3, 10, "Alles mein!", "Sammel in einer Runde 15 Powerups auf"),
	HEILUNGF�RALLE(4, 10, "Heilung  f�r alle", "Platziere eine Heilstation im Deathmatch"),
	UNZERST�RBAR(5, 10, "Unzerst�rbar", "Beende das Deathmatch mit 3 Leben"),
	FEUER(6, 10, "FEUER?!", "Benutze im Deathmatch eine Feuerattacke"),
	KILLSTREAK(7, 10, "Killstreak", "T�te 5 Spieler ohne zu sterben");

	int id;
	int points;
	String name;
	String description;
	
	private Achievement(int id, int points, String name, String description){
		this.id = id;
		this.points = points;
		this.name = name;
		this.description = description;
	}
	
	public int getID(){
		return this.id;
	}
	
	public int getPoints(){
		return this.points;
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getDescription(){
		return this.description;
	}
	
}
