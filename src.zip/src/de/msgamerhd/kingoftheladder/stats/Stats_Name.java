package de.msgamerhd.kingoftheladder.stats;

import java.sql.ResultSet;
import java.util.UUID;

import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.MySQL;

/**
 * Class created by MsGamerHD on 16.06.2016
 */
public class Stats_Name {
	
	public static String column = "name";
	
	public static void syncWithMySQL(Player p){
		if(existPlayer(p.getUniqueId())){
			MySQL.update("UPDATE "+Settings.stats_tabelname+" SET "+column+" = '"+p.getName()+"' WHERE UUID = '"+p.getUniqueId()+"'");
		} else {
			MySQL.update("INSERT INTO "+Settings.stats_tabelname+" (UUID,"+column+") VALUES ('"+p.getUniqueId()+"','"+p.getName()+"')");
		}
	}
	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static String getName(UUID uuid){
		if(existPlayer(uuid)){
			try{
				ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
				
				if(rs.next()) return rs.getString(column);
			} catch (Exception d){}
		}
		return "�cSpieler existiert nicht";
	}
	
	public static UUID getUUID(String name){
		try{
			ResultSet rs = MySQL.query("SELECT UUID FROM "+Settings.stats_tabelname+" WHERE name = '"+name+"'");
			
			if(rs.next()) {
				String uuid = rs.getString("UUID");
				return UUID.fromString(uuid);
			}
		} catch (Exception d){}
		
		return null;
	}
}
