package de.msgamerhd.kingoftheladder.stats;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.MySQL;

/**
 * Class created by MsGamerHD on 16.06.2016
 */
public class Stats_RankingPoints {
	
	public static HashMap<UUID, Integer> points = new HashMap<>();

	public static String column = "points";
	
	public static void syncWithMySQL(){
		for(UUID uuid : points.keySet()){
			if(existPlayer(uuid)){
				MySQL.update("UPDATE "+Settings.stats_tabelname+" SET "+column+" = '"+points.get(uuid)+"' WHERE UUID = '"+uuid+"'");
			} else {
				MySQL.update("INSERT INTO "+Settings.stats_tabelname+" (UUID,"+column+") VALUES ('"+uuid.toString()+"','"+points.get(uuid)+"')");
			}
		}
		
	}

	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static void set(UUID uuid, int toSet){
		points.put(uuid, toSet);
	}
	
	public static int get(UUID uuid){
		if(!points.containsKey(uuid)){
			try{
				ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
				if(rs.next()){
					points.put(uuid, rs.getInt(column));
				}
			} catch (Exception d){}
		}
		
		if(!points.containsKey(uuid)) points.put(uuid, 0);
		
		return points.get(uuid);
	}

	public static void add(UUID uuid, int toAdd, boolean message){
		int count = get(uuid);
		count = count + toAdd;
		
		if(message){
			Player p = Bukkit.getPlayer(uuid);
			if(p != null) p.sendMessage(Settings.pr+Settings.acpt+"+ "+toAdd+(toAdd == 1 ? " Ranking-Punkt" : " Ranking-Punkte"));
		}
		
		set(uuid, count);
	}

	public static void remove(UUID uuid, int toRemove){
		int count = get(uuid);
		count = count - toRemove;
		
		set(uuid, count);
	}
	
	public static ArrayList<UUID> getTopPlayers(){
		ArrayList<UUID> top = new ArrayList<UUID>();
		try{
			ResultSet rs = MySQL.query("SELECT UUID FROM "+Settings.stats_tabelname+" ORDER BY "+column+" DESC");
			rs.beforeFirst();
			for(int i = 0; i < 3; i++){
				rs.next();
				top.add(UUID.fromString(rs.getString("uuid")));
			}
		} catch(Exception exc){}
		return top;
	}
}
