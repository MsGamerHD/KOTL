package de.msgamerhd.kingoftheladder.stats;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.UUID;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.MySQL;

/**
 * Class created by MsGamerHD on 16.06.2016
 */
public class Stats_PlayedGames {
	
	public static HashMap<UUID, Integer> played = new HashMap<>();

	public static String column = "played_games";
	
	public static void syncWithMySQL(){
		for(UUID uuid : played.keySet()){
			if(existPlayer(uuid)){
				MySQL.update("UPDATE "+Settings.stats_tabelname+" SET "+column+" = '"+played.get(uuid)+"' WHERE UUID = '"+uuid+"'");
			} else {
				MySQL.update("INSERT INTO "+Settings.stats_tabelname+" (UUID,"+column+") VALUES ('"+uuid.toString()+"','"+played.get(uuid)+"')");
			}
		}
	}
	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static void set(UUID uuid, int toSet){
		played.put(uuid, toSet);
	}
	
	public static int get(UUID uuid){
		if(!played.containsKey(uuid)){
			try{
				ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
				if(rs.next()){
					played.put(uuid, rs.getInt(column));
				}
			} catch (Exception d){}
			if(!played.containsKey(uuid)){
				played.put(uuid, 0);
			}
			
		}
		return played.get(uuid);
	}

	public static void add(UUID uuid, int toAdd){
		int count = get(uuid);
		count = count + toAdd;
		
		set(uuid, count);
	}

	public static void remove(UUID uuid, int toRemove){
		int count = get(uuid);
		count = count - toRemove;
		
		set(uuid, count);
	}
}
