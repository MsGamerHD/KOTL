package de.msgamerhd.kingoftheladder.stats;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.MySQL;

/**
 * Class created by MsGamerHD on 16.06.2016
 */
public class Stats_Coins {
	
	public static HashMap<UUID, Integer> coins = new HashMap<>();

	public static String column = "coins";
	
	public static void syncWithMySQL(){
		for(UUID uuid : coins.keySet()){
			if(existPlayer(uuid)){
				MySQL.update("UPDATE "+Settings.stats_tabelname+" SET "+column+" = '"+coins.get(uuid)+"' WHERE UUID = '"+uuid+"'");
			} else {
				MySQL.update("INSERT INTO "+Settings.stats_tabelname+" (UUID,"+column+") VALUES ('"+uuid.toString()+"','"+coins.get(uuid)+"')");
			}
		}
	}

	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static void set(UUID uuid, int toSet){
		coins.put(uuid, toSet);
	}
	
	public static int get(UUID uuid){
		if(!coins.containsKey(uuid)){
			try{
				ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
				if(rs.next()){
					coins.put(uuid, rs.getInt(column));
				}
			} catch (Exception d){}
			if(!coins.containsKey(uuid)){
				coins.put(uuid, 0);
			}
			
		}
		return coins.get(uuid);
	}

	public static void add(UUID uuid, int toAdd, boolean message, boolean boost){
		int count = get(uuid);
		count += toAdd;
		
		if(message){
			Player p = Bukkit.getPlayer(uuid);
			if(p != null) {
				String coinsname = (toAdd == 1 ? " Coin" : " Coins");
				if(boost){
					p.sendMessage(Settings.pr+Settings.acpt+"+ "+toAdd+coinsname+" �6(+ "+toAdd+coinsname+" Premium Boost)");
					count += toAdd;
				} else {
					p.sendMessage(Settings.pr+Settings.acpt+"+ "+toAdd+coinsname);
				}
			}
		}
		
		set(uuid, count);
	}

	public static void remove(UUID uuid, int toRemove){
		int count = get(uuid);
		count = count - toRemove;
		
		set(uuid, count);
	}
	
	public static ArrayList<UUID> getTopPlayers(){
		ArrayList<UUID> top = new ArrayList<UUID>();
		try{
			ResultSet rs = MySQL.query("SELECT UUID FROM "+Settings.stats_tabelname+" ORDER BY "+column+" DESC");
			rs.beforeFirst();
			for(int i = 0; i < 3; i++){
				rs.next();
				top.add(UUID.fromString(rs.getString("uuid")));
			}
		} catch(Exception exc){}
		return top;
	}
}
