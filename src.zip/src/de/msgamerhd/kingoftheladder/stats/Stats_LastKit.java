package de.msgamerhd.kingoftheladder.stats;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.UUID;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.utils.MySQL;

/**
 * Class created by MsGamerHD on 16.06.2016
 */
public class Stats_LastKit {
	
	public static HashMap<UUID, Kit> lastkit = new HashMap<>();

	public static String column = "last_kit_id";
	
	public static void syncWithMySQL(){
		for(UUID uuid : lastkit.keySet()){
			if(existPlayer(uuid)){
				MySQL.update("UPDATE "+Settings.stats_tabelname+" SET "+column+" = '"+lastkit.get(uuid).getID()+"' WHERE UUID = '"+uuid+"'");
			} else {
				MySQL.update("INSERT INTO "+Settings.stats_tabelname+" (UUID,"+column+") VALUES ('"+uuid.toString()+"','"+lastkit.get(uuid).getID()+"')");
			}
		}
	}

	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static void set(UUID uuid, Kit kit){
		lastkit.put(uuid, kit);
	}
	
	public static Kit get(UUID uuid){
		if(!lastkit.containsKey(uuid)){
			try{
				ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
				if(rs.next()){
					int kitid = rs.getInt(column);
					
					for(Kit kits : Kit.values()){
						if(kits.getID() == kitid){
							lastkit.put(uuid, kits);
							return kits;
						}
					}
					
				}
			} catch (Exception d){}
		}
		if(lastkit.containsKey(uuid)){
			return lastkit.get(uuid);
		}
		return null;
	}
}
