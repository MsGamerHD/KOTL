package de.msgamerhd.kingoftheladder.stats;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.UUID;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.utils.MySQL;

/**
 * Class created by MsGamerHD on 16.06.2016
 */
public class Stats_Wins {
	
	public static HashMap<UUID, Integer> wins = new HashMap<>();

	public static String column = "wins";
	
	public static void syncWithMySQL(){
		for(UUID uuid : wins.keySet()){
			if(existPlayer(uuid)){
				MySQL.update("UPDATE "+Settings.stats_tabelname+" SET "+column+" = '"+wins.get(uuid)+"' WHERE UUID = '"+uuid+"'");
			} else {
				MySQL.update("INSERT INTO "+Settings.stats_tabelname+" (UUID,"+column+") VALUES ('"+uuid.toString()+"','"+wins.get(uuid)+"')");
			}
		}
	}
	
	public static boolean existPlayer(UUID uuid){
		try {
			ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
			return rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static void set(UUID uuid, int toSet){
		wins.put(uuid, toSet);
	}
	
	public static int get(UUID uuid){
		if(!wins.containsKey(uuid)){
			try{
				ResultSet rs = MySQL.query("SELECT "+column+" FROM "+Settings.stats_tabelname+" WHERE UUID = '"+uuid+"'");
				if(rs.next()){
					wins.put(uuid, rs.getInt(column));
				}
			} catch (Exception d){}
			if(!wins.containsKey(uuid)){
				wins.put(uuid, 0);
			}
			
		}
		return wins.get(uuid);
	}

	public static void add(UUID uuid, int toAdd){
		int count = get(uuid);
		count = count + toAdd;
		
		set(uuid, count);
	}

	public static void remove(UUID uuid, int toRemove){
		int count = get(uuid);
		count = count - toRemove;
		
		set(uuid, count);
	}
}
