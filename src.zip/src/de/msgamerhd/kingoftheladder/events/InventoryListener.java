package de.msgamerhd.kingoftheladder.events;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.kits.KitUtils;
import de.msgamerhd.kingoftheladder.utils.MapUtils;
import de.msgamerhd.kingoftheladder.utils.Map_DeathmatchUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class InventoryListener implements Listener {

	@EventHandler
	public void on(InventoryClickEvent e){
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory().getName().equals(Settings.achievement_itemname)){
			e.setCancelled(true);
			
		} else if(e.getClickedInventory().getName().equals(Settings.kit_itemname)){
			e.setCancelled(true);

			if(e.getCurrentItem().getItemMeta() != null){
				String name = e.getCurrentItem().getItemMeta().getDisplayName();
				if(name != null){
					for(Kit kit : Kit.values()){
						if(name.contains(kit.getName())){
							KitUtils.chooseKit(p, kit);
							break;
						}
					}
				}
			}
			
		} else if(e.getClickedInventory().getName().equals(Settings.buykit_invname)){
			e.setCancelled(true);

			if(e.getSlot() == 1){
				for(Kit kits : Kit.values()){
					if(e.getInventory().getItem(4).getItemMeta().getDisplayName().contains(kits.getName())){
						KitUtils.buyKit(p, kits);
						break;
					}
				}
			} else if(e.getSlot() == 7){
				p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1, 1);
				KitUtils.openKitInventory(p);
			}
			
		} else if(e.getClickedInventory().getName().equals(Settings.einrichten_invname)){
			e.setCancelled(true);
			
			if(e.getSlot() == 2 || e.getSlot() == 4 || e.getSlot() == 6){
				p.playSound(p.getLocation(), Sound.ITEM_PICKUP, 1, 1);
				p.getInventory().addItem(e.getCurrentItem());
			}
		} else if(e.getClickedInventory().getName().equals(Settings.dm_einrichten_invname)){
			e.setCancelled(true);
			
			if(e.getSlot() == 4){
				p.playSound(p.getLocation(), Sound.ITEM_PICKUP, 1, 1);
				p.getInventory().addItem(e.getCurrentItem());
			}
		} else if(e.getClickedInventory().getName().equals(Settings.changemap_invname)){
			e.setCancelled(true);
			
			if(e.getSlot() == 5){
				p.openInventory(Main.changedmmap_inv);
				return;
			}
			if(e.getCurrentItem().getType() == Settings.changemap_material){
				String itemname = e.getCurrentItem().getItemMeta().getDisplayName();
				String mapname = ChatColor.stripColor(itemname);
				
				if(MapUtils.existMap(mapname)){
					p.sendMessage(Settings.pr+Settings.acpt+"Die Game-Map "+Settings.hlt+mapname+Settings.acpt+" wurde ausgew�hlt.");
					Main.map = mapname;
					
					ItemStack currentmap = Main.changemap_inv.getItem(3);
					ItemMeta im = currentmap.getItemMeta();
					im.setDisplayName(Settings.co+"Aktuelle Map: "+Settings.hlt+Main.map);
					currentmap.setItemMeta(im);
					
					Main.changemap_inv.setItem(3, currentmap);
				}
			}
		} else if(e.getClickedInventory().getName().equals(Settings.changedmmap_invname)){
			e.setCancelled(true);

			if(e.getSlot() == 5){
				p.openInventory(Main.changemap_inv);
				return;
			}
			if(e.getCurrentItem().getType() == Settings.changemap_material){
				String itemname = e.getCurrentItem().getItemMeta().getDisplayName();
				String mapname = ChatColor.stripColor(itemname);
				
				if(Map_DeathmatchUtils.existMap(mapname)){
					p.sendMessage(Settings.pr+Settings.acpt+"Die Deathmatch-Map "+Settings.hlt+mapname+Settings.acpt+" wurde ausgew�hlt.");
					Main.dmmap = mapname;
					
					ItemStack currentmap = Main.changedmmap_inv.getItem(3);
					ItemMeta im = currentmap.getItemMeta();
					im.setDisplayName(Settings.co+"Aktuelle Deathmatch-Map: "+Settings.hlt+Main.map);
					currentmap.setItemMeta(im);
					
					Main.changedmmap_inv.setItem(3, currentmap);
				}
			}
		}
	}
	
}
