package de.msgamerhd.kingoftheladder.events;

import java.util.Random;

import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFormEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.enums.GameStatus;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
@SuppressWarnings("deprecation")
public class WorldResetListener implements Listener {

	@EventHandler
	public void on(EntityExplodeEvent e){
		if(Main.status != GameStatus.INGAME){
			for(Block block : e.blockList()){
				block.getWorld().playEffect(block.getLocation(), Effect.STEP_SOUND, block.getTypeId(), 10);
			}
			e.blockList().clear();
		} else {
			for(Block block : e.blockList()){
				Material m = block.getType();
				byte data = block.getData();
				
				block.setType(Material.AIR);

		        Random rnd = new Random();
		        int wait = rnd.nextInt(8);
		        wait+=4;
		        
				new BukkitRunnable() {
					
					@Override
					public void run() {
						block.setType(m);
						block.setData(data);
						block.getWorld().playEffect(block.getLocation(), Effect.STEP_SOUND, m.getId(), 10);
					}
				}.runTaskLater(Main.getInstance(), wait*20);
			}
			e.blockList().clear();
		}
	}

	@EventHandler
	public void on(BlockFormEvent e){
		e.setCancelled(true);
	}

	@EventHandler
	public void on(BlockFromToEvent e){
		e.setCancelled(true);
	} 

	@EventHandler
	public void on(BlockPhysicsEvent e){
		e.setCancelled(true);
	}
	
}
