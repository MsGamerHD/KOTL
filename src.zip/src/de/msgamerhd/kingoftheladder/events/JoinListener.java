package de.msgamerhd.kingoftheladder.events;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class JoinListener implements Listener {

	@EventHandler
	public void on(PlayerJoinEvent e){
		e.setJoinMessage(null);
		PlayerUtils.playerJoin(e.getPlayer());
	}
	
}
