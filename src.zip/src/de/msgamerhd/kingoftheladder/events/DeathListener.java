package de.msgamerhd.kingoftheladder.events;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.kits.KitSkillUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerRespawnUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class DeathListener implements Listener {

	@EventHandler
	public void on(PlayerDeathEvent e){
		Player p = e.getEntity();
		Player killer = p.getKiller();
		e.setDeathMessage(null);
		
		if(killer != null) if(killer == p) killer = null;

		if(PlayerUtils.getTeam(p) != Team.SPIELENDER){
			p.spigot().respawn();
			p.setHealth(20.0);
			e.getDrops().clear();
			e.setDroppedExp(0);
			return;
		}
		
		if(Main.status == GameStatus.INGAME || Main.status == GameStatus.PROTECTION){
			PlayerRespawnUtils.respawnIngame(e);
			KitSkillUtils.iswaiting.remove(p);
		} else if(Main.status == GameStatus.DEATHMATCH){
			PlayerRespawnUtils.respawnDeathmatch(e);
		} else {
			PlayerRespawnUtils.respawnOtherReason(e);
		}
	}
}
