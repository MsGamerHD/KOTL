package de.msgamerhd.kingoftheladder.events;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.commands.Skip_CMD;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.stats.Stats_LeavedGames;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class LeaveListener implements Listener {

	@EventHandler
	public void on(PlayerQuitEvent e){
		Player p = e.getPlayer();
		e.setQuitMessage(null);
		
		if(Main.status != GameStatus.LOBBY && Main.status != GameStatus.RESTARTING && PlayerUtils.getTeam(p) == Team.SPIELENDER){
			Bukkit.broadcastMessage(Settings.pr+Settings.wrn+"Der Spieler "+Settings.hlt+p.getName()+Settings.wrn+" hat das Spiel verlassen!");
			PlayerUtils.lose(p);
			Stats_LeavedGames.add(p.getUniqueId(), 1);
		}
		
		if(Skip_CMD.skiped.contains(p)){
			Skip_CMD.skiped.remove(p);
		}
		PlayerUtils.removeTeam(p);
		Main.syncAllWithMySQL();
	}
	
}
