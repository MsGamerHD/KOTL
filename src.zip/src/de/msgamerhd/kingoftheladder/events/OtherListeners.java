package de.msgamerhd.kingoftheladder.events;

import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.commands.Einrichten_CMD;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.utils.EnchanterUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class OtherListeners implements Listener {

	@EventHandler
	public void on(PlayerInteractEvent e){
		Player p = e.getPlayer();
		
		if(!(Einrichten_CMD.configurationmode)){
			if(Main.status == GameStatus.LOBBY || Main.status == GameStatus.RESTARTING){
				e.setCancelled(true);
			}
			if(Main.status == GameStatus.INGAME || Main.status == GameStatus.DEATHMATCH){
				if(e.getAction() == Action.RIGHT_CLICK_BLOCK){
					if(e.getClickedBlock().getType() == Material.CHEST || e.getClickedBlock().getType() == Material.HOPPER || e.getClickedBlock().getType() == Material.ENDER_CHEST || e.getClickedBlock().getType() == Material.BEACON || e.getClickedBlock().getType() == Material.ENCHANTMENT_TABLE){
						e.setCancelled(true);
						return;
					}
				}
				e.setCancelled(false);
			}
			if(Main.status == GameStatus.SHOP){
				if(p.getItemInHand().getType().toString().contains("HELMET") || p.getItemInHand().getType().toString().contains("CHESTPLATE") || p.getItemInHand().getType().toString().contains("LEGGINGS") || p.getItemInHand().getType().toString().contains("BOOTS")){
					e.setCancelled(false);
				} else {
					e.setCancelled(true);
					if(e.getAction() == Action.RIGHT_CLICK_BLOCK){
						if(e.getClickedBlock().getType() == Material.ENCHANTMENT_TABLE){
							if(p.getItemInHand().getType() != Material.AIR){
								EnchanterUtils.enchantItem(p, p.getItemInHand());
							}
							return;
						}
					}
				}
				p.updateInventory();
			}
			if(Main.status == GameStatus.INGAME || Main.status == GameStatus.PROTECTION) {
				if(p.getItemInHand().getType().toString().contains("HELMET")){
					e.setCancelled(true);
					e.getPlayer().updateInventory();
				}
			}
		}
	}

	@EventHandler
	public void on(AsyncPlayerChatEvent e){
		Player p = e.getPlayer();
		
		String msg = e.getMessage();
		if(msg.contains("%")) msg = msg.replaceAll("%", "%%");
		
		e.setFormat((p.isOp() ? "�4" : "�a")+p.getName()+"�7: �f"+msg);
	}

	@EventHandler
	public void on(WeatherChangeEvent e){
		if(e.getWorld().isThundering()){
			e.getWorld().setThundering(false);
			e.getWorld().setStorm(false);
		}
	}

	@SuppressWarnings("deprecation")
	@EventHandler
	public void on(BlockPlaceEvent e){
		Player p = e.getPlayer();
		
		if(!Einrichten_CMD.configurationmode){
			e.setCancelled(true);
			
			if(Main.status == GameStatus.DEATHMATCH){
				//TNT
				if(e.getBlock().getType() == Material.TNT){
					if(p.getItemInHand().getAmount() > 1){
						p.getItemInHand().setAmount((p.getItemInHand().getAmount()-1));
					} else {
						p.setItemInHand(new ItemStack(Material.AIR));
					}
					
					TNTPrimed tnt = (TNTPrimed) p.getWorld().spawnEntity(e.getBlock().getLocation(), EntityType.PRIMED_TNT);
					tnt.setFuseTicks(40);
					
				//Spinnenweben
				} else if(e.getBlock().getType() == Material.WEB){
					e.setCancelled(false);
					Material material = e.getBlockReplacedState().getType();
					byte data = e.getBlockReplacedState().getData().getData();

					new BukkitRunnable() {
						
						@Override
						public void run() {
							e.getBlock().setType(material);
							e.getBlock().setData(data);
						}
					}.runTaskLater(Main.getInstance(), 8*10);
						
				//Heilstation
				} else if(e.getBlock().getType() == Material.BEACON){
					e.setCancelled(false);
					Material material = e.getBlockReplacedState().getType();
					byte data = e.getBlockReplacedState().getData().getData();
					
					Location loc = e.getBlock().getLocation();
					loc.add(0.5, -1, 0.5);
					ArmorStand stand = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
					
					//Einstellen
					stand.setArms(false);
					stand.setCanPickupItems(false);
					stand.setBasePlate(false);
					stand.setVisible(false);
					stand.setGravity(false);
					stand.setCustomNameVisible(true);

					//L�schung nach 10 Sekunden
					new BukkitRunnable() {
						int counter = 0;
						int maxamount = 6;
						
						@Override
						public void run() {
							//Heilen
							e.getBlock().getWorld().spigot().playEffect(e.getBlock().getLocation(), Effect.HEART, 0, 0, 1, 1, 1, 0, 15, 20);
							
							for(Player all : Bukkit.getOnlinePlayers()){
								if(all.getLocation().distance(e.getBlock().getLocation()) <= 4){
									p.removePotionEffect(PotionEffectType.REGENERATION);
									p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 2));
									all.playSound(e.getBlock().getLocation(), Sound.ENDERMAN_TELEPORT, 1, 1);
								} else {
									all.playSound(e.getBlock().getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);
								}
							}
							
							//Zerst�ren
							if(counter >= maxamount){
								e.getBlock().setType(material);
								e.getBlock().setData(data);
								
								if(stand != null) stand.remove();
								
								for(Player all : Bukkit.getOnlinePlayers()) all.playSound(e.getBlock().getLocation(), Sound.ANVIL_BREAK, 1, 1);
								
								cancel();
								return;
							}
							
							//Status
							if(stand != null){
								String color = "�4";
								if(counter <= 5) color = "�c";
								if(counter <= 4) color = "�6";
								if(counter <= 3) color = "�e";
								if(counter <= 2) color = "�a";
								stand.setCustomName("�c�lHeilstation �7(Status: "+color+(maxamount-counter)+"�7/"+maxamount+")");
							}
							
							counter+=1;
						}
					}.runTaskTimer(Main.getInstance(), 0, 30);
				}
			}
		}
	}

	@EventHandler
	public void on(FoodLevelChangeEvent e){
		if(Main.status != GameStatus.DEATHMATCH) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void on(BlockBreakEvent e){
		if(!Einrichten_CMD.configurationmode){
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void on(PlayerDropItemEvent e){
		if(!Einrichten_CMD.configurationmode){
			if(Main.status != GameStatus.DEATHMATCH) {
				e.setCancelled(true);
			}
		}
	}

	@EventHandler
	public void on(PlayerPickupItemEvent e){
		if(!Einrichten_CMD.configurationmode){
			if(Main.status != GameStatus.DEATHMATCH) {
				e.setCancelled(true);
			}
		}
	}

	@EventHandler
	public void on(InventoryClickEvent e){
		if(!Einrichten_CMD.configurationmode){
			if(!(Main.status == GameStatus.DEATHMATCH || Main.status == GameStatus.SHOP)) {
				e.setCancelled(true);
			}
		}
	}

	@EventHandler
	public void on(ProjectileHitEvent e){
		if(!Einrichten_CMD.configurationmode){
			if(Main.status != GameStatus.DEATHMATCH) {
				if(e.getEntity() instanceof Arrow){
					e.getEntity().remove();
				}
			}
		}
	}

	@EventHandler
	public void on(EntityDamageEvent e){
		if(Main.status == GameStatus.INGAME || Main.status == GameStatus.DEATHMATCH) {
			if(!(e.getEntity() instanceof ItemFrame || e.getEntity() instanceof ArmorStand || e.getEntity() instanceof EnderCrystal)){
				if(e.getEntity() instanceof Player){
					Player p = (Player) e.getEntity();
					
					if(p.hasPotionEffect(PotionEffectType.INVISIBILITY)){
						e.setCancelled(true);
						return;
					}
				}
				e.setCancelled(false);
			} else {
				e.setCancelled(true);
			}
		} else {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void on(EntityDamageByEntityEvent e){
		if(e.getDamager() instanceof Player){
			Player dmg = (Player) e.getDamager();

			if(dmg.hasPotionEffect(PotionEffectType.INVISIBILITY)){
				dmg.removePotionEffect(PotionEffectType.INVISIBILITY);
			}
		}
	}
}
