package de.msgamerhd.kingoftheladder.events;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.commands.Einrichten_CMD;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.kits.KitSkillUtils;
import de.msgamerhd.kingoftheladder.utils.FileManager;
import de.msgamerhd.kingoftheladder.utils.GameUtils;
import de.msgamerhd.kingoftheladder.utils.MapUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class MoveListener implements Listener {

	public static Location goal = null;
	@EventHandler
	public void on(PlayerMoveEvent e){
		Player p = e.getPlayer();
		
		if(!Einrichten_CMD.configurationmode){
			if(Main.status == GameStatus.LOBBY || Main.status == GameStatus.RESTARTING || Main.status == GameStatus.SHOP){
				Location spawn = FileManager.getLobbySpawn();
				
				if(spawn != null){
					if(p.getLocation().getY() <= (spawn.getY()-10)){
						PlayerUtils.teleportToLobby(p);
					}
				}
				return;
			}
		}
		
		boolean freeze = KitSkillUtils.freezelist.containsKey(p);
		
		if((Main.status == GameStatus.PROTECTION || freeze) && PlayerUtils.getTeam(p) == Team.SPIELENDER){
			Location from = e.getFrom().clone();
			Location to = e.getTo().clone();
			from.setY(to.getY());
			
			if(from.distance(to) >= 0.001){
				p.teleport(e.getFrom());
			}
		}
		
		if(Main.status == GameStatus.INGAME && PlayerUtils.getTeam(p) == Team.SPIELENDER){
			if(isOnGoal(p)){
				boolean changeking = true;
				if(GameUtils.king != null) if(isOnGoal(GameUtils.king)) changeking = false;
				
				if(changeking){
					GameUtils.setKing(p);
				}
			}
		}
	}
	
	public static boolean isOnGoal(Player p){
		if(goal == null) goal = MapUtils.getGoal(Main.map);
		
		if(p.getLocation().distance(goal) <= 0.8){
			return true;
		}
		
		return false;
	}
	
}
