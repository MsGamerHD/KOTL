package de.msgamerhd.kingoftheladder.events;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Shop_Items;
import de.msgamerhd.kingoftheladder.kits.KitSkillUtils;
import de.msgamerhd.kingoftheladder.kits.KitUtils;
import de.msgamerhd.kingoftheladder.shop.ShopUtils;
import de.msgamerhd.kingoftheladder.stats.AchievementUtils;
import de.msgamerhd.kingoftheladder.utils.MapUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class ItemInteractListener implements Listener {

	@EventHandler
	public void on(PlayerInteractEvent e){
		Player p = e.getPlayer();
		
		ItemStack is = p.getItemInHand();
		
		if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK){
			if(is.getItemMeta() != null){
				String itemname = is.getItemMeta().getDisplayName();
				
				if(itemname != null){
					if(itemname.equals(Settings.setgoal_itemname)){
						Bukkit.dispatchCommand(p, "kotl setgoal");
					
					} else if(itemname.equals(Settings.setspawn_itemname)){
						Bukkit.dispatchCommand(p, "kotl nextspawn");
					
					} else if(itemname.equals(Settings.addpowerup_itemname)){
						Bukkit.dispatchCommand(p, "kotl nextpowerup");
					
					} else if(itemname.equals(Settings.dm_setspawn_itemname)){
						Bukkit.dispatchCommand(p, "dm nextspawn");
					
					} else if(itemname.equals(Settings.changemap_itemname)){
						if(Main.changedmmap_inv == null) MapUtils.loadDeathmatchInventory();
						if(Main.changemap_inv == null) MapUtils.loadInventory();

						p.openInventory(Main.changemap_inv);
					
					} else if(itemname.equals(Settings.gamestart_itemname)){
						Bukkit.dispatchCommand(p, "start");
					
					} else if(itemname.equals(Settings.bug_item.getItemMeta().getDisplayName())){
						if(Main.status == GameStatus.INGAME){
							if(!(p.getLocation().getBlock().getType().isTransparent() || p.getEyeLocation().getBlock().getType().isTransparent())){
								Location ploc = p.getLocation().clone();
								Location eloc = p.getEyeLocation().clone();
								
								for(int y = 0; y < 300; y++){
									ploc.add(0, y, 0);
									eloc.add(0, y, 0);
									if(ploc.getBlock().getType().isTransparent() && eloc.getBlock().getType().isTransparent()){
										p.teleport(p.getLocation().add(0, y, 0));
										p.sendMessage(Settings.pr+"Du wurdest befreit!");
										p.playSound(p.getLocation(), Sound.ENDERMAN_TELEPORT, 1, 1);
										break;
									}
								}
							} else {
								p.sendMessage(Settings.pr+Settings.wrn+"Es sieht so aus, als w�rdest du nicht ein einem Block stecken.");
							}
						}
					
					} else if(itemname.equals(Settings.achievement_itemname)){
						AchievementUtils.openAchievementInventory(p);
						
					} else if(itemname.equals(Settings.kit_itemname)){
						KitUtils.openKitInventory(p);
						
					} else if(itemname.equals(Settings.shop_name)){
						ShopUtils.openShop(p);
						
					} else if(itemname.equals(Shop_Items.FEUERATTACKE.getName())){
						if(Main.status == GameStatus.DEATHMATCH){
							KitSkillUtils.useFire(p);
						}
						
					} else if(itemname.equals(Shop_Items.PILZ.getName())){
						if(Main.status == GameStatus.DEATHMATCH){
							ItemStack pitem = p.getItemInHand();
							if(pitem.getAmount() > 1){
								pitem.setAmount((pitem.getAmount()-1));
							} else {
								p.setItemInHand(new ItemStack(Material.AIR));
							}
							
							p.setFoodLevel(p.getFoodLevel()+2);
							p.removePotionEffect(PotionEffectType.SPEED);
							p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 6*20, 2));
							p.playSound(p.getLocation(), Sound.EAT, 1, 1);
						}
					}
				}
			}
		}
	}
}
