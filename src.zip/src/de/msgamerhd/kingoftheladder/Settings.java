package de.msgamerhd.kingoftheladder;

import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import de.msgamerhd.kingoftheladder.utils.ItemUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
@SuppressWarnings("deprecation")
public class Settings {

	public static String co = "�7";
	public static String hlt = "�b";
	public static String acpt = "�a";
	public static String wrn = "�c";
	public static String pr = "�6>> �eKingOfTheLadder �6| "+co;
	public static String prshort = "�6>> �eKOTL �6| "+co;
	public static String perm = pr+wrn+"Du kannst diesen Befehl nicht nutzen!";

	public static int minplayers = 2;
	public static int maxplayers = 10;

	public static int poinstowin = 330;
	public static int enchantment_cost = 380;
	
	public static String powerupname = "�6�l>> �e�lPowerup";
	public static ItemStack nospecial_item = ItemUtils.getItem(Material.INK_SACK, 1, DyeColor.RED.getDyeData(), "�cKein Special-Item", null);
	public static ItemStack bug_item = ItemUtils.getItem(Material.SUGAR, 1, 0, "�7Aus einem Block befreien", null);

	public static int normalitem_slot = 0;
	public static int kititemslot = 1;
	public static int specialitem_slot = 4;
	public static int bugitem_slot = 7;
	public static int statusitem_slot = 8;
	
	//Map w�hlen
	public static String changemap_invname = "�eW�hle eine Game-Map";
	public static String changedmmap_invname = "�eW�hle eine Deathmatch-Map";
	public static String changemap_itemname = "�aMap w�hlen";
	public static Material changemap_material = Material.EMPTY_MAP;
	
	//Items
	public static String achievement_itemname = "�bErrungenschaften";
	public static String gamestart_itemname = "�aSpiel starten";
	public static String kit_itemname = "�bKit Auswahl";
	public static String buykit_invname = "�bKit kaufen";
	
	//Einrichten
	public static String einrichten_invname = "�eMap Einrichten";
	public static String setspawn_itemname = "�aSpawnpunkt hinzuf�gen";
	public static String addpowerup_itemname = "�aPowerup hinzuf�gen";
	public static String setgoal_itemname = "�aZielpunkt setzen";
	
	public static String dm_einrichten_invname = "�eMap Einrichten �7�o(DM)";
	public static String dm_setspawn_itemname = "�aSpawnpunkt hinzuf�gen �7�o(DM)";
	
	//Shop
	public static String shop_name = "�6�l>> �eKingOfTheLadder Shop";
	
	//MySQL
	public static String host = "localhost";
	public static String database = "database";
	public static String user = "root";
	public static String password = "password";

	public static String stats_tabelname = "PlayerStats";
	public static String achievements_tabelname = "PlayerAchievements";
	public static String kits_tabelname = "PlayerKits";
	
}
