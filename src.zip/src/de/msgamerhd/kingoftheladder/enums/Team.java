package de.msgamerhd.kingoftheladder.enums;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public enum Team {

	SPIELENDER("Spielender"),
	ZUSCHAUER("Zuschauer");
	
	String name;
	
	private Team(String name) {
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	
}
