package de.msgamerhd.kingoftheladder.enums;

import org.bukkit.Material;

/**
 * Class created by MsGamerHD on 09.10.2016
 */
public enum Kit {

	// �n = normale farbe | �h = hinweis-farbe | \n = n�chste Zeile
	KOBOLD(1, 0, "Kobold", Material.EMERALD, "�nSein selbstgemachter �hSpeer�n ist nicht nur spitz, \n�nsondern schl�gt andere Spieler auch noch \n�nweit weg."),
	ENDERMAN(2, 0, "Enderman", Material.ENDER_PEARL, "�nEr bekommt alle �h8 Sekunden �neine Enderperle \n�nund erh�lt auch �hkeinen�n Schaden durch Enderperlen."),
	BARBAR(3, 3000, "Barbar", Material.GOLD_HELMET, "�nSeine starke Waffe erm�glicht es ihm, seine \n�nGegner schnell zu t�ten. Das Gewicht seiner \n�nWaffe �hverlangsamt �nihn jedoch sp�rbar."),
	RENNER(4, 1200, "Renner", Material.FEATHER, "�nEr wird auf Grund seiner �hhohen�n Geschwindigkeit \n�ngef�rchtet!"),
	PYROTECHNIKER(5, 5000, "Pyrotechniker", Material.FIREBALL, "�nMit seiner au�ergew�hnlichen F�higkeit, \n�hkeinen �nSchaden von Feuer zu erhalten, \n�nmacht er mit seinen Feuerattacken den\n�nGegnern schwer zu schaffen!"),
	SCHNEEMANN(6, 3000, "Schneemann", Material.SNOW_BALL, "�nSeine frostigen Schneeb�lle lassen seine Gegner \n�nf�r �h3 Sekunden �neinfriehren. Dazu kommt, \n�ndass er �hnicht�n eingefrohren werden kann."),
	ZAUBERER(7, 5000, "Zauberer", Material.BLAZE_ROD, "�nMit seinem Zauberstab kann er alle �h16 Sekunden �ndie Position \n�nmit anderen Spielern �hTauschen�n."),
	BOMBER(8, 800, "Bomber", Material.TNT, "�nMan bekommt alle �h14 Sekunden �nein TNT \n�nund kann damit die Map zerst�ren!"),
	SPRINGER(9, 2500, "Springer", Material.CHAINMAIL_BOOTS, "�nEr besitzt die F�higkeit, einen �hDoppelsprung \n�njede �h6 Sekunden ausf�hren zu k�nnen"),
	HEXE(10, 2600, "Hexe", Material.BREWING_STAND_ITEM, "�nMit ihrem Stab wirft sie einen zuf�lligen \n�hTrank�n auf seine Gegner. Zudem hat sie selber \n�neine �hImmunit�t�n gegen sch�dliche Tr�nke!"),
	GOLEM(11, 3000, "Golem", Material.IRON_BLOCK, "�nAuf Grund seines Gewichts bewegt sich der \n�nGolem nur sehr �htr�ge�n. Wegen seiner eisernen \n�nBeschichtung h�lt der viel Schaden aus!"),
	DIEB(12, 5000, "Dieb", Material.GOLD_INGOT, "�nWegen seiner Begabung, unauff�llig Punkte \n�nzu �hklauen�n, bekommt er als K�nig �h6 Punkte \n�nund wenn er kein K�nig ist �h3 Punkte�n. Zudem macht er \n�nmit seinem �6Gold �nviel Schaden!"),
	TINTENFISCH(14, 3500, "Tintenfisch", Material.INK_SACK, "�nEr verschafft sich einen Vorteil, indem \n�ner alle Spieler f�r �h5 Sekunden \n�nblendet und verlangsamt."),
	HEILER(15, 5000, "Heiler", Material.APPLE, "�nEr sieht normal aus, kann sich jedoch alle \n�h22 Sekunden �nkomplett �hheilen�n."),
	SCHLANGE(16, 4000, "Schlange", Material.FERMENTED_SPIDER_EYE, "�nSie �hl�hmt�n und �hvergiftet�n ihre \n�nGegner f�r einen kurzen Moment.");

	int id;
	int cost;
	String name;
	Material type;
	String description;
	
	private Kit(int id, int cost, String name, Material type, String description){
		this.id = id;
		this.cost = cost;
		this.name = name;
		this.type = type;
		this.description = description;
	}
	
	public int getID(){
		return id;
	}
	
	public int getCost(){
		return cost;
	}
	
	public String getName(){
		return name;
	}
	
	public Material getType(){
		return type;
	}
	
	public String getDescription(){
		return description.replaceAll("�n", "�7").replaceAll("�h", "�b");
	}
	
}
