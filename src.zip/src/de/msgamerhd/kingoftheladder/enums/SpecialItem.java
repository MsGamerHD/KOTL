package de.msgamerhd.kingoftheladder.enums;


import java.util.Random;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import de.msgamerhd.kingoftheladder.utils.ItemUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public enum SpecialItem {

	BOMBE(ItemUtils.getItem(Material.TNT, 1, 0, "�cBombe", "�c*tssss*\n�4�lBOOOM")),
	BOMBE3(ItemUtils.getItem(Material.TNT, 3, 0, "�cBombe", "�c*tssss*\n�4�lBOOOM")),
	KN�PPEL(ItemUtils.getItem(Material.STICK, 1, 0, "�6Kn�ppel �7�o(Schlage einen Spieler)", "�7Klaue durch Schlagen Punkte\n�7von anderen Spielern")),
	WELLENSTO�(ItemUtils.getItem(Material.EYE_OF_ENDER, 1, 0, "�2Wellen Sto�", "�7Beschw�re eine Welle, welche\n�7alle anderen Spieler wegschleudert")),
	ENDERPERLE1(ItemUtils.getItem(Material.ENDER_PEARL, 1, 0, "�3Enderperle", null)),
	ENDERPERLE2(ItemUtils.getItem(Material.ENDER_PEARL, 2, 0, "�3Enderperle", null)),
	ENDERPERLE4(ItemUtils.getItem(Material.ENDER_PEARL, 4, 0, "�3Enderperle", null)),
	BOGEN(ItemUtils.getItem(Material.BOW, 1, Material.BOW.getMaxDurability()-7, "�7Bogen", null)),
	SPRUNG(ItemUtils.getItem(Material.FEATHER, 1, 0, "�7Sprung", null)),
	EXTREMESPRUNG(ItemUtils.getItem(Material.FEATHER, 1, 0, "�4Extremer �7Sprung", null)),
	PUNKTE4(ItemUtils.getItem(Material.DOUBLE_PLANT, 1, 0, "�64 Punkte", null)),
	PUNKTE6(ItemUtils.getItem(Material.DOUBLE_PLANT, 1, 0, "�66 Punkte", null)),
	PUNKTE8(ItemUtils.getItem(Material.DOUBLE_PLANT, 1, 0, "�68 Punkte", null)),
	PUNKTE15(ItemUtils.getItem(Material.DOUBLE_PLANT, 1, 0, "�615 Punkte", null)),
	FROSTATTACKE(ItemUtils.getItem(Material.ICE, 1, 0, "�bFrostattacke �7�o(Schlage einen Spieler)", "�7Friere einen Spieler druch\n�7anklicken ein"));

	ItemStack item;
	
	private SpecialItem(ItemStack item) {
		this.item = item;
	}
	
	public ItemStack getItem(){
		return this.item;
	}
	
	public Material getMaterial(){
		return item.getType();
	}
	
	public String getName(){
		if(item.getItemMeta() != null){
			if(item.getItemMeta().getDisplayName() != null){
				return item.getItemMeta().getDisplayName();
			}
		}
		return "";
	}
	
	public static SpecialItem getRandomItem(){
        SpecialItem[] itemarray = SpecialItem.values();
        
        Random rnd = new Random();
        int rndint = rnd.nextInt(itemarray.length);
        
        return itemarray[rndint];
	}
	
}
