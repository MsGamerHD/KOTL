package de.msgamerhd.kingoftheladder.enums;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import de.msgamerhd.kingoftheladder.utils.ItemUtils;

/**
 * Class created by MsGamerHD on 05.10.2016
 */
public enum Shop_Items {

	//Schwerter
	HOLZSCHWERT(Shop_Categorys.WAFFEN, 0, 50, "Holzschwert", ItemUtils.getItem(Material.WOOD_SWORD, 1, 0, null, null)),
	STEINSCHWERT(Shop_Categorys.WAFFEN, 1, 200, "Steinschwert", ItemUtils.getItem(Material.STONE_SWORD, 1, 0, null, null)),
	EISENSCHWERT(Shop_Categorys.WAFFEN, 2, 450, "Eisenschwert", ItemUtils.getItem(Material.IRON_SWORD, 1, 0, null, null)),
	BOGEN(Shop_Categorys.WAFFEN, 4, 180, "Bogen", ItemUtils.getItem(Material.BOW, 1, 0, null, null)),
	PFEIL(Shop_Categorys.WAFFEN, 5, 10, "Pfeil", ItemUtils.getItem(Material.ARROW, 1, 0, null, null)),
	ANGEL(Shop_Categorys.WAFFEN, 7, 130, "Angel", ItemUtils.getItem(Material.FISHING_ROD, 1, 0, null, null)),
	TNT(Shop_Categorys.WAFFEN, 8, 90, "TNT", ItemUtils.getItem(Material.TNT, 1, 0, null, null)),
	
	//Lederr�stung
	LEDERHELM(Shop_Categorys.LEDERR�STUNG, 2, 30, "Lederkappe", ItemUtils.getItem(Material.LEATHER_HELMET, 1, 0, null, null)),
	LEDERBRUSTPANZER(Shop_Categorys.LEDERR�STUNG, 3, 50, "Lederbrustpanzer", ItemUtils.getItem(Material.LEATHER_CHESTPLATE, 1, 0, null, null)),
	LEDERHOSE(Shop_Categorys.LEDERR�STUNG, 4, 40, "Lederhose", ItemUtils.getItem(Material.LEATHER_LEGGINGS, 1, 0, null, null)),
	LEDERSCHUHE(Shop_Categorys.LEDERR�STUNG, 5, 30, "Lederschuhe", ItemUtils.getItem(Material.LEATHER_BOOTS, 1, 0, null, null)),
	
	//Kettenr�stung
	KETTENHELM(Shop_Categorys.KETTENR�STUNG, 2, 100, "Kettenhelm", ItemUtils.getItem(Material.CHAINMAIL_HELMET, 1, 0, null, null)),
	KETTENBRUSTPANZER(Shop_Categorys.KETTENR�STUNG, 3, 150, "Kettenbrustpanzer", ItemUtils.getItem(Material.CHAINMAIL_CHESTPLATE, 1, 0, null, null)),
	KETTENHOSE(Shop_Categorys.KETTENR�STUNG, 4, 130, "Kettenhose", ItemUtils.getItem(Material.CHAINMAIL_LEGGINGS, 1, 0, null, null)),
	KETTENSCHUHE(Shop_Categorys.KETTENR�STUNG, 5, 100, "Kettenschuhe", ItemUtils.getItem(Material.CHAINMAIL_BOOTS, 1, 0, null, null)),
	
	//Eisenr�stung
	EISENHELM(Shop_Categorys.EISENR�STUNG, 2, 200, "Eisenhelm", ItemUtils.getItem(Material.IRON_HELMET, 1, 0, null, null)),
	EISENBRUSTPANZER(Shop_Categorys.EISENR�STUNG, 3, 300, "Eisenbrustpanzer", ItemUtils.getItem(Material.IRON_CHESTPLATE, 1, 0, null, null)),
	EISENHOSE(Shop_Categorys.EISENR�STUNG, 4, 200, "Eisenhose", ItemUtils.getItem(Material.IRON_LEGGINGS, 1, 0, null, null)),
	EISENSCHUHE(Shop_Categorys.EISENR�STUNG, 5, 200, "Eisenschuhe", ItemUtils.getItem(Material.IRON_BOOTS, 1, 0, null, null)),

	//ESSEN
	APFEL(Shop_Categorys.ESSEN, 2, 2, "Apfel", ItemUtils.getItem(Material.APPLE, 1, 0, null, null)),
	FLEISCH(Shop_Categorys.ESSEN, 3, 4, "Fleisch", ItemUtils.getItem(Material.COOKED_BEEF, 1, 0, null, null)),
	PILZ(Shop_Categorys.ESSEN, 5, 16, "Pilz", ItemUtils.getItem(Material.RED_MUSHROOM, 1, 0, null, null)),
	GOLDAPFEL(Shop_Categorys.ESSEN, 7, 100, "Goldapfel", ItemUtils.getItem(Material.GOLDEN_APPLE, 1, 0, null, null)),
	
	//Tr�nke
	HEILTRANKLVL1(Shop_Categorys.TR�NKE, 1, 140, "Heiltrank Lvl. 1", ItemUtils.getItem(Material.POTION, 3, 16453, null, null)),
	HEILTRANKLVL2(Shop_Categorys.TR�NKE, 2, 200, "Heiltrank Lvl. 2", ItemUtils.getItem(Material.POTION, 2, 16421, null, null)),
	SCHADENSTRANKLVL1(Shop_Categorys.TR�NKE, 6, 190, "Schadenstrank Lvl. 1", ItemUtils.getItem(Material.POTION, 1, 16460, null, null)),
	SCHADENSTRANKLVL2(Shop_Categorys.TR�NKE, 7, 230, "Schadenstrank Lvl. 2", ItemUtils.getItem(Material.POTION, 1, 16428, null, null)),
	
	//Special
	SPINNENWEBEN(Shop_Categorys.SPEZIAL, 1, 40, "Spinnenweben �7�o(Platzieren)", ItemUtils.getItem(Material.WEB, 1, 0, null, null)),
	HEILSTATION(Shop_Categorys.SPEZIAL, 3, 620, "�aHeilstation �7�o(Platzieren)", ItemUtils.getItem(Material.BEACON, 1, 0, null, null)),
	FEUERATTACKE(Shop_Categorys.SPEZIAL, 4, 550, "�cFeuerattacke �7�o(Rechtsklick)", ItemUtils.getItem(Material.FIREBALL, 1, 0, null, null)),
	EXTRAHERZEN(Shop_Categorys.SPEZIAL, 6, 240, "�aExtraleben", ItemUtils.getItem(Material.EMERALD, 1, 0, null, null));

	Shop_Categorys category;
	int slot;
	int tokens;
	String name;
	ItemStack item;
	
	private Shop_Items(Shop_Categorys category, int slot, int tokens, String name, ItemStack item){
		this.category = category;
		this.slot = slot;
		this.tokens = tokens;
		this.name = name;
		this.item = item;
	}
	
	public int getSlot(){
		return this.slot;
	}
	
	public Shop_Categorys getCategory(){
		return this.category;
	}
	
	public int getTokens(){
		return this.tokens;
	}
	
	public String getName(){
		return "�f"+this.name;
	}
	
	public String getLore(){
		return "\n�6"+this.tokens+(this.tokens == 1 ? " Token" : " Tokens") + "\n";
	}
	
	public ItemStack getItem(){
		return this.item;
	}
	
	public Material getMaterial(){
		return this.item.getType();
	}
	
}
