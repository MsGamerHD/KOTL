package de.msgamerhd.kingoftheladder.enums;

import org.bukkit.Material;

/**
 * Class created by MsGamerHD on 05.10.2016
 */
public enum Shop_Categorys {

	WAFFEN("Waffen", Material.GOLD_SWORD, 0),
	LEDERR�STUNG("Lederr�stung", Material.LEATHER_CHESTPLATE, 1),
	KETTENR�STUNG("Kettenr�stung", Material.CHAINMAIL_CHESTPLATE, 2),
	EISENR�STUNG("Eisenr�stung", Material.IRON_CHESTPLATE, 3),
	ESSEN("Essen", Material.CAKE, 5),
	TR�NKE("Tr�nke", Material.POTION, 6),
	SPEZIAL("Spezial", Material.EMERALD, 8);
	
	String name;
	Material material;
	int slot;
	
	private Shop_Categorys(String name, Material material, int slot){
		this.name = name;
		this.material = material;
		this.slot = slot;
	}
	
	public String getName(){
		return "�b"+this.name;
	}
	
	public String getRawName(){
		return this.name;
	}
	
	public Material getMaterial(){
		return this.material;
	}
	
	public int getSlot(){
		return this.slot;
	}
	
}
