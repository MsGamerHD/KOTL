package de.msgamerhd.kingoftheladder.enums;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public enum GameStatus {

	LOBBY(60),
	PROTECTION(0),
	INGAME(10*60),
	SHOP(90),
	DEATHMATCH(10*60),
	RESTARTING(10);
	
	int time;
	
	private GameStatus(int time) {
		this.time = time;
	}
	
	public int getTime(){
		return (this.time);
	}
	
}
