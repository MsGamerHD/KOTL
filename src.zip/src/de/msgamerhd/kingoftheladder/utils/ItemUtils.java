package de.msgamerhd.kingoftheladder.utils;

import java.util.ArrayList;
import java.util.Arrays;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Class created by MsGamerHD on 24.08.2016
 */
public class ItemUtils {
	
	public static ItemStack getItem(Material m, int anzahl, int damage, String name, String lore){
		ItemStack is = new ItemStack(m, anzahl, (short) damage);
		if(name != null){
			ItemMeta im = is.getItemMeta();
			im.setDisplayName(name);

			if(lore != null){
				if(lore.contains("\n")){
					String[] lorearray = lore.split("\n");
					ArrayList<String> lorelist = new ArrayList<>();
					for(int i = 0; i < lorearray.length; i++){
						lorelist.add(lorearray[i]);
					}
					im.setLore(lorelist);
				} else {
					im.setLore(Arrays.asList(lore));
				}
			}
			
			is.setItemMeta(im);
		}
		
		return is;
	}
	
	public static ItemStack getItem(Material m, int anzahl, int damage, String name, String lore, boolean unbreakable){
		ItemStack is = getItem(m, anzahl, damage, name, lore);
		ItemMeta im = is.getItemMeta();
		im.spigot().setUnbreakable(unbreakable);
		is.setItemMeta(im);
		
		return is;
	}
	
	public static boolean isSameItem(ItemStack item1, ItemStack item2){
		if(item1.getType() == item2.getType() && item1.getDurability() == item2.getDurability()){
			if(item1.getItemMeta() != null && item2.getItemMeta() != null){
				if(item1.getItemMeta().getDisplayName().equals(item2.getItemMeta().getDisplayName())){
					return true;
				}
			} else {
				return true;
			}
		}
		return false;
	}
	
	public static boolean isSameItemOnlyName(ItemStack item1, ItemStack item2){
		if(item1.getType() == item2.getType()){
			if(item1.getItemMeta() != null && item2.getItemMeta() != null){
				if(item1.getItemMeta().getDisplayName().equals(item2.getItemMeta().getDisplayName())){
					return true;
				}
			} else {
				return true;
			}
		}
		return false;
	}
	
	public static int getType(String eintrag){
		int type = 0;
		
		if(eintrag.contains(":")){
			String[] typearray = eintrag.split(":");

			try{
				type = Integer.parseInt(typearray[0]);
			} catch (NumberFormatException d) {
			}
		} else {
			try{
				type = Integer.parseInt(eintrag);
			} catch (NumberFormatException d) {
			}
		}
		return type;
	}
	
	public static int getData(String eintrag){
		int data = 0;
		
		if(eintrag.contains(":")){
			String[] typearray = eintrag.split(":");

			try{
				data = Integer.parseInt(typearray[1]);
			} catch (NumberFormatException d) {
			}
		}
		return data;
	}

	public static boolean removeItem(Player p, Material m, int count){
		PlayerInventory inv = p.getInventory();
		
		if(getItemAmount(p, m) >= count){
			for(int i = 0; i < count; i++){
				for(int slot = 0; slot < inv.getSize(); slot++){
					ItemStack is = p.getInventory().getItem(slot);
					
					if(is != null && is.getType() == m){
						if(is.getAmount() > 1){
							is.setAmount(is.getAmount()-1);
							inv.setItem(slot, is);
							break;
						} else {
							inv.setItem(slot, null);
							break;
						}
					}
				}
			}
			return true;
		}
		
		return false;
	}
	
	public static int getItemAmount(Player p, Material m){
		PlayerInventory inv = p.getInventory();
		
		int amount = 0;
		
		for(ItemStack is : inv.getContents()){
			if(is != null){
				if(is.getType() == m){
					amount+=is.getAmount();
				}
			}
		}
		return amount;
	}
}
