package de.msgamerhd.kingoftheladder.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.stats.Stats_Coins;
import de.msgamerhd.kingoftheladder.stats.Stats_Deaths;
import de.msgamerhd.kingoftheladder.stats.Stats_Kills;
import de.msgamerhd.kingoftheladder.stats.Stats_LeavedGames;
import de.msgamerhd.kingoftheladder.stats.Stats_Name;
import de.msgamerhd.kingoftheladder.stats.Stats_PlayedGames;
import de.msgamerhd.kingoftheladder.stats.Stats_RankingPoints;
import de.msgamerhd.kingoftheladder.stats.Stats_Wins;
import net.minecraft.server.v1_8_R3.EntityArmorStand;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityDestroy;
import net.minecraft.server.v1_8_R3.PacketPlayOutSpawnEntityLiving;
import net.minecraft.server.v1_8_R3.WorldServer;

/**
 * Class created by MsGamerHD on 09.10.2016
 */
public class HologramUtils {

	public static HashMap<Player, ArrayList<EntityArmorStand>> pstands = new HashMap<>();
	
	public static void refreshHolos(){
		File file = FileManager.getDataFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

		Location loc;

		removeHolos();
		
		if(Main.status == GameStatus.LOBBY){
			//Top-3
			int rank = 1;
			for(UUID uuid : Stats_RankingPoints.getTopPlayers()){
				loc = ((Location) cfg.get("location.rank_"+rank)).clone();
				
				if(loc != null){
					String color = "�c";
					if(rank == 2) color = "�7";
					if(rank == 1) color = "�6";
					
					spawnHologram(loc, Settings.hlt+Stats_RankingPoints.get(uuid)+" Punkte", Stats_Name.getName(uuid), (rank == 1 ? Material.GOLD_CHESTPLATE : (rank == 2 ? Material.IRON_CHESTPLATE : Material.LEATHER_CHESTPLATE)));
					loc.add(0, 0.3, 0);
					spawnHologram(loc, color+"�l"+Stats_Name.getName(uuid));
				}
				
				loc = ((Location) cfg.get("location.hologram.rank_"+rank)).clone();

				if(loc != null){
					loc.subtract(0, 1.5, 0);
					spawnHologram(loc, "�fGesp. Spiele: "+Settings.hlt+Stats_PlayedGames.get(uuid));
					loc.subtract(0, 0.27, 0);
					spawnHologram(loc, "�fGew. Spiele: "+Settings.hlt+Stats_Wins.get(uuid));
					loc.subtract(0, 0.27, 0);
					spawnHologram(loc, "�fKills: "+Settings.hlt+Stats_Kills.get(uuid));
				}
				rank+=1;
			}
		} else {
			loc = ((Location) cfg.get("location.hologram.rank_5")).clone();
			
			if(loc != null){
				loc.subtract(0, 1.5, 0);
				spawnHologram(loc, "�6Eine Verzauberung kostet "+Settings.enchantment_cost+" Tokens");
			}
		}
	}
	
	public static void removeHolos(){
		File file = FileManager.getDataFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		Location loc = ((Location) cfg.get("location.rank_"+1)).clone();

		if(loc != null){
			for(Entity en : loc.getWorld().getEntities()){
				if(en instanceof ArmorStand){
					en.remove();
				}
			}
		}
	}
	
	public static void spawnHologram(Location loc, String name){
		spawnHologram(loc, name, null, null);
	}

	public static void spawnHologram(Location loc, String name, String owner, Material chestplate){
		ArmorStand stand = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
		stand.setBasePlate(false);
		stand.setVisible(false);
		stand.setGravity(false);
		stand.setCustomNameVisible(true);
		stand.setCustomName(name);
		
		if(owner != null && chestplate != null){
			stand.setVisible(true);
	        stand.setHelmet(getSkull(owner));
	        stand.setChestplate(new ItemStack(chestplate));
	        stand.setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));
	        stand.setBoots(new ItemStack(Material.LEATHER_BOOTS));
		}
	}
	
	//Spieler-Stats
	public static void removeHolos(Player p){
		if(pstands.containsKey(p)){
			ArrayList<EntityArmorStand> list = pstands.get(p);
			
			for(EntityArmorStand allstands : list){
				PacketPlayOutEntityDestroy packet = new PacketPlayOutEntityDestroy(allstands.getId());
				((CraftPlayer)p).getHandle().playerConnection.sendPacket(packet);
			}
			pstands.remove(p);
		}
	}
	
	public static void refreshPacketHolos(Player p){
		File file = FileManager.getDataFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

		Location loc = ((Location) cfg.get("location.hologram.rank_"+4)).clone();
		
		removeHolos(p);
		
		if(loc != null){
			UUID uuid = p.getUniqueId();

			loc.add(0, 0.27, 0);
			spawnPacketHologram(loc, "�a�lDeine Statistiken", p);
			loc.subtract(0, 0.27, 0);
			spawnPacketHologram(loc, "�fGesp. Spiele: "+Settings.hlt+Stats_PlayedGames.get(uuid), p);
			loc.subtract(0, 0.27, 0);
			spawnPacketHologram(loc, "�fVerls. Spiele: "+Settings.hlt+Stats_LeavedGames.get(uuid), p);
			loc.subtract(0, 0.27, 0);
			spawnPacketHologram(loc, "�fGew. Spiele: "+Settings.hlt+Stats_Wins.get(uuid), p);
			loc.subtract(0, 0.27, 0);
			spawnPacketHologram(loc, "�fKills: "+Settings.hlt+Stats_Kills.get(uuid), p);
			loc.subtract(0, 0.27, 0);
			spawnPacketHologram(loc, "�fTode: "+Settings.hlt+Stats_Deaths.get(uuid), p);
			loc.subtract(0, 0.27, 0);
			
			double kd = (double)Stats_Kills.get(uuid) / (double)(Stats_Deaths.get(uuid) == 0 ? 1 : Stats_Deaths.get(uuid));

			if(Double.isNaN(kd)) kd = 0;
			kd = (int)(kd*100+0.5)/100.0;
			spawnPacketHologram(loc, "�fK/D: "+Settings.hlt+kd, p);
			loc.subtract(0, 0.27, 0);
			spawnPacketHologram(loc, "�fPunkte: "+Settings.hlt+Stats_RankingPoints.get(uuid), p);
			loc.subtract(0, 0.27, 0);
			spawnPacketHologram(loc, "�fCoins: "+Settings.hlt+Stats_Coins.get(uuid), p);
		}
	}

	public static void spawnPacketHologram(Location loc, String name, Player p){
        WorldServer s = ((CraftWorld)loc.getWorld()).getHandle();
        EntityArmorStand stand = new EntityArmorStand(s);
        
        stand.setLocation(loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
        stand.setCustomName(name);
        stand.setCustomNameVisible(true);
        stand.setGravity(false);
        stand.setInvisible(true);
       
        PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving(stand);
        ((CraftPlayer)p).getHandle().playerConnection.sendPacket(packet);
        
        ArrayList<EntityArmorStand> list = new ArrayList<>();
        if(pstands.containsKey(p)) list = pstands.get(p);
        
        list.add(stand);
        
        pstands.put(p, list);
	}
	
	public static ItemStack getSkull(String owner){
		 ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
	     SkullMeta sm = (SkullMeta) skull.getItemMeta();
	     sm.setOwner(owner);
	     skull.setItemMeta(sm);
	     
	     return skull;
	}
	
}
