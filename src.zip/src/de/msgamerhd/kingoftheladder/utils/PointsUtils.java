package de.msgamerhd.kingoftheladder.utils;

import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.countdowns.GameCountdown;

/**
 * Class created by MsGamerHD on 01.10.2016
 */
public class PointsUtils {

	public static HashMap<Player, Integer> points = new HashMap<>();
	
	public static int getPoints(Player p){
		if(points.containsKey(p)){
			return points.get(p);
		}
		return 0;
	}
	
	public static void addPoints(Player p, int amount){
		if(p != null){
			if(amount > 0){
				int newamount = getPoints(p)+amount;
				if(newamount < 0) newamount = 0;
				
				points.put(p, newamount);
				ScoreboardUtils.updateBoard();
				
				p.setLevel(newamount);
				
				if(newamount >= Settings.poinstowin){
					if(!PlayerUtils.won.contains(p)){
						for(Player all : Bukkit.getOnlinePlayers()){
							((CraftPlayer)all).sendTitle("�6"+p.getName(), "�7hat "+Settings.poinstowin+" Punkte erreicht!");
							all.playSound(all.getLocation(), Sound.ENDERDRAGON_GROWL, 4, 2);
							PlayerUtils.won.add(p);
							if(GameCountdown.gamecountdown > 15){
								GameCountdown.gamecountdown = 15;
								Bukkit.broadcastMessage(Settings.pr+Settings.hlt+"Die Spielzeit wurde verk�rzt!");
							}
						}
					}
				}
			}
		}
	}
	
	public static void addPoints(Player p, int amount, boolean message){
		if(p != null){
			if(amount > 0){
				addPoints(p, amount);
				if(message){
					p.sendMessage(Settings.pr+Settings.acpt+"+ "+amount+(amount == 1 ? " Punkt" : " Punkte"));
					p.playSound(p.getLocation(), Sound.ITEM_PICKUP, 1, 1);
				}
			}
		}
	}
	
	public static void removePoints(Player p, int amount){
		if(amount > 0){
			int newamount = getPoints(p)-amount;
			if(newamount < 0) newamount = 0;
			
			points.put(p, newamount);
			ScoreboardUtils.updateBoard();
			p.setLevel(newamount);
			p.playSound(p.getLocation(), Sound.PIG_IDLE, 1, 1);
			p.sendMessage(Settings.pr+Settings.wrn+"- "+amount+(amount == 1 ? " Punkt" : " Punkte"));
		}
	}
	
}
