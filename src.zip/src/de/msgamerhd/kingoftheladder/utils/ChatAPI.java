package de.msgamerhd.kingoftheladder.utils;

import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.PacketPlayOutChat;
import net.minecraft.server.v1_8_R3.IChatBaseComponent.ChatSerializer;

import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

public class ChatAPI {
	
	public static String dictateText(String text, String courser, String vorschreibtext){
		String chat = "{\"text\":\""+text+"\",\"clickEvent\":{\"action\":\"suggest_command\",\"value\":\""+vorschreibtext+"\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\""+courser+"\"}]}}}";
		return chat;
	}
	
	public static String performCommand(String text, String courser, String ausf�hrtext){
		String chat = "{\"text\":\""+text+"\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\""+ausf�hrtext+"\"},\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\""+courser+"\"}]}}}";
		return chat;
	}
	
	public static String coursorText(String text, String courser){
		String chat = "{\"text\":\""+text+"\",\"hoverEvent\":{\"action\":\"show_text\",\"value\":{\"text\":\"\",\"extra\":[{\"text\":\""+courser+"\"}]}}}";
		return chat;
	}
	
	public static String nrmltext(String text){
		String chat = "{\"text\":\""+text+"\"}";
		return chat;
	}
	
	public static void sendMessage(Player p, String serializer){
		IChatBaseComponent chat = ChatSerializer.a("[\"\","+serializer+"]");
		PacketPlayOutChat packet = new PacketPlayOutChat(chat);
		((CraftPlayer)p).getHandle().playerConnection.sendPacket(packet);
	}
	
}
