package de.msgamerhd.kingoftheladder.utils;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.countdowns.OtherRunnables;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.kits.KitSkillUtils;
import de.msgamerhd.kingoftheladder.stats.Achievement;
import de.msgamerhd.kingoftheladder.stats.AchievementUtils;
import de.msgamerhd.kingoftheladder.stats.Stats_Coins;
import de.msgamerhd.kingoftheladder.stats.Stats_Deaths;
import de.msgamerhd.kingoftheladder.stats.Stats_Kills;
import de.msgamerhd.kingoftheladder.stats.Stats_RankingPoints;

/**
 * Class created by MsGamerHD on 08.10.2016
 */
public class PlayerRespawnUtils {

	//INGAME
	public static void respawnIngame(PlayerDeathEvent e){
		Player p = e.getEntity();
		Player killer = p.getKiller();
		e.setDeathMessage(null);
		if(KitSkillUtils.freezelist.containsKey(p)) KitSkillUtils.freezelist.remove(p);

		if(Main.status == GameStatus.INGAME){
			e.getDrops().clear();
			e.setDroppedExp(0);
			e.setKeepInventory(true);
			
			if(killer == null){
				Bukkit.broadcastMessage(Settings.pr+Settings.hlt+p.getName()+Settings.co+" ist gestorben!");
			} else {
				if(Main.status == GameStatus.DEATHMATCH){
					killer.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 6*20, 2));
				}
				Bukkit.broadcastMessage(Settings.pr+Settings.hlt+p.getName()+Settings.co+" wurde von "+Settings.hlt+killer.getName()+Settings.co+" get�tet!");
			}
			
			boolean isking = GameUtils.isKing(p);
			if(isking){
				GameUtils.resetKing();
				GameUtils.setKing(killer);
				PointsUtils.addPoints(killer, 4, true);
				PointsUtils.removePoints(p, 8);
			} else {
				PointsUtils.removePoints(p, 2);
			}
			OtherRunnables.pointtime.put(p, 0);
			
			if(isking){
				p.playSound(p.getLocation(), Sound.ENDERDRAGON_GROWL, 3, 3);
				p.sendMessage(Settings.pr+"�cDu hast deine �6Krone �cverloren!");
			}
			new BukkitRunnable() {
				
				@Override
				public void run() {
					p.spigot().respawn();
					p.getInventory().clear();
					p.getInventory().setArmorContents(null);
					PlayerUtils.teleportToMapspawn(p);
					PlayerUtils.updateItems(p);
					PlayerUtils.respawnProtection(p, 2);
					p.setLevel(PointsUtils.getPoints(p));
					KitSkillUtils.setKitEffectAndItem(p);
				}
			}.runTaskLater(Main.getInstance(), 2);
		}
	}
	
	public static void respawnDeathmatch(PlayerDeathEvent e){
		Player p = e.getEntity();
		Player killer = p.getKiller();
		e.setDeathMessage(null);
		e.setKeepInventory(true);
		
		if(Main.status == GameStatus.DEATHMATCH){
			Stats_Deaths.add(p.getUniqueId(), 1);
			
			if(killer == null){
				Bukkit.broadcastMessage(Settings.pr+Settings.hlt+p.getName()+Settings.co+" ist gestorben!");
			} else {
				if(Main.status == GameStatus.DEATHMATCH){
					killer.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 6*20, 2));
				}
				Stats_Kills.add(killer.getUniqueId(), 1);
				Stats_RankingPoints.add(killer.getUniqueId(), 4, true);
				Stats_Coins.add(killer.getUniqueId(), 10, true, p.hasPermission("game.boost"));
				Bukkit.broadcastMessage(Settings.pr+Settings.hlt+p.getName()+Settings.co+" wurde von "+Settings.hlt+killer.getName()+Settings.co+" get�tet!");
			}
			
			if(PlayerUtils.removeLife(p, 1) <= 0){
				p.spigot().respawn();
				PlayerUtils.lose(p);
				AchievementUtils.addAchievement(p, Achievement.ERSTERUNDE);
				if(Main.status != GameStatus.RESTARTING){
					e.setKeepInventory(false);
				}
				
			} else {
				new BukkitRunnable() {
					
					@Override
					public void run() {
						p.spigot().respawn();
						PlayerUtils.teleportToDMMapspawn(p);
						PlayerUtils.respawnProtection(p, 3);
					}
				}.runTaskLater(Main.getInstance(), 2);
			}
		}
	}
	

	public static void respawnOtherReason(PlayerDeathEvent e){
		Player p = e.getEntity();

		e.getDrops().clear();
		e.setDroppedExp(0);
		p.spigot().respawn();
		PlayerUtils.teleportToLobby(p);
	}

}
