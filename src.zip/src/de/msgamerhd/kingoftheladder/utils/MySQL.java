package de.msgamerhd.kingoftheladder.utils;

import java.io.File;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;

import com.mysql.jdbc.Connection;

import de.msgamerhd.kingoftheladder.Settings;

public class MySQL {
	
	public static Connection con;
	
	public static void loadSQLSettings(){
		File file = FileManager.getMySQLFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

		Settings.host = cfg.getString("mysql.host");
		Settings.database = cfg.getString("mysql.database");
		Settings.password = cfg.getString("mysql.password");
		Settings.user = cfg.getString("mysql.user");
	}
	
	public static void connect(){
		try{
			loadSQLSettings();
			con = (Connection) DriverManager.getConnection("jdbc:mysql://" + Settings.host + ":3306/" + Settings.database + "?autoReconnect=true", Settings.user, Settings.password);
			Bukkit.getConsoleSender().sendMessage("�aDie MySQL-Verbindung von KingOfTheLadder wurde aufgebaut!");
		} catch (SQLException e){
			Bukkit.getConsoleSender().sendMessage("�cDie MySQL-Verbindung von KingOfTheLadder konnte �lNICHT �r�caufgebaut werden!");
		}
	}
	
	public static boolean isConnected(){
		//wenn nicht verbunden, erneut 1x versuchen
		if(con == null) connect();
		
		if(con != null) return true;
		return false;
	}
	
	public static void close(){
		try {
			if(isConnected()){
				con.close();
				Bukkit.getConsoleSender().sendMessage("�9Die MySQL-Verbindung von KingOfTheLadder wurde geschlossen!");
			}
		} catch (SQLException e) {
			Bukkit.getConsoleSender().sendMessage("�cDie MySQL-Verbindung von KingOfTheLadder konnte �lNICHT �r�cgeschlossen werden!");
		}
	}
	
	public static void update(String qry){
		if(isConnected()){
			try {
				Statement st = con.createStatement();
				
				st.executeUpdate(qry);
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static ResultSet query(String qry){
		if(isConnected()){
			ResultSet rs = null;
			
			try {
				Statement st = con.createStatement();
				rs = st.executeQuery(qry);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return rs;
		} 
		
		return null;
	}
	
}
