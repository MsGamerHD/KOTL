package de.msgamerhd.kingoftheladder.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Map_DeathmatchUtils {

	public static String convertName(String name){
		return name.replace(" ", "_").toLowerCase();
	}
	
	public static ArrayList<String> getMapsAsList(){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ArrayList<String> maplist = new ArrayList<>();
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps");
		
		if(sec != null){
			for(String map : sec.getKeys(false)){
				maplist.add(cfg.getString("maps."+map+".name"));
			}
		}
		
		return maplist;
	}
	
	public static String getMaps(){
		ArrayList<String> maplist = getMapsAsList();
		
		if(maplist.isEmpty()){
			return "�ckeine Maps";
		}
		
		String maptext = "";
		for(String map : maplist){
			maptext = maptext + ", " + map;
		}
		maptext = maptext.substring(2);
		
		return maptext;
	}
	
	public static String getRandomMap(){
		ArrayList<String> maplist = getMapsAsList();
		
		if(maplist.isEmpty()){
			return null;
		}

		Random rnd = new Random();
		int zahl = rnd.nextInt(maplist.size());
		
		return maplist.get(zahl);
	}
	
	public static boolean existMap(String mapname){
		return getMaps().toLowerCase().contains(mapname.toLowerCase());
	}
	
	public static boolean createMap(String mapname){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".name", mapname);
		
		try {
			cfg.save(file);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public static boolean setBuilder(String mapname, String builder){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".builder", builder);
		
		try {
			cfg.save(file);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public static String getBuilder(String mapname){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

		if(cfg.contains("maps."+convertName(mapname)+".builder")){
			return cfg.getString("maps."+convertName(mapname)+".builder");
		}
		
		return "�cunbekannt";
	}
	
	/*
	 * Spawnpunkte
	 */
	public static int getNextSpawnID(String mapname){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps."+convertName(mapname)+".spawn");
		
		int highest = 0;
		
		if(sec != null){
			for(String allspawns : sec.getKeys(false)){
				try {
					int id = Integer.parseInt(allspawns);
					if(id > highest){
						highest = id;
					}
				} catch (NumberFormatException e) {
				}
			}
		}
		highest+=1;
		
		return highest;
	}
	
	public static ArrayList<Location> getSpawns(String mapname){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ArrayList<Location> spawns = new ArrayList<>();
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps."+convertName(mapname)+".spawn");
		
		if(sec != null){
			for(String allspawns : sec.getKeys(false)){
				Location loc = (Location) cfg.get("maps."+convertName(mapname)+".spawn."+allspawns);
				
				if(loc != null){
					spawns.add(loc);
				}
			}
		}
		
		return spawns;
	}
	
	public static int addSpawn(String mapname, Location loc){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		int id = getNextSpawnID(mapname);
		cfg.set("maps."+convertName(mapname)+".spawn."+id, loc);
		
		try {
			cfg.save(file);
			return id;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return -1;
	}
	
	public static void removeSpawn(String mapname, int id){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".spawn."+id, null);
		
		try {
			cfg.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Location getSpawn(String mapname, int id){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		return (Location) cfg.get("maps."+convertName(mapname)+".spawn."+id);
	}
	
	public static boolean existSpawn(String mapname, int id){
		File file = FileManager.getDeathmatchMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		return cfg.contains("maps."+convertName(mapname)+".spawn."+id);
	}
	
}
