package de.msgamerhd.kingoftheladder.utils;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.countdowns.DeathmatchCountdown;
import de.msgamerhd.kingoftheladder.countdowns.GameCountdown;
import de.msgamerhd.kingoftheladder.countdowns.LobbyCountdown;
import de.msgamerhd.kingoftheladder.countdowns.ProtectionCountdown;
import de.msgamerhd.kingoftheladder.countdowns.ShopCountdown;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.kits.KitUtils;

/**
 * Class created by MsGamerHD on 01.10.2016
 */
public class ScoreboardUtils {

	public static void resetScoreboardAll(){
		for(Player all : Bukkit.getOnlinePlayers()){
			resetScoreboard(all);
		}
	}
	
	public static void resetScoreboard(Player p){
		Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();

		Objective obj = board.getObjective("scoreboard");
		if (obj == null) obj = board.registerNewObjective("scoreboard", "dummy");
		
		obj.setDisplaySlot(DisplaySlot.SIDEBAR);
		
		int min = LobbyCountdown.lobbycountdown/60;
		int sec = LobbyCountdown.lobbycountdown-(min*60);
		obj.setDisplayName(Settings.prshort+Settings.hlt+min+":"+(sec < 10 ? "0" : "")+sec);

		if(Main.status != GameStatus.SHOP){
			obj.getScore("�e�lServer-IP:").setScore(999);
			obj.getScore("�fbergwerkLABS.de").setScore(998);
			obj.getScore("�1").setScore(997);
			
			if(Main.status == GameStatus.LOBBY || Main.status == GameStatus.PROTECTION || Main.status == GameStatus.INGAME){
				obj.getScore("�e�lDein Kit:").setScore(996);
				if(KitUtils.pkits.containsKey(p)){
					obj.getScore("�f"+KitUtils.pkits.get(p).getName()).setScore(995);
				} else {
					obj.getScore("�ckeins ausgew�hlt").setScore(995);
				}
				if(Main.status == GameStatus.PROTECTION || Main.status == GameStatus.INGAME){
					obj.getScore("�2").setScore(994);
				}
			}
		}
		
		p.setScoreboard(board);
		updateDisplayname();
	}
	
	@SuppressWarnings("static-access")
	public static void setKit(Player p, Kit kit){
		Scoreboard board = p.getScoreboard();
		
		if(board != null){
			Objective obj = board.getObjective("scoreboard");
			if (obj == null) obj = board.registerNewObjective("scoreboard", "dummy");
			
			board.resetScores("�ckeins ausgew�hlt");
			for(Kit kits : kit.values()){
				board.resetScores("�f"+kits.getName());
			}
			obj.getScore("�f"+kit.getName()).setScore(995);
		}
	}
	
	public static void switchKing(Player oldking, Player newking){
		for(Player all : Bukkit.getOnlinePlayers()){
			Scoreboard board = all.getScoreboard();

			if(board == null) {
				resetScoreboard(all);
			} else if (all.getScoreboard() != board){
				resetScoreboard(all);
			}
			
			if(Main.status == GameStatus.INGAME){
				Objective obj = board.getObjective("scoreboard");
				if (obj == null) obj = board.registerNewObjective("scoreboard", "dummy");

				if(oldking != null){
					board.resetScores("�6"+oldking.getName());
					obj.getScore(oldking.getName()).setScore(PointsUtils.getPoints(oldking));
				}

				if(newking != null){
					board.resetScores(newking.getName());
					obj.getScore("�6"+newking.getName()).setScore(PointsUtils.getPoints(newking));
				}
				
			}
		}
	}
	
	public static void removePlayer(String name){
		for(Player all : Bukkit.getOnlinePlayers()){
			Scoreboard board = all.getScoreboard();

			if(board == null) {
				resetScoreboard(all);
			} else if (all.getScoreboard() != board){
				resetScoreboard(all);
			}
			
			board.resetScores(name);
		}
	}
	
	public static void updateBoard(){
		for(Player all : Bukkit.getOnlinePlayers()){
			Scoreboard board = all.getScoreboard();

			if(board == null) {
				resetScoreboard(all);
			} else if (all.getScoreboard() != board){
				resetScoreboard(all);
			}

			Objective obj = board.getObjective("scoreboard");
			if (obj == null) obj = board.registerNewObjective("scoreboard", "dummy");
			
			for(Player all2 : Bukkit.getOnlinePlayers()){
				if(PlayerUtils.getTeam(all2) == Team.SPIELENDER){
					if(Main.status == GameStatus.INGAME || Main.status == GameStatus.PROTECTION){
						if(GameUtils.isKing(all2)){
							obj.getScore("�6"+all2.getName()).setScore(PointsUtils.getPoints(all2));
						} else {
							obj.getScore(all2.getName()).setScore(PointsUtils.getPoints(all2));
						}
					} else if(Main.status == GameStatus.SHOP){
						obj.getScore(all2.getName()).setScore(TokensUtils.getTokens(all2));
					} else if(Main.status == GameStatus.DEATHMATCH){
						obj.getScore(all2.getName()).setScore(PlayerUtils.getLife(all2));
					} else {
						board = Bukkit.getScoreboardManager().getNewScoreboard();
					}
				}
			}
		}
	}
	
	public static void updateDisplayname(){
		for(Player all : Bukkit.getOnlinePlayers()){
			Scoreboard board = all.getScoreboard();

			if(board == null) {
				resetScoreboard(all);
			} else if (all.getScoreboard() != board){
				resetScoreboard(all);
			}

			int countdown = 60;
			if(Main.status == GameStatus.LOBBY) countdown = LobbyCountdown.lobbycountdown;
			if(Main.status == GameStatus.PROTECTION) countdown = ProtectionCountdown.protectioncountdown;
			if(Main.status == GameStatus.INGAME) countdown = GameCountdown.gamecountdown;
			if(Main.status == GameStatus.SHOP) countdown = ShopCountdown.shopcountdown;
			if(Main.status == GameStatus.DEATHMATCH) countdown = DeathmatchCountdown.deathmatchcountdown;
			
			int min = countdown/60;
			int sec = countdown-(min*60);
			
			Objective obj = board.getObjective("scoreboard");
			if (obj == null) obj = board.registerNewObjective("scoreboard", "dummy");
			obj.setDisplayName(Settings.prshort+Settings.hlt+min+":"+(sec < 10 ? "0" : "")+sec);
			
			
			if(Main.status == GameStatus.RESTARTING){
				all.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
			}
		}
	}
	
}
