package de.msgamerhd.kingoftheladder.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class MapUtils {

	public static String convertName(String name){
		return name.replace(" ", "_").toLowerCase();
	}
	
	public static ArrayList<String> getMapsAsList(){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ArrayList<String> maplist = new ArrayList<>();
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps");
		
		if(sec != null){
			for(String map : sec.getKeys(false)){
				maplist.add(cfg.getString("maps."+map+".name"));
			}
		}
		
		return maplist;
	}
	
	public static String getMaps(){
		ArrayList<String> maplist = getMapsAsList();
		
		if(maplist.isEmpty()){
			return "�ckeine Maps";
		}
		
		String maptext = "";
		for(String map : maplist){
			maptext = maptext + ", " + map;
		}
		maptext = maptext.substring(2);
		
		return maptext;
	}
	
	public static String getRandomMap(){
		ArrayList<String> maplist = getMapsAsList();
		
		if(maplist.isEmpty()){
			return null;
		}

		Random rnd = new Random();
		int zahl = rnd.nextInt(maplist.size());
		
		return maplist.get(zahl);
	}
	
	public static boolean existMap(String mapname){
		return getMaps().toLowerCase().contains(mapname.toLowerCase());
	}
	
	public static boolean createMap(String mapname){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".name", mapname);
		
		try {
			cfg.save(file);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public static boolean setBuilder(String mapname, String builder){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".builder", builder);
		
		try {
			cfg.save(file);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return false;
	}

	public static String getBuilder(String mapname){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

		if(cfg.contains("maps."+convertName(mapname)+".builder")){
			return cfg.getString("maps."+convertName(mapname)+".builder");
		}
		
		return "�cunbekannt";
	}
	
	public static boolean setGoal(String mapname, Location loc){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".goal", loc);
		
		try {
			cfg.save(file);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public static Location getGoal(String mapname){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		return (Location) cfg.get("maps."+convertName(mapname)+".goal");
	}
	
	/*
	 * Spawnpunkte
	 */
	public static int getNextSpawnID(String mapname){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps."+convertName(mapname)+".spawn");
		
		int highest = 0;
		
		if(sec != null){
			for(String allspawns : sec.getKeys(false)){
				try {
					int id = Integer.parseInt(allspawns);
					if(id > highest){
						highest = id;
					}
				} catch (NumberFormatException e) {
				}
			}
		}
		highest+=1;
		
		return highest;
	}
	
	public static ArrayList<Location> getSpawns(String mapname){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ArrayList<Location> spawns = new ArrayList<>();
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps."+convertName(mapname)+".spawn");
		
		if(sec != null){
			for(String allspawns : sec.getKeys(false)){
				Location loc = (Location) cfg.get("maps."+convertName(mapname)+".spawn."+allspawns);
				
				if(loc != null){
					spawns.add(loc);
				}
			}
		}
		
		return spawns;
	}
	
	public static int addSpawn(String mapname, Location loc){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		int id = getNextSpawnID(mapname);
		cfg.set("maps."+convertName(mapname)+".spawn."+id, loc);
		
		try {
			cfg.save(file);
			return id;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return -1;
	}
	
	public static void removeSpawn(String mapname, int id){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".spawn."+id, null);
		
		try {
			cfg.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Location getSpawn(String mapname, int id){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		return (Location) cfg.get("maps."+convertName(mapname)+".spawn."+id);
	}
	
	public static boolean existSpawn(String mapname, int id){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		return cfg.contains("maps."+convertName(mapname)+".spawn."+id);
	}
	
	/*
	 * Powerups
	 */
	public static int getNextPowerupID(String mapname){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps."+convertName(mapname)+".powerup");
		
		int highest = 0;
		
		if(sec != null){
			for(String allpoweruplocs : sec.getKeys(false)){
				try {
					int id = Integer.parseInt(allpoweruplocs);
					if(id > highest){
						highest = id;
					}
				} catch (NumberFormatException e) {
				}
			}
		}
		highest+=1;
		
		return highest;
	}
	
	public static ArrayList<Location> getPowerups(String mapname){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		ArrayList<Location> poweruploclist = new ArrayList<>();
		
		ConfigurationSection sec = cfg.getConfigurationSection("maps."+convertName(mapname)+".powerup");
		
		if(sec != null){
			for(String allpoweruplocs : sec.getKeys(false)){
				Location loc = (Location) cfg.get("maps."+convertName(mapname)+".powerup."+allpoweruplocs);
				
				if(loc != null){
					poweruploclist.add(loc);
				}
			}
		}
		
		return poweruploclist;
	}
	
	public static int addPowerup(String mapname, Location loc){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		int id = getNextPowerupID(mapname);
		cfg.set("maps."+convertName(mapname)+".powerup."+id, loc);
		
		try {
			cfg.save(file);
			return id;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return -1;
	}
	
	public static void removePowerup(String mapname, int id){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		cfg.set("maps."+convertName(mapname)+".powerup."+id, null);
		
		try {
			cfg.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static Location getPowerup(String mapname, int id){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		return (Location) cfg.get("maps."+convertName(mapname)+".powerup."+id);
	}
	
	public static boolean existPowerup(String mapname, int id){
		File file = FileManager.getMapFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		return cfg.contains("maps."+convertName(mapname)+".powerup."+id);
	}
	
	
	
	//LADEN

	
	public static void loadInventory(){
		int invsize = 2*9;
		ArrayList<String> maplist = MapUtils.getMapsAsList();
		int listsize = maplist.size();
		
		for(int i = 1; i < 4; i++){
			if(listsize > i*9) {
				invsize = i*9;
				invsize+=2*9;
			}
		}
		
		Main.changemap_inv = Bukkit.createInventory(null, invsize, Settings.changemap_invname);

		for(int i = 0; i < Main.changemap_inv.getSize(); i++){
			Main.changemap_inv.setItem(i, ItemUtils.getItem(Material.STAINED_GLASS_PANE, 1, 7, " ", null));
		}
		
		ItemStack currentmap = ItemUtils.getItem(Material.SLIME_BALL, 1, 0, Settings.co+"Aktuelle Map: "+Settings.hlt+Main.map, null);
		currentmap.addUnsafeEnchantment(Enchantment.DURABILITY, 1);
		ItemMeta im = currentmap.getItemMeta();
		im.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		currentmap.setItemMeta(im);
		
		Main.changemap_inv.setItem(3, currentmap);
		Main.changemap_inv.setItem(5, ItemUtils.getItem(Material.FIREBALL, 1, 0, Settings.hlt+"W�hle die Deathmatch-Map", null));
		
		int slot = 9;
		for(String maps : maplist){
			Main.changemap_inv.setItem(slot, ItemUtils.getItem(Settings.changemap_material, 1, 0, Settings.hlt+maps, "�7Klicke, um diese Map auszuw�hlen"));
			slot++;
		}
	}
	
	public static void loadDeathmatchInventory(){
		ArrayList<String> maplist = Map_DeathmatchUtils.getMapsAsList();
		int listsize = maplist.size();
		
		int invsize = 2*9;
		for(int i = 1; i < 4; i++){
			if(listsize > i*9) {
				invsize = i*9;
				invsize+=2*9;
			}
		}
		
		Main.changedmmap_inv = Bukkit.createInventory(null, invsize, Settings.changedmmap_invname);

		for(int i = 0; i < Main.changedmmap_inv.getSize(); i++){
			Main.changedmmap_inv.setItem(i, ItemUtils.getItem(Material.STAINED_GLASS_PANE, 1, 7, " ", null));
		}
		
		ItemStack currentmap = ItemUtils.getItem(Material.SLIME_BALL, 1, 0, Settings.co+"Aktuelle Deathmatch-Map: "+Settings.hlt+Main.dmmap, null);
		currentmap.addUnsafeEnchantment(Enchantment.DURABILITY, 1);
		ItemMeta im = currentmap.getItemMeta();
		im.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		currentmap.setItemMeta(im);
		
		Main.changedmmap_inv.setItem(3, currentmap);
		Main.changedmmap_inv.setItem(5, ItemUtils.getItem(Material.EYE_OF_ENDER, 1, 0, Settings.hlt+"W�hle die Game-Map", null));

		int slot = 9;
		for(String maps : maplist){
			Main.changedmmap_inv.setItem(slot, ItemUtils.getItem(Settings.changemap_material, 1, 0, Settings.hlt+maps, "�7Klicke, um diese Deathmatch-Map auszuw�hlen"));
			slot++;
		}
	}
	
}
