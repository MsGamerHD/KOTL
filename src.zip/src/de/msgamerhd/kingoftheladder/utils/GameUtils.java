package de.msgamerhd.kingoftheladder.utils;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Team;

/**
 * Class created by MsGamerHD on 02.10.2016
 */
public class GameUtils {

	public static Player king = null;
	
	public static void setKing(Player p){
		if(!isKing(p) && (Main.status == GameStatus.INGAME ||  Main.status == GameStatus.PROTECTION)){
			Player oldking = king;
			
			if(p != null){
				ScoreboardUtils.switchKing(oldking, p);
				king = p;
				PlayerUtils.updateItems(p);
				p.sendMessage(Settings.pr+Settings.acpt+"Du bist der neue K�nig");
				PlayerUtils.sendActionBar(p, Settings.acpt+"Du bist der neue K�nig");
				
				for(Player all : Bukkit.getOnlinePlayers()){
					all.playSound(all.getLocation(), Sound.BLAZE_BREATH, 1, 1);
					
					if(all != king){
						all.sendMessage(Settings.pr+"�6"+king.getName()+Settings.acpt+" ist der neue K�nig!");
						PlayerUtils.sendActionBar(all, "�6"+king.getName()+Settings.acpt+" ist der neue K�nig!");
					}
				}
			}
			
			if(oldking != null){
				ScoreboardUtils.switchKing(oldking, p);
				PlayerUtils.updateItems(oldking);
			}
		}
	}
	
	public static int getPlayerCount(){
		int count = 0;
		for(Player all : Bukkit.getOnlinePlayers()){
			if(PlayerUtils.getTeam(all) == Team.SPIELENDER){
				count+=1;
			}
		}
		
		return count;
	}
	
	public static void resetKing(){
		if(Main.status == GameStatus.INGAME){
			if(king != null){
				for(Player all : Bukkit.getOnlinePlayers()){
					if(all != king){
						all.playSound(all.getLocation(), Sound.ENDERDRAGON_GROWL, 3, 3);
						((CraftPlayer)all).sendTitle("", "�cDer �6K�nig �cist gefallen!");
					}
				}
				ScoreboardUtils.switchKing(king, null);
				king = null;
			}
		}
	}
	
	public static boolean isKing(Player p){
		if(king != null && p != null) if(p == king) return true;
		
		return false;
	}
	
}
