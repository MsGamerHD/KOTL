package de.msgamerhd.kingoftheladder.utils;

import java.util.HashMap;

import org.bukkit.entity.Player;

/**
 * Class created by MsGamerHD on 01.10.2016
 */
public class TokensUtils {

	public static HashMap<Player, Integer> tokens = new HashMap<>();
	
	public static int getTokens(Player p){
		if(!tokens.containsKey(p)){
			tokens.put(p, PointsUtils.getPoints(p)*10);
			p.setLevel(PointsUtils.getPoints(p)*10);
		}
		return tokens.get(p);
	}
	
	public static void addTokens(Player p, int amount){
		if(p != null){
			if(amount > 0){
				int newamount = getTokens(p)+amount;
				if(newamount < 0) newamount = 0;
				
				tokens.put(p, newamount);
				p.setLevel(newamount);
				ScoreboardUtils.updateBoard();
			}
		}
	}
	
	public static void removeTokens(Player p, int amount){
		if(amount > 0){
			int newamount = getTokens(p)-amount;
			if(newamount < 0) newamount = 0;
			
			tokens.put(p, newamount);
			p.setLevel(newamount);
			ScoreboardUtils.updateBoard();
		}
	}
	
}
