package de.msgamerhd.kingoftheladder.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.countdowns.RestartCountdown;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Kit;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.kits.KitUtils;
import de.msgamerhd.kingoftheladder.stats.Achievement;
import de.msgamerhd.kingoftheladder.stats.AchievementUtils;
import de.msgamerhd.kingoftheladder.stats.Stats_LastKit;
import de.msgamerhd.kingoftheladder.stats.Stats_Name;
import de.msgamerhd.kingoftheladder.stats.Stats_RankingPoints;
import de.msgamerhd.kingoftheladder.stats.Stats_Wins;
import net.minecraft.server.v1_8_R3.IChatBaseComponent;
import net.minecraft.server.v1_8_R3.PacketPlayOutChat;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerListHeaderFooter;
import net.minecraft.server.v1_8_R3.PlayerConnection;
import net.minecraft.server.v1_8_R3.IChatBaseComponent.ChatSerializer;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class PlayerUtils {
	
	public static HashMap<Player, Team> playerteam = new HashMap<>();
	
	public static ArrayList<Player> won = new ArrayList<>();
	
	
	public static void clearChat(Player p){
		for(int i = 0; i < 20; i++){
			p.sendMessage(" ");
		}
	}
	
	public static void sendActionBar(Player p, String message) {
		PlayerConnection con = ((CraftPlayer) p).getHandle().playerConnection;
		IChatBaseComponent chat = ChatSerializer.a("{\"text\": \"" + message + "\"}");
		PacketPlayOutChat packet = new PacketPlayOutChat(chat, (byte) 2);
		
		con.sendPacket(packet);
	}
	
	public static void sendTablist(Player p, String header, String footer) {
		PlayerConnection con = ((CraftPlayer) p).getHandle().playerConnection;
		IChatBaseComponent tabheader = ChatSerializer.a("{\"text\": \"" + header + "\"}");
		IChatBaseComponent tabfooter = ChatSerializer.a("{\"text\": \"" + footer + "\"}");
		
		PacketPlayOutPlayerListHeaderFooter packet = new PacketPlayOutPlayerListHeaderFooter(tabheader);
		
		try {
			Field field = packet.getClass().getDeclaredField("b");
			field.setAccessible(true);
			field.set(packet, tabfooter);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			con.sendPacket(packet);
		}
	}

	//Teleports
	public static int spawncounter = 1;
	
	public static void teleportToMapspawn(Player p){
		int spawnpoints = MapUtils.getSpawns(Main.map).size();
		
		if(spawncounter > spawnpoints){
			spawncounter = 1;
		}
		
		p.teleport(MapUtils.getSpawn(Main.map, spawncounter));
		
		spawncounter+=1;
	}
	
	public static int dm_spawncounter = 1;
	
	public static void teleportToDMMapspawn(Player p){
		int spawnpoints = Map_DeathmatchUtils.getSpawns(Main.dmmap).size();
		
		if(dm_spawncounter > spawnpoints){
			dm_spawncounter = 1;
		}
		
		p.teleport(Map_DeathmatchUtils.getSpawn(Main.dmmap, dm_spawncounter));
		
		dm_spawncounter+=1;
	}
	
	public static void teleportToLobby(Player p){
		Location lobby = FileManager.getLobbySpawn();
		
		if(lobby != null){
			p.teleport(lobby);
		} else {
			p.sendMessage(Settings.pr+Settings.wrn+"Der Standpunkt f�r die Lobby wurde noch nicht gesetzt.");
		}
	}
	
	//Spieler Teams
	public static void addTeam(Player p, Team team){
		if(!(playerteam.containsKey(p) && playerteam.get(p) == team)){
			playerteam.put(p, team);
			
			if(team == Team.ZUSCHAUER && (Main.status == GameStatus.INGAME ||  Main.status == GameStatus.PROTECTION)){
				p.setGameMode(GameMode.SPECTATOR);
				p.sendMessage(Settings.pr+"Du bist nun ein "+team.getName()+".");
			}
		}
	}
	
	public static void removeTeam(Player p){
		if(playerteam.containsKey(p)){
			playerteam.remove(p);
		}
	}
	
	public static Team getTeam(Player p){
		if(playerteam.containsKey(p)){
			return playerteam.get(p);
		} else {
			addTeam(p, Team.ZUSCHAUER);
			return getTeam(p);
		}
	}
	
	
	public static void updateVisibility(){
		for(Player p : Bukkit.getOnlinePlayers()){

			for(Player all : Bukkit.getOnlinePlayers()){
				if(all != p){
					if(Main.status == GameStatus.INGAME){
						if(getTeam(p) == Team.ZUSCHAUER){
							p.showPlayer(all);
						} else {
							if(getTeam(all) == Team.ZUSCHAUER){
								p.hidePlayer(all);
							} else {
								p.showPlayer(all);
							}
						}
					} else {
						p.showPlayer(all);
					}
				}
			}
		}
	}
	
	//Player - Gewinnen oder verlieren
	public static void win(Player p) {
		if(!(Main.status == GameStatus.INGAME || Main.status == GameStatus.RESTARTING)){
			Bukkit.broadcastMessage(Settings.pr+Settings.acpt+"Der Spieler "+Settings.hlt+p.getName()+Settings.acpt+" hat das Spiel gewonnen!");
			
			for(Player all : Bukkit.getOnlinePlayers()){
				all.playSound(all.getLocation(), Sound.LEVEL_UP, 1, 1);
			}
			
			Stats_Wins.add(p.getUniqueId(), 1);
			Stats_RankingPoints.add(p.getUniqueId(), 12, true);
			AchievementUtils.addAchievement(p, Achievement.ERSTERUNDE);
			
			RestartCountdown.startCountdown();
		}
	}
	
	public static void lose(Player p){
		if(!(Main.status == GameStatus.LOBBY || Main.status == GameStatus.RESTARTING)){
			Bukkit.broadcastMessage(Settings.pr+"Der Spieler "+Settings.hlt+p.getName()+Settings.co+" ist ausgeschieden!");
			if(GameUtils.isKing(p)){
				GameUtils.resetKing();
			}
			PlayerUtils.addTeam(p, Team.ZUSCHAUER);
			ScoreboardUtils.removePlayer(p.getName());
			
			Player lastplayer = null;
			for(Player all : Bukkit.getOnlinePlayers()){
				if(PlayerUtils.getTeam(all) == Team.SPIELENDER){
					lastplayer = all;
				}
			}
			
			if(GameUtils.getPlayerCount() <= 1){
				if(lastplayer != null){
					win(lastplayer);
				} else {
					Bukkit.broadcastMessage(Settings.pr+Settings.wrn+"Der Server wird neugestartet, da kein Gewinner ermittelt werden konnte!");
					RestartCountdown.startCountdown();
				}
			}
		}
	}
	
	//F�r die "K�nigs-Runde"
	public static void updateItems(Player p){
		if(Main.status == GameStatus.INGAME || Main.status == GameStatus.PROTECTION){
			//Helm (Status)
			if(GameUtils.isKing(p)){
				p.getInventory().setChestplate(ItemUtils.getItem(Material.GOLD_CHESTPLATE, 1, 0, "�6�lBrustpanzer", null, true));
				p.getInventory().setHelmet(ItemUtils.getItem(Material.GOLD_HELMET, 1, 0, "�6�lKrone", null, true));
				p.getInventory().setItem(Settings.statusitem_slot, ItemUtils.getItem(Material.GOLD_HELMET, 1, 0, "�6Du bist der K�nig", null));
			} else {
				p.getInventory().setChestplate(ItemUtils.getItem(Material.LEATHER_CHESTPLATE, 1, 0, "�c�lBrustpanzer", null, true));
				p.getInventory().setHelmet(null);
				p.getInventory().setItem(Settings.statusitem_slot, ItemUtils.getItem(Material.LEATHER_HELMET, 1, 0, "�cDu bist nicht der K�nig", null));
			}
			
			//normales Item
			ItemStack item = ItemUtils.getItem(Material.STICK, 1, 0, "�8Schlagstock", null, true);
			item.addUnsafeEnchantment(Enchantment.KNOCKBACK, 1);
			item.getItemMeta().addItemFlags(ItemFlag.HIDE_ENCHANTS);
			p.getInventory().setItem(Settings.normalitem_slot, item);
			
			//Special-Item
			if(p.getInventory().getItem(Settings.specialitem_slot) == null){
				p.getInventory().setItem(Settings.specialitem_slot, Settings.nospecial_item);
			} else if(p.getInventory().getItem(Settings.specialitem_slot).getType() == Material.AIR){
				p.getInventory().setItem(Settings.specialitem_slot, Settings.nospecial_item);
			}
			
			//Instant-Tod-Item
			p.getInventory().setItem(Settings.bugitem_slot, Settings.bug_item);
		}
		
		p.updateInventory();
	}
	
	//DEATHMATCH Leben
	public static HashMap<Player, Integer> lifes = new HashMap<>();
	
	public static int getLife(Player p){
		if(!lifes.containsKey(p)){
			lifes.put(p, 3);
			return 3;
		}
		
		return lifes.get(p);
	}
	
	public static int removeLife(Player p, int amount){
		int lifeamount = getLife(p);
		lifeamount-=amount;
		lifes.put(p, lifeamount);
		
		ScoreboardUtils.updateBoard();
		
		return lifeamount;
	}
	
	public static int addLife(Player p, int amount){
		int lifeamount = getLife(p);
		lifeamount+=amount;
		lifes.put(p, lifeamount);
		
		ScoreboardUtils.updateBoard();
		
		return lifeamount;
	}
	
	/*
	 * Respawnschutz
	 */
	public static void respawnProtection(Player p, int seconds){
		p.sendMessage(Settings.pr+"Du hast "+seconds+(seconds == 1 ? " Sekunde" : " Sekunden")+" Spawn-Schutz!");
		
		if(p.hasPotionEffect(PotionEffectType.INVISIBILITY)){
			p.removePotionEffect(PotionEffectType.INVISIBILITY);
		}
		
		p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, seconds*20, 1));
	}
	
	
	public static void resetPlayer(Player p, GameMode mode, boolean inv){	
		if(Main.status != GameStatus.LOBBY && Main.status != GameStatus.RESTARTING) {
			if(getTeam(p) == Team.ZUSCHAUER){
				mode = GameMode.SPECTATOR;
			}
		}
		
		for(PotionEffect effect : p.getActivePotionEffects()) p.removePotionEffect(effect.getType());
		p.setGameMode(mode);
		p.setFoodLevel(25);
		p.setLevel(0);
		p.setExp(0);
		
		if(inv){
			p.getInventory().clear();
			p.getInventory().setArmorContents(null);
			p.setMaxHealth(20.0);
			p.setHealthScale(20.0);
		}
		p.setHealth(p.getMaxHealth());
		
	}
	
	public static void playerJoin(Player p){
		PlayerUtils.sendTablist(p, "�6>> �ebergwerkLABS-Servernetzwerk �6<<", "�7Du befindest dich auf: "+Settings.hlt+"KOTL_01");
		Stats_Name.syncWithMySQL(p);
		
		ScoreboardUtils.resetScoreboard(p);
		ScoreboardUtils.updateBoard();

		//Bereits im Spiel
		if(Main.status != GameStatus.LOBBY){
			PlayerUtils.addTeam(p, Team.ZUSCHAUER);
			if(Main.status == GameStatus.RESTARTING){
				p.setGameMode(GameMode.ADVENTURE);
				p.sendMessage(Settings.pr+Settings.wrn+"Der Server startet gleich neu!");
			}
			PlayerUtils.resetPlayer(p, GameMode.ADVENTURE, true);
		} else {
			Bukkit.broadcastMessage(Settings.pr+p.getName()+" ist dem Spiel beigetreten.");
			PlayerUtils.resetPlayer(p, GameMode.ADVENTURE, true);
			PlayerUtils.teleportToLobby(p);
			HologramUtils.refreshHolos();
			HologramUtils.refreshPacketHolos(p);
			
			PlayerUtils.clearChat(p);
			p.sendMessage(Settings.pr+"Map: "+Settings.hlt+Main.map+Settings.co+" | Deathmatch-Map: "+Settings.hlt+Main.dmmap);
			
			//Items
			String lore = "�7�o<Rechtsklick>";
			if(p.hasPermission("game.changemap")) p.getInventory().setItem(1, ItemUtils.getItem(Material.COMPASS, 1, 0, Settings.changemap_itemname, lore));
			if(p.hasPermission("game.start")) p.getInventory().setItem(7, ItemUtils.getItem(Material.EMERALD, 1, 0, Settings.gamestart_itemname, lore));
			
			p.getInventory().setItem(3, ItemUtils.getItem(Material.EYE_OF_ENDER, 1, 0, Settings.kit_itemname, lore));
			p.getInventory().setItem(5, ItemUtils.getItem(Material.NETHER_STAR, 1, 0, Settings.achievement_itemname, lore));
		
			Kit lastkit = Stats_LastKit.get(p.getUniqueId());
			if(lastkit != null){
				if(KitUtils.hasKit(p, lastkit) == 1){
					KitUtils.pkits.put(p, lastkit);
					ScoreboardUtils.setKit(p, lastkit);
					p.sendMessage(Settings.pr+"Dir wurde dein zuletzt ausgew�hltes Kit zugeteilt.");
				} else {
					p.sendMessage(Settings.pr+Settings.wrn+"Dein letztes Kit konnte dir nicht mehr zugeteilt werden, da du dieses nicht besitzt!");
					KitUtils.pkits.put(p, Kit.KOBOLD);
					ScoreboardUtils.setKit(p, Kit.KOBOLD);
				}
			} else {
				KitUtils.pkits.put(p, Kit.KOBOLD);
				ScoreboardUtils.setKit(p, Kit.KOBOLD);
			}
		}
		PlayerUtils.updateVisibility();	
	}
	
}
