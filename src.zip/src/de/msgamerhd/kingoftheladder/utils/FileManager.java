package de.msgamerhd.kingoftheladder.utils;

import java.io.File;
import java.io.IOException;

import org.bukkit.Location;
import org.bukkit.configuration.file.YamlConfiguration;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class FileManager {

	public static File getFile(String name){
		File ordner = new File("plugins//KingOfTheLadder");
		File file = new File("plugins//KingOfTheLadder//"+name+".yml");

		if(!ordner.exists()){
			ordner.mkdir();
		}
		
		if(!file.exists()){
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return file;
	}
	
	public static File getLocationFile(){
		return getFile("location");
	}
	
	public static File getMapFile(){
		return getFile("maps");
	}
	
	public static File getDataFile(){
		return getFile("data");
	}
	
	public static File getDeathmatchMapFile(){
		return getFile("maps_deathmatch");
	}
	
	public static File getMySQLFile(){
		File file = getFile("mysql_settings");
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

		if(!(cfg.contains("mysql.user"))) cfg.set("mysql.user", "root");
		if(!(cfg.contains("mysql.password"))) cfg.set("mysql.password", "password");
		if(!(cfg.contains("mysql.database"))) cfg.set("mysql.database", "database");
		if(!(cfg.contains("mysql.host"))) cfg.set("mysql.host", "localhost");
		
		try {
			cfg.save(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return file;
	}
	
	public static Location getLobbySpawn(){
		File file = FileManager.getLocationFile();
		YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
		
		Location lobby = (Location) cfg.get("lobby");
		
		return lobby;
	}
	
}
