package de.msgamerhd.kingoftheladder.utils;

import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import de.msgamerhd.kingoftheladder.Settings;

/**
 * Class created by MsGamerHD on 10.10.2016
 */
public class EnchanterUtils {

	public static void enchantItem(Player p, ItemStack is){
		Enchantment ench = null;
		int level = 0;
		int maxlevel = 1;
		
		if(is.getType().toString().contains("HELMET") || is.getType().toString().contains("CHESTPLATE") || is.getType().toString().contains("LEGGINGS") || is.getType().toString().contains("BOOTS")){
			ench = Enchantment.PROTECTION_ENVIRONMENTAL;
			level = is.getEnchantmentLevel(ench)+1;
			maxlevel = 5;
		} else if(is.getType().toString().contains("SWORD")){
			ench = Enchantment.DAMAGE_ALL;
			level = is.getEnchantmentLevel(ench)+1;
			maxlevel = 5;
		} else if(is.getType().toString().contains("BOW")){
			ench = Enchantment.ARROW_DAMAGE;
			level = is.getEnchantmentLevel(ench)+1;
			maxlevel = 5;
		} else if(is.getType().toString().contains("FISHING_ROD")){
			ench = Enchantment.DURABILITY;
			level = is.getEnchantmentLevel(ench)+1;
			maxlevel = 3;
		}
		
		if(ench == null){
			p.playSound(p.getLocation(), Sound.NOTE_BASS_GUITAR, 1, 1);
			p.sendMessage(Settings.pr+Settings.wrn+"Das Item kann nicht verzaubert werden!");
			return;
		}
		if(level > maxlevel){
			p.sendMessage(Settings.pr+Settings.wrn+"Dein Item ist bereits mit den besten Verzauberungen verzaubert.");
			return;
		}
		if(TokensUtils.getTokens(p) < Settings.enchantment_cost){
			p.sendMessage(Settings.pr+Settings.wrn+"Du hast nicht gen�gend Tokens!");
			return;
		}
		
		is.addUnsafeEnchantment(ench, level);
		p.playSound(p.getLocation(), Sound.LEVEL_UP, 1, 1);
		TokensUtils.removeTokens(p, Settings.enchantment_cost);

		//Bei allen Items, bis auf der Angel, bekommt man zus�tzlich Haltbarkeit
		if(ench != Enchantment.DURABILITY){
			int durabilitylevel = is.getEnchantmentLevel(Enchantment.DURABILITY)+1;
			if(durabilitylevel <= 2){
				is.addUnsafeEnchantment(Enchantment.DURABILITY, durabilitylevel);
			}
		}
	}
}
