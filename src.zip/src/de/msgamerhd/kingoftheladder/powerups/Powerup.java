package de.msgamerhd.kingoftheladder.powerups;

import java.util.ArrayList;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Effect;
import org.bukkit.FireworkEffect;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.SpecialItem;
import de.msgamerhd.kingoftheladder.utils.MapUtils;

/**
 * Class created by MsGamerHD on 02.10.2016
 */
public class Powerup {

	public static void startSpawningPowerups(){
        Random rnd = new Random();
        int wait = rnd.nextInt(30);
        wait+=20;
		
		new BukkitRunnable() {
			
			@Override
			public void run() {
				if(Main.status == GameStatus.INGAME){
					spawnPowerup();
					startSpawningPowerups();
				}
			}
		}.runTaskLater(Main.getInstance(), wait*20);
	}
	
	public static void spawnPowerup(){
		if(Main.status == GameStatus.INGAME){
			ArrayList<Location> locslist = MapUtils.getPowerups(Main.map);

	        Random rnd = new Random();
	        int rndint = rnd.nextInt(locslist.size());
			
	        Location loc = locslist.get(rndint);
	        
	        new BukkitRunnable() {

	            int y = (int) (loc.getY()+60);
	            
				@Override
				public void run() {
					if(Main.status != GameStatus.INGAME){
						cancel();
						return;
					}
					Location effectloc = loc.clone();
					effectloc.setY(y);
					
					Firework fw = (Firework) effectloc.getWorld().spawnEntity(effectloc, EntityType.FIREWORK);
					FireworkMeta fm = fw.getFireworkMeta();
					FireworkEffect effect = FireworkEffect.builder().flicker(true).withColor(Color.AQUA).withFade(Color.YELLOW).with(Type.BALL).trail(true).build();
					fm.addEffect(effect);
					fw.setFireworkMeta(fm);
					
					y-=2;
					
					if(y <= loc.getBlockY()){
				        for(Entity entity : loc.getWorld().getEntities()){
				        	if(entity instanceof ArmorStand){
				        		if(entity.getLocation().distance(loc) <= 0.8){
				        			entity.remove();
				        		}
				        	}
				        }
				        
						effectloc.setY(y);
						ArmorStand stand = (ArmorStand) effectloc.getWorld().spawnEntity(effectloc, EntityType.ARMOR_STAND);
						
						//R�stung
						ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short) 3);
						SkullMeta sm = (SkullMeta) skull.getItemMeta();
						sm.setOwner("HerrBergmann");
						skull.setItemMeta(sm);
						stand.setHelmet(skull);
						stand.setChestplate(new ItemStack(Material.IRON_CHESTPLATE));
						stand.setLeggings(new ItemStack(Material.LEATHER_LEGGINGS));
						stand.setBoots(new ItemStack(Material.LEATHER_BOOTS));
						
						//Einstellen
						stand.setArms(true);
						stand.setCanPickupItems(false);
						stand.setItemInHand(SpecialItem.getRandomItem().getItem());
						stand.setBasePlate(false);
						stand.setVisible(false);
						stand.setGravity(false);
						stand.setCustomName(Settings.powerupname);
						stand.setCustomNameVisible(true);
						
						stand.getWorld().spigot().playEffect(effectloc, Effect.MOBSPAWNER_FLAMES, 0, 0, 3, 1, 3, 0, 160, 50);

						for(Player all : Bukkit.getOnlinePlayers()){
							((CraftPlayer)all).sendTitle("", Settings.acpt+"Ein Powerup ist gespawnt");
						}
						
						cancel();
					}
				}
			}.runTaskTimer(Main.getInstance(), 0, 3);
		}
	}
	
}
