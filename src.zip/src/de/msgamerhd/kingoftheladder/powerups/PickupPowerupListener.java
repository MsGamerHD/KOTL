package de.msgamerhd.kingoftheladder.powerups;

import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.inventory.ItemStack;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.SpecialItem;
import de.msgamerhd.kingoftheladder.enums.Team;
import de.msgamerhd.kingoftheladder.stats.Stats_PowerUPs;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class PickupPowerupListener implements Listener {

	@EventHandler
	public void on(PlayerInteractAtEntityEvent e){
		if(e.getRightClicked() instanceof ArmorStand){
			e.setCancelled(true);
			
			ArmorStand stand = (ArmorStand) e.getRightClicked();
			
			if(stand.getName().equals(Settings.powerupname)){
				Player p = e.getPlayer();
				
				if(PlayerUtils.getTeam(p) == Team.SPIELENDER){
					ItemStack handitem = stand.getItemInHand();
					
					if(handitem.getType() == SpecialItem.BOGEN.getMaterial()){
						p.getInventory().setItem(9, new ItemStack(Material.ARROW, 8));
					} else {
						p.getInventory().setItem(9, null);
					}
					
					p.getInventory().setItem(Settings.specialitem_slot, handitem);
					p.playSound(p.getLocation(), Sound.CHICKEN_EGG_POP, 1, 1);
					stand.getWorld().spigot().playEffect(stand.getLocation(), Effect.POTION_SWIRL, 0, 0, 1, 1, 1, 0, 60, 50);
					
					stand.remove();
					
					Stats_PowerUPs.add(p.getUniqueId(), 1);
				}
			}
		}
	}
	
}
