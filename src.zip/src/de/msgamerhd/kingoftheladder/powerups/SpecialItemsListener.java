package de.msgamerhd.kingoftheladder.powerups;

import java.util.Random;

import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.SpecialItem;
import de.msgamerhd.kingoftheladder.kits.KitSkillUtils;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.PlayerUtils;
import de.msgamerhd.kingoftheladder.utils.PointsUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class SpecialItemsListener implements Listener {
	
	@EventHandler
	public void on(PlayerInteractEvent e){
		Player p = e.getPlayer();
		ItemStack pitem = p.getItemInHand();
		
		if(Main.status != GameStatus.INGAME){
			return;
		}
		if(e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK){
			SpecialItem specialitem = null;
			
			for(SpecialItem all : SpecialItem.values()){
				if(ItemUtils.isSameItemOnlyName(pitem, all.getItem())){
					specialitem = all;
					break;
				}
			}
			
			boolean remove = false;
			
			if(specialitem != null){
				if(specialitem == SpecialItem.PUNKTE15){
					remove = true;
					PointsUtils.addPoints(p, 15, true);
					remove = true;
					
				} else if(specialitem == SpecialItem.PUNKTE8){
					remove = true;
					PointsUtils.addPoints(p, 8, true);
					
				} else if (specialitem == SpecialItem.PUNKTE6) {
					remove = true;
					PointsUtils.addPoints(p, 6, true);
					
				} else if (specialitem == SpecialItem.PUNKTE4) {
					remove = true;
					PointsUtils.addPoints(p, 4, true);
					
				} else if (specialitem == SpecialItem.BOMBE) {
					remove = true;
					KitSkillUtils.throwTNT(p);
					
				} else if (specialitem == SpecialItem.WELLENSTO�) {
					remove = true;
					KitSkillUtils.useEarthquake(p);
					
				} else if (specialitem == SpecialItem.SPRUNG) {
					remove = true;
					p.setVelocity(p.getLocation().getDirection().multiply(1.9).setY(0.6));
					
				} else if (specialitem == SpecialItem.EXTREMESPRUNG) {
					remove = true;
					p.setVelocity(p.getLocation().getDirection().multiply(2.8).setY(1.2));
					
				}
			}
			if(remove){
				if(pitem.getAmount() > 1){
					pitem.setAmount((pitem.getAmount()-1));
				} else {
					p.setItemInHand(new ItemStack(Material.AIR));
				}
				PlayerUtils.updateItems(p);
			}
		}
	}
	
	@EventHandler
	public void on(EntityDamageByEntityEvent e){
		Entity en = e.getEntity();
		Entity dm = e.getDamager();
		
		if(en instanceof Player && dm instanceof Player){
			Player p = (Player) en;
			Player damager = (Player) dm;

			boolean remove = false;
			
			if(ItemUtils.isSameItem(damager.getItemInHand(), SpecialItem.KN�PPEL.getItem())){
				remove = true;
				useKn�ppel(damager, p);
			} else if(ItemUtils.isSameItem(damager.getItemInHand(), SpecialItem.FROSTATTACKE.getItem())){
				remove = true;
				p.sendMessage(Settings.pr+Settings.hlt+damager.getName()+Settings.wrn+" hat dich eingefroheren.");
				KitSkillUtils.freeze(p, 6);
			}
			
			if(remove){
				if(damager.getItemInHand().getAmount() > 1){
					damager.getItemInHand().setAmount((p.getItemInHand().getAmount()-1));
				} else {
					damager.setItemInHand(new ItemStack(Material.AIR));
				}
			}
			
			PlayerUtils.updateItems(damager);
		}
	}
	
	@EventHandler
	public void on(ProjectileLaunchEvent e){
		ProjectileSource shooter = e.getEntity().getShooter();
		
		if(shooter instanceof Player){
			Player p = (Player) shooter;

			new BukkitRunnable() {
				
				@Override
				public void run() {
					PlayerUtils.updateItems(p);
				}
			}.runTaskLater(Main.getInstance(), 1);
		}
	}
	
	//Attacken
	public static void useKn�ppel(Player from, Player to){
        Random rnd = new Random();
        int amount = rnd.nextInt(20);
        amount+=2;
        
        if(PointsUtils.getPoints(to) < amount){
        	amount = PointsUtils.getPoints(to);
        }
		
        to.sendMessage(Settings.pr+Settings.hlt+from.getName()+Settings.wrn+" hat dir "+Settings.hlt+amount+Settings.wrn+(amount == 1 ? " Punkt" : " Punkte")+" geklaut!");
        from.sendMessage(Settings.pr+"Du hast "+Settings.hlt+amount+Settings.co+(amount == 1 ? " Punkt" : " Punkte")+" von "+Settings.hlt+to.getName()+Settings.co+" geklaut.");
        PointsUtils.removePoints(to, amount);
        PointsUtils.addPoints(from, amount, true);
	}
	
}
