package de.msgamerhd.kingoftheladder.shop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import de.msgamerhd.kingoftheladder.Main;
import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.GameStatus;
import de.msgamerhd.kingoftheladder.enums.Shop_Categorys;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;

/**
 * Class created by MsGamerHD on 05.10.2016
 */
public class ShopUtils {

	public static void openShop(Player p){
		if(Main.status == GameStatus.SHOP){
			Inventory inv = Bukkit.createInventory(null, 2*9, Settings.shop_name);
			
			for(Shop_Categorys ctg : Shop_Categorys.values()){
				inv.setItem(ctg.getSlot(), ItemUtils.getItem(ctg.getMaterial(), 1, 0, ctg.getName(), null));
			}
			
			p.openInventory(inv);
		}
	}
	
}
