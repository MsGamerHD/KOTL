package de.msgamerhd.kingoftheladder.shop;

import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import de.msgamerhd.kingoftheladder.Settings;
import de.msgamerhd.kingoftheladder.enums.Shop_Categorys;
import de.msgamerhd.kingoftheladder.enums.Shop_Items;
import de.msgamerhd.kingoftheladder.utils.ItemUtils;
import de.msgamerhd.kingoftheladder.utils.TokensUtils;

/**
 * Class created by MsGamerHD on 24.09.2016
 */
public class Shop_InventoryListener implements Listener {

	@EventHandler
	public void on(InventoryClickEvent e){
		Player p = (Player) e.getWhoClicked();
		
		try {
			if(e.getClickedInventory().getName().equals(Settings.shop_name)){
				e.setCancelled(true);
				
				ItemStack clicked = e.getCurrentItem();

				if(clicked.getItemMeta() != null){
					if(clicked.getItemMeta().getDisplayName() != null){

						//Wenn Kategorie gewechselt wird (bzw. wenn auf Kategorie-Item geklickt wird)
						for(Shop_Categorys ctg : Shop_Categorys.values()){
							if(clicked.getItemMeta().getDisplayName().equals(ctg.getName())){
								for(int i = 9; i < 2*9; i++){
									e.getInventory().setItem(i, new ItemStack(Material.AIR));
								}
								
								for(Shop_Items items : Shop_Items.values()){
									if(items.getCategory() == ctg){
										e.getInventory().setItem(items.getSlot()+9, ItemUtils.getItem(items.getMaterial(), items.getItem().getAmount(), items.getItem().getDurability(), items.getName(), items.getLore()));
									}
								}
								
								p.playSound(p.getLocation(), Sound.PIG_IDLE, 1, 1);
								return;
							}
						}
						
						//Wenn auf ein Item zum Kaufen geklickt wird
						for(Shop_Items items : Shop_Items.values()){
							if(clicked.getItemMeta().getDisplayName().equals(items.getName())){
								int cost = items.getTokens();
								int playertokens = TokensUtils.getTokens(p);
								
								if(playertokens >= cost){
									TokensUtils.removeTokens(p, cost);
									p.playSound(p.getLocation(), Sound.PIG_IDLE, 1, 1);
									
									if(items == Shop_Items.EXTRAHERZEN){
										double health = p.getMaxHealth()+2;
										p.setMaxHealth(health);
										p.setHealthScale(health);
										p.setHealth(p.getMaxHealth());
										p.getWorld().spigot().playEffect(p.getLocation(), Effect.HEART, 0, 0, 1, 1, 1, 0, 50, 20);
									} else {
										ItemStack is = items.getItem();
										ItemMeta im = is.getItemMeta();
										im.setDisplayName(null);
										im.setLore(null);
										if(items == Shop_Items.HEILSTATION || items == Shop_Items.FEUERATTACKE || items == Shop_Items.SPINNENWEBEN || items == Shop_Items.PILZ) im.setDisplayName(items.getName());
										is.setItemMeta(im);
										p.getInventory().addItem(is);
									}
								} else {
									p.playSound(p.getLocation(), Sound.ITEM_BREAK, 1, 1);
								}
								
								return;
							}
						}
					}
				}
				
				
			}
		} catch (NullPointerException exp) {
		}
	}
	
}
